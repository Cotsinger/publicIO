-- 1031 CORDIS OSI catalog for an empty test catalog. Ontologies use the REST upload.
BEGIN;
COPY public.t_semantic_data_table (entity_id, entity_type, schema_name, table_name, table_name_en, db_name_en, table_id, source_type, table_name_ch, table_description, ddl, layer, column_descriptions, qualified_name, data_retention_period_days, table_properties, status, created_at, updated_at) FROM stdin;
d172eb52-7fff-4cc8-b2ad-e61821067136	PhysicalTable	unics_cordis	erc_panels	erc_panels	cordis_temporary	\N	postgresql	\N	unics_cordis.erc_panels	\N	\N	code(STRING): ERC 学科评审组（panel）的唯一标识代码，为本表主键。；part_of(STRING): 标识该评审组从属的上级分组（外键）。；description(STRING): 该 ERC 学科评审组的描述说明文本。	postgresql.cordis_temporary.unics_cordis.erc_panels	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
ae2e4492-031d-48ae-9c68-8f1dcbe95437	PhysicalTable	unics_cordis	countries	countries	cordis_temporary	\N	postgresql	\N	unics_cordis.countries	\N	\N	country_code2(STRING): 国家的两位字母代码（country code2）。；unics_id(INTEGER): 国家记录的唯一标识符（unics id），为 countries 表的主键。；country_code3(STRING): 国家的三位字母代码（country code3）。；geocode_country_code(STRING): 用于地理编码（geocode）的国家代码。；country_name(STRING): 国家的名称。	postgresql.cordis_temporary.unics_cordis.countries	\N	\N	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
db5af359-7d66-498f-b1d9-5aada88f34b5	PhysicalTable	unics_cordis	activity_types	activity_types	cordis_temporary	\N	postgresql	\N	unics_cordis.activity_types	\N	\N	description(STRING): 科研活动类型的文字说明，STRING 类型，用于解释该活动类型的含义。；code(STRING): 科研活动类型（activity type）的唯一标识代码，STRING 类型，主键。	postgresql.cordis_temporary.unics_cordis.activity_types	\N	\N	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
02237d15-fa57-4db5-824a-df2a18bb6c35	PhysicalTable	unics_cordis	institutions	institutions	cordis_temporary	\N	postgresql	\N	unics_cordis.institutions	\N	\N	country_id(INTEGER): 科研机构所属国家的 ID，外键，关联国家表。；grid_id(STRING): 科研机构的 GRID 标识 ID。；wikidata_url(STRING): 科研机构在 Wikidata 中的实体页面 URL。；website(STRING): 科研机构的官方网站网址。；db_pedia_url(STRING): 科研机构在 DBpedia 中的实体页面 URL。；geocode_regions_3(STRING): 科研机构所在的三级地理编码区域（geocode region level 3）代码，外键，用于关联地理区域信息。；short_name(STRING): 科研机构的简短名称。；document_vectors(STRING): 物理列 institutions.document_vectors（tsvector）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）；institutions_name(STRING): 科研机构的完整名称。；acronym(STRING): 科研机构的缩写（首字母缩略词）。；unics_id(INTEGER): 科研机构在 UNICS 中的唯一标识 ID，本表主键。	postgresql.cordis_temporary.unics_cordis.institutions	\N	\N	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
ced13c31-3076-4620-a122-b53f6bfbc8d1	PhysicalTable	unics_cordis	programmes	programmes	cordis_temporary	\N	postgresql	\N	unics_cordis.programmes	\N	\N	rcn(STRING): CORDIS 系统中的记录控制号（RCN），用于标识该经费计划记录。；parent(STRING): 上级（父级）经费计划的代码（外键），表示计划之间的层级关系。；short_name(STRING): 经费计划的简短名称（short name），便于引用与显示。；code(STRING): 经费计划的唯一标识代码（主键）。；title(STRING): 经费计划的完整官方名称（title）。	postgresql.cordis_temporary.unics_cordis.programmes	\N	\N	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
452d93e6-35dd-426f-863c-a998d42b2c78	PhysicalTable	unics_cordis	eu_territorial_units	eu_territorial_units	cordis_temporary	\N	postgresql	\N	unics_cordis.eu_territorial_units	\N	\N	geocode_regions(STRING): 标识欧盟地域单元的地理区域编码（geocode regions），作为表的主键唯一标识。；nuts_version(STRING): 该地域单元对应的 NUTS 分类版本。；geocode_level(INTEGER): 该地域单元地理编码（geocode）所处的层级。；description(STRING): 对该欧盟地域单元的文字描述说明。	postgresql.cordis_temporary.unics_cordis.eu_territorial_units	\N	\N	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
919004a6-67ec-4d2d-bf0f-18ae953dad15	PhysicalTable	unics_cordis	subject_areas	subject_areas	cordis_temporary	\N	postgresql	\N	unics_cordis.subject_areas	\N	\N	description(STRING): 学科领域的描述（description）文本，对该领域含义的说明。；title(STRING): 学科领域的标题（title），即该领域的名称。；code(STRING): 学科领域（subject area）的唯一标识代码，为本表主键。	postgresql.cordis_temporary.unics_cordis.subject_areas	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
af01bc68-175f-4680-a45b-7ce1df299761	PhysicalTable	unics_cordis	project_erc_panels	project_erc_panels	cordis_temporary	\N	postgresql	\N	unics_cordis.project_erc_panels	\N	\N	project(INTEGER): 关联的项目标识，指向 project 表主键的外键，标识该关联所属的CORDIS项目。；panel(STRING): 项目所关联的欧洲研究理事会（ERC）评审学科组（panel）代码，为指向 ERC 学科组表的外键。	postgresql.cordis_temporary.unics_cordis.project_erc_panels	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
64db1cbc-0840-47d4-96de-edeebe954ae9	PhysicalTable	unics_cordis	project_subject_areas	project_subject_areas	cordis_temporary	\N	postgresql	\N	unics_cordis.project_subject_areas	\N	\N	subject_area(STRING): 关联的学科领域标识（subject area，STRING），作为外键指向学科领域实体，并与 project 共同构成本表的联合主键。；project(INTEGER): 关联的项目标识（project，INTEGER），作为外键指向 CORDIS 项目实体，并与 subject_area 共同构成本表的联合主键。	postgresql.cordis_temporary.unics_cordis.project_subject_areas	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	PhysicalTable	unics_cordis	topics	topics	cordis_temporary	\N	postgresql	\N	unics_cordis.topics	\N	\N	title(STRING): 研究主题的标题（title），即该主题的正式名称。；rcn(STRING): 该研究主题记录在 CORDIS 中的 RCN（Record Control Number）编号。；code(STRING): 研究主题（topic）的唯一代码标识，为本表主键。	postgresql.cordis_temporary.unics_cordis.topics	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
cd961474-8eff-4886-97d1-6345c73e864b	PhysicalTable	unics_cordis	project_topics	project_topics	cordis_temporary	\N	postgresql	\N	unics_cordis.project_topics	\N	\N	topic(STRING): 该关联记录所指向的主题（topic）代码，作为外键引用主题相关数据，并与 project 共同构成联合主键。；project(INTEGER): 该关联记录所指向的 CORDIS 项目（project）标识，作为外键引用项目表，并与 topic 共同构成联合主键。	postgresql.cordis_temporary.unics_cordis.project_topics	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	PhysicalTable	unics_cordis	project_members	project_members	cordis_temporary	\N	postgresql	\N	unics_cordis.project_members	\N	\N	city(STRING): 项目成员所在的城市。；postal_code(STRING): 项目成员地址的邮政编码。；member_role(STRING): 该成员在项目中的角色（member role），为外键。；street(STRING): 项目成员地址中的街道信息。；region_name(STRING): 物理列 project_members.region_name（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）；region_code(STRING): 物理列 project_members.region_code（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）；vat_number(STRING): 成员的增值税（VAT）登记号码（vat number）。；ec_contribution(DOUBLE): 该项目成员获得的欧盟委员会（EC）资助金额（ec contribution）。；pic_number(STRING): 项目成员的 PIC 编号（Participant Identification Code，欧盟参与者识别码）。；unics_id(INTEGER): 项目成员记录的唯一标识（UNICS ID），作为主键。；country(STRING): 项目成员所在的国家。；department_name(STRING): 该成员所属部门的名称（department name）。；project(INTEGER): 该成员所关联的项目标识（外键，指向项目表）。；geocode_regions_3(STRING): 成员对应的三级地理区划代码（geocode regions 3），为外键。；member_name(STRING): 项目成员的名称。；latitude(STRING): 成员地理位置的纬度（latitude）。；institution_id(INTEGER): 关联的机构（institution）唯一标识，为外键。；rcn(STRING): 成员记录的 RCN 编号（Record Control Number，CORDIS 记录控制号）。；activity_type(STRING): 项目成员的活动类型（外键，关联活动类型分类）。；member_short_name(STRING): 项目成员的简短名称（member short name）。；longitude(STRING): 成员地理位置的经度（longitude）。	postgresql.cordis_temporary.unics_cordis.project_members	\N	\N	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
5ea00da3-6274-4df2-afa9-933930a5f4ec	PhysicalTable	unics_cordis	people	people	cordis_temporary	\N	postgresql	\N	unics_cordis.people	\N	\N	unics_id(INTEGER): 科研人员在 UNICS 系统中的唯一标识符（unics id），为该表主键。；full_name(STRING): 科研人员的完整姓名（full name）。	postgresql.cordis_temporary.unics_cordis.people	\N	\N	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
8d7100b2-8b83-4be9-922f-29f482ef3b8a	PhysicalTable	unics_cordis	erc_research_domains	erc_research_domains	cordis_temporary	\N	postgresql	\N	unics_cordis.erc_research_domains	\N	\N	description(STRING): ERC 研究领域的文字说明；code(STRING): ERC 研究领域的唯一代码标识（主键）	postgresql.cordis_temporary.unics_cordis.erc_research_domains	\N	\N	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
e85848dd-cca7-4995-b740-36a916a789eb	PhysicalTable	unics_cordis	project_member_roles	project_member_roles	cordis_temporary	\N	postgresql	\N	unics_cordis.project_member_roles	\N	\N	code(STRING): 项目成员角色（project member role）的唯一标识代码，为本表主键。；description(STRING): 对项目成员角色（project member role）含义的文字说明。	postgresql.cordis_temporary.unics_cordis.project_member_roles	\N	\N	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
6b6bda9e-cd24-48cb-848d-a9945edcc139	PhysicalTable	unics_cordis	ec_framework_programs	ec_framework_programs	cordis_temporary	\N	postgresql	\N	unics_cordis.ec_framework_programs	\N	\N	ec_framework_program_name(STRING): 欧盟框架计划（EC Framework Programme）的名称，作为主键唯一标识表中每条框架计划记录。	postgresql.cordis_temporary.unics_cordis.ec_framework_programs	\N	\N	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
8c160313-6794-48e9-9d43-06ef6d146023	PhysicalTable	unics_cordis	funding_schemes	funding_schemes	cordis_temporary	\N	postgresql	\N	unics_cordis.funding_schemes	\N	\N	title(STRING): 资助方式（funding scheme）的名称或标题，即该代码对应资助方式的可读名称。；code(STRING): 资助方式（funding scheme）的唯一标识代码，作为本表主键，用于关联引用该资助方式。	postgresql.cordis_temporary.unics_cordis.funding_schemes	\N	\N	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
804b8988-7d87-4a2c-9086-6be7b216f565	PhysicalTable	unics_cordis	projects	projects	cordis_temporary	\N	postgresql	\N	unics_cordis.projects	\N	\N	principal_investigator(INTEGER): 科研项目的主导研究者（principal investigator），以外键关联对应实体。；start_date(DATE): 科研项目的开始日期。；end_year(INTEGER): 科研项目计划结束的年份。；ec_max_contribution(DOUBLE): 欧盟委员会（EC）对该科研项目可提供的最大资助（contribution）金额。；end_date(DATE): 科研项目的结束日期。；title(STRING): 科研项目的完整标题。；start_year(INTEGER): 科研项目开始的年份。；ec_call(STRING): 欧盟委员会（EC）项目征集的标识。；unics_id(INTEGER): 科研项目在 UNICS 中的唯一标识，为该表主键。；framework_program(STRING): 项目所属的研发框架计划（framework program），以外键关联对应实体。；homepage(STRING): 科研项目官方网站（homepage）的链接地址。；ec_ref(STRING): 欧盟委员会（EC）的项目参考编号。；total_cost(DOUBLE): 科研项目实施的总成本（total cost）金额。；acronym(STRING): 科研项目的缩写名称。；cordis_ref(STRING): CORDIS 平台中的项目参考编号。；objective(STRING): 科研项目的研究目标（objective）描述文本。；ec_fund_scheme(STRING): 欧盟委员会（EC）资助计划，作为外键关联。	postgresql.cordis_temporary.unics_cordis.projects	\N	\N	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
93e9b14a-3710-413d-b611-255bf90040d3	PhysicalTable	unics_cordis	project_programmes	project_programmes	cordis_temporary	\N	postgresql	\N	unics_cordis.project_programmes	\N	\N	programme(STRING): 经费计划（programme，STRING），作为主键/外键标识与本关联中项目相对应的经费计划。；project(INTEGER): 项目标识（project，INTEGER），作为主键/外键标识参与本「项目-经费计划关联」的项目。	postgresql.cordis_temporary.unics_cordis.project_programmes	\N	\N	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
\.
COPY public.t_semantic_data_column (dimension_id, name, qualified_name, is_primary_key, status, column_name_desc, column_description, column_description_short, column_description_medium, column_value_profile, column_properties, synonyms, value_nullable, is_foreign_key, db_name_en, table_name_en, table_id, column_name_en, value_type, created_at, updated_at) FROM stdin;
6981aeec-9867-5559-9659-95cb008082fe	unics_id	cordis_temporary.countries.unics_id	t	Active	\N	unics_id(INTEGER): 国家记录的唯一标识符（unics id），为 countries 表的主键。	unics_id(INTEGER): 国家记录的唯一标识符（unics id），为 countries 表的主键。	unics_id(INTEGER): 国家记录的唯一标识符（unics id），为 countries 表的主键。	\N	\N	\N	f	t	cordis_temporary	countries	ae2e4492-031d-48ae-9c68-8f1dcbe95437	unics_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
181f9815-26c0-5c99-964b-5e4388beaf26	nuts_version	cordis_temporary.eu_territorial_units.nuts_version	f	Active	\N	nuts_version(STRING): 该地域单元对应的 NUTS 分类版本。	nuts_version(STRING): 该地域单元对应的 NUTS 分类版本。	nuts_version(STRING): 该地域单元对应的 NUTS 分类版本。	\N	\N	\N	t	f	cordis_temporary	eu_territorial_units	452d93e6-35dd-426f-863c-a998d42b2c78	nuts_version	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e06bf26a-6fc9-50a4-9371-8c9cad9bd309	short_name	cordis_temporary.institutions.short_name	f	Active	\N	short_name(STRING): 科研机构的简短名称。	short_name(STRING): 科研机构的简短名称。	short_name(STRING): 科研机构的简短名称。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	short_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e4b5df58-1b68-5b1c-b7a2-3ea0ff6428a5	rcn	cordis_temporary.programmes.rcn	f	Active	\N	rcn(STRING): CORDIS 系统中的记录控制号（RCN），用于标识该经费计划记录。	rcn(STRING): CORDIS 系统中的记录控制号（RCN），用于标识该经费计划记录。	rcn(STRING): CORDIS 系统中的记录控制号（RCN），用于标识该经费计划记录。	\N	\N	\N	t	f	cordis_temporary	programmes	ced13c31-3076-4620-a122-b53f6bfbc8d1	rcn	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
1dd2d62b-c967-5b5a-8166-0cbc93a54f14	acronym	cordis_temporary.projects.acronym	f	Active	\N	acronym(STRING): 科研项目的缩写名称。	acronym(STRING): 科研项目的缩写名称。	acronym(STRING): 科研项目的缩写名称。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	acronym	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
d5a9ced2-8f7f-509e-92b0-fc7f17f5e08f	cordis_ref	cordis_temporary.projects.cordis_ref	f	Active	\N	cordis_ref(STRING): CORDIS 平台中的项目参考编号。	cordis_ref(STRING): CORDIS 平台中的项目参考编号。	cordis_ref(STRING): CORDIS 平台中的项目参考编号。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	cordis_ref	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
daa00751-7e2e-5208-9f34-6dabc4446e6c	start_date	cordis_temporary.projects.start_date	f	Active	\N	start_date(DATE): 科研项目的开始日期。	start_date(DATE): 科研项目的开始日期。	start_date(DATE): 科研项目的开始日期。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	start_date	DATE	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
0f2c294b-e5bb-5658-a34f-e199c381f6ed	geocode_country_code	cordis_temporary.countries.geocode_country_code	f	Active	\N	geocode_country_code(STRING): 用于地理编码（geocode）的国家代码。	geocode_country_code(STRING): 用于地理编码（geocode）的国家代码。	geocode_country_code(STRING): 用于地理编码（geocode）的国家代码。	\N	\N	\N	t	f	cordis_temporary	countries	ae2e4492-031d-48ae-9c68-8f1dcbe95437	geocode_country_code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
1003752e-5e92-59a4-ad11-a581286595ec	country_id	cordis_temporary.institutions.country_id	f	Active	\N	country_id(INTEGER): 科研机构所属国家的 ID，外键，关联国家表。	country_id(INTEGER): 科研机构所属国家的 ID，外键，关联国家表。	country_id(INTEGER): 科研机构所属国家的 ID，外键，关联国家表。	\N	\N	\N	t	t	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	country_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
10a834e0-b46e-5ebe-bb26-da4618fab0b3	street	cordis_temporary.project_members.street	f	Active	\N	street(STRING): 项目成员地址中的街道信息。	street(STRING): 项目成员地址中的街道信息。	street(STRING): 项目成员地址中的街道信息。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	street	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
00870e84-bc48-5394-809c-0cf025d684d0	title	cordis_temporary.projects.title	f	Active	\N	title(STRING): 科研项目的完整标题。	title(STRING): 科研项目的完整标题。	title(STRING): 科研项目的完整标题。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	title	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
45c1c894-f774-588d-bf53-82e3b1cf1c44	unics_id	cordis_temporary.people.unics_id	t	Active	\N	unics_id(INTEGER): 科研人员在 UNICS 系统中的唯一标识符（unics id），为该表主键。	unics_id(INTEGER): 科研人员在 UNICS 系统中的唯一标识符（unics id），为该表主键。	unics_id(INTEGER): 科研人员在 UNICS 系统中的唯一标识符（unics id），为该表主键。	\N	\N	\N	f	t	cordis_temporary	people	5ea00da3-6274-4df2-afa9-933930a5f4ec	unics_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
5ef477d6-ac45-5285-9baa-89e4a77ed6cf	unics_id	cordis_temporary.institutions.unics_id	t	Active	\N	unics_id(INTEGER): 科研机构在 UNICS 中的唯一标识 ID，本表主键。	unics_id(INTEGER): 科研机构在 UNICS 中的唯一标识 ID，本表主键。	unics_id(INTEGER): 科研机构在 UNICS 中的唯一标识 ID，本表主键。	\N	\N	\N	f	t	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	unics_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
27f223f5-297f-53cd-91fc-8335c34f6eab	ec_call	cordis_temporary.projects.ec_call	f	Active	\N	ec_call(STRING): 欧盟委员会（EC）项目征集的标识。	ec_call(STRING): 欧盟委员会（EC）项目征集的标识。	ec_call(STRING): 欧盟委员会（EC）项目征集的标识。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	ec_call	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
92fd1362-a2d5-552c-9d25-b0b6985c9abd	code	cordis_temporary.funding_schemes.code	t	Active	\N	code(STRING): 资助方式（funding scheme）的唯一标识代码，作为本表主键，用于关联引用该资助方式。	code(STRING): 资助方式（funding scheme）的唯一标识代码，作为本表主键，用于关联引用该资助方式。	code(STRING): 资助方式（funding scheme）的唯一标识代码，作为本表主键，用于关联引用该资助方式。	\N	\N	\N	f	t	cordis_temporary	funding_schemes	8c160313-6794-48e9-9d43-06ef6d146023	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
a5149156-fafa-5143-b48c-54798d4b6d61	country_name	cordis_temporary.countries.country_name	f	Active	\N	country_name(STRING): 国家的名称。	country_name(STRING): 国家的名称。	country_name(STRING): 国家的名称。	\N	\N	\N	t	f	cordis_temporary	countries	ae2e4492-031d-48ae-9c68-8f1dcbe95437	country_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
a5216dd0-53fa-5b35-9605-517f7f7b1635	homepage	cordis_temporary.projects.homepage	f	Active	\N	homepage(STRING): 科研项目官方网站（homepage）的链接地址。	homepage(STRING): 科研项目官方网站（homepage）的链接地址。	homepage(STRING): 科研项目官方网站（homepage）的链接地址。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	homepage	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
afbe1d23-b5ab-5a41-8cfb-1042c22bb13d	objective	cordis_temporary.projects.objective	f	Active	\N	objective(STRING): 科研项目的研究目标（objective）描述文本。	objective(STRING): 科研项目的研究目标（objective）描述文本。	objective(STRING): 科研项目的研究目标（objective）描述文本。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	objective	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
b4356ca7-95c5-51e3-9e92-48237ae3c85e	full_name	cordis_temporary.people.full_name	f	Active	\N	full_name(STRING): 科研人员的完整姓名（full name）。	full_name(STRING): 科研人员的完整姓名（full name）。	full_name(STRING): 科研人员的完整姓名（full name）。	\N	\N	\N	t	f	cordis_temporary	people	5ea00da3-6274-4df2-afa9-933930a5f4ec	full_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
27de199a-8fdb-57d5-8259-23cd1328696e	institutions_name	cordis_temporary.institutions.institutions_name	f	Active	\N	institutions_name(STRING): 科研机构的完整名称。	institutions_name(STRING): 科研机构的完整名称。	institutions_name(STRING): 科研机构的完整名称。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	institutions_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
1fa2911e-abe8-5d67-a119-1f1a6f03e237	code	cordis_temporary.topics.code	t	Active	\N	code(STRING): 研究主题（topic）的唯一代码标识，为本表主键。	code(STRING): 研究主题（topic）的唯一代码标识，为本表主键。	code(STRING): 研究主题（topic）的唯一代码标识，为本表主键。	\N	\N	\N	f	t	cordis_temporary	topics	5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e2815a8a-3288-51b3-9b1e-14e37c8a5452	rcn	cordis_temporary.topics.rcn	f	Active	\N	rcn(STRING): 该研究主题记录在 CORDIS 中的 RCN（Record Control Number）编号。	rcn(STRING): 该研究主题记录在 CORDIS 中的 RCN（Record Control Number）编号。	rcn(STRING): 该研究主题记录在 CORDIS 中的 RCN（Record Control Number）编号。	\N	\N	\N	t	f	cordis_temporary	topics	5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	rcn	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
607298ac-0e01-5419-abd8-ce63c13d243c	title	cordis_temporary.topics.title	f	Active	\N	title(STRING): 研究主题的标题（title），即该主题的正式名称。	title(STRING): 研究主题的标题（title），即该主题的正式名称。	title(STRING): 研究主题的标题（title），即该主题的正式名称。	\N	\N	\N	t	f	cordis_temporary	topics	5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	title	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
19c64428-f519-5d25-975e-0fd662917cfd	code	cordis_temporary.subject_areas.code	t	Active	\N	code(STRING): 学科领域（subject area）的唯一标识代码，为本表主键。	code(STRING): 学科领域（subject area）的唯一标识代码，为本表主键。	code(STRING): 学科领域（subject area）的唯一标识代码，为本表主键。	\N	\N	\N	f	t	cordis_temporary	subject_areas	919004a6-67ec-4d2d-bf0f-18ae953dad15	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
98395eca-3905-53c8-b341-e2d0ff50d3d0	db_pedia_url	cordis_temporary.institutions.db_pedia_url	f	Active	\N	db_pedia_url(STRING): 科研机构在 DBpedia 中的实体页面 URL。	db_pedia_url(STRING): 科研机构在 DBpedia 中的实体页面 URL。	db_pedia_url(STRING): 科研机构在 DBpedia 中的实体页面 URL。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	db_pedia_url	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
2f519aea-7ac3-5aff-b489-b0adb7d8ff11	wikidata_url	cordis_temporary.institutions.wikidata_url	f	Active	\N	wikidata_url(STRING): 科研机构在 Wikidata 中的实体页面 URL。	wikidata_url(STRING): 科研机构在 Wikidata 中的实体页面 URL。	wikidata_url(STRING): 科研机构在 Wikidata 中的实体页面 URL。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	wikidata_url	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
ead61652-231c-5fce-a9cd-f41b6845a9f2	member_short_name	cordis_temporary.project_members.member_short_name	f	Active	\N	member_short_name(STRING): 项目成员的简短名称（member short name）。	member_short_name(STRING): 项目成员的简短名称（member short name）。	member_short_name(STRING): 项目成员的简短名称（member short name）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	member_short_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e4175882-86a4-5b25-aec1-63fa6157d511	department_name	cordis_temporary.project_members.department_name	f	Active	\N	department_name(STRING): 该成员所属部门的名称（department name）。	department_name(STRING): 该成员所属部门的名称（department name）。	department_name(STRING): 该成员所属部门的名称（department name）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	department_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
7e52348a-c459-5e5f-a254-4452a4f3bb36	vat_number	cordis_temporary.project_members.vat_number	f	Active	\N	vat_number(STRING): 成员的增值税（VAT）登记号码（vat number）。	vat_number(STRING): 成员的增值税（VAT）登记号码（vat number）。	vat_number(STRING): 成员的增值税（VAT）登记号码（vat number）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	vat_number	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
f543bff8-a8d7-5f67-9e3d-f432b3cc6ef4	latitude	cordis_temporary.project_members.latitude	f	Active	\N	latitude(STRING): 成员地理位置的纬度（latitude）。	latitude(STRING): 成员地理位置的纬度（latitude）。	latitude(STRING): 成员地理位置的纬度（latitude）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	latitude	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
53cf00a7-7aec-5ca9-a452-00b9024ab25d	longitude	cordis_temporary.project_members.longitude	f	Active	\N	longitude(STRING): 成员地理位置的经度（longitude）。	longitude(STRING): 成员地理位置的经度（longitude）。	longitude(STRING): 成员地理位置的经度（longitude）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	longitude	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e5859fc3-4f1b-5167-8660-07ce87deb38f	member_name	cordis_temporary.project_members.member_name	f	Active	\N	member_name(STRING): 项目成员的名称。	member_name(STRING): 项目成员的名称。	member_name(STRING): 项目成员的名称。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	member_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
9bdc6f76-c04e-5b0f-a016-4e73d8b6a0f2	geocode_level	cordis_temporary.eu_territorial_units.geocode_level	f	Active	\N	geocode_level(INTEGER): 该地域单元地理编码（geocode）所处的层级。	geocode_level(INTEGER): 该地域单元地理编码（geocode）所处的层级。	geocode_level(INTEGER): 该地域单元地理编码（geocode）所处的层级。	\N	\N	\N	t	f	cordis_temporary	eu_territorial_units	452d93e6-35dd-426f-863c-a998d42b2c78	geocode_level	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e454c561-623c-5447-8dce-b3f559f05b65	country_code2	cordis_temporary.countries.country_code2	f	Active	\N	country_code2(STRING): 国家的两位字母代码（country code2）。	country_code2(STRING): 国家的两位字母代码（country code2）。	country_code2(STRING): 国家的两位字母代码（country code2）。	\N	\N	\N	t	f	cordis_temporary	countries	ae2e4492-031d-48ae-9c68-8f1dcbe95437	country_code2	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
731f865d-608a-5661-b581-8c224c75976b	country_code3	cordis_temporary.countries.country_code3	f	Active	\N	country_code3(STRING): 国家的三位字母代码（country code3）。	country_code3(STRING): 国家的三位字母代码（country code3）。	country_code3(STRING): 国家的三位字母代码（country code3）。	\N	\N	\N	t	f	cordis_temporary	countries	ae2e4492-031d-48ae-9c68-8f1dcbe95437	country_code3	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
dbecf104-c73d-5016-99d3-dd9d6fa47120	geocode_regions	cordis_temporary.eu_territorial_units.geocode_regions	t	Active	\N	geocode_regions(STRING): 标识欧盟地域单元的地理区域编码（geocode regions），作为表的主键唯一标识。	geocode_regions(STRING): 标识欧盟地域单元的地理区域编码（geocode regions），作为表的主键唯一标识。	geocode_regions(STRING): 标识欧盟地域单元的地理区域编码（geocode regions），作为表的主键唯一标识。	\N	\N	\N	f	t	cordis_temporary	eu_territorial_units	452d93e6-35dd-426f-863c-a998d42b2c78	geocode_regions	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
89aa1f5e-9879-532a-b723-c42b81200701	description	cordis_temporary.eu_territorial_units.description	f	Active	\N	description(STRING): 对该欧盟地域单元的文字描述说明。	description(STRING): 对该欧盟地域单元的文字描述说明。	description(STRING): 对该欧盟地域单元的文字描述说明。	\N	\N	\N	t	f	cordis_temporary	eu_territorial_units	452d93e6-35dd-426f-863c-a998d42b2c78	description	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
c9b3abb6-139e-5c4a-bfcf-82c959c0afbf	part_of	cordis_temporary.erc_panels.part_of	f	Active	\N	part_of(STRING): 标识该评审组从属的上级分组（外键）。	part_of(STRING): 标识该评审组从属的上级分组（外键）。	part_of(STRING): 标识该评审组从属的上级分组（外键）。	\N	\N	\N	t	t	cordis_temporary	erc_panels	d172eb52-7fff-4cc8-b2ad-e61821067136	part_of	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
ea550e34-bc87-57e4-b93a-9319e2397423	description	cordis_temporary.erc_research_domains.description	f	Active	\N	description(STRING): ERC 研究领域的文字说明	description(STRING): ERC 研究领域的文字说明	description(STRING): ERC 研究领域的文字说明	\N	\N	\N	t	f	cordis_temporary	erc_research_domains	8d7100b2-8b83-4be9-922f-29f482ef3b8a	description	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
2e727c02-10bd-561a-881e-d586e86c93e9	end_year	cordis_temporary.projects.end_year	f	Active	\N	end_year(INTEGER): 科研项目计划结束的年份。	end_year(INTEGER): 科研项目计划结束的年份。	end_year(INTEGER): 科研项目计划结束的年份。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	end_year	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
16682df4-941a-52f4-bada-bb727361436d	ec_max_contribution	cordis_temporary.projects.ec_max_contribution	f	Active	\N	ec_max_contribution(DOUBLE): 欧盟委员会（EC）对该科研项目可提供的最大资助（contribution）金额。	ec_max_contribution(DOUBLE): 欧盟委员会（EC）对该科研项目可提供的最大资助（contribution）金额。	ec_max_contribution(DOUBLE): 欧盟委员会（EC）对该科研项目可提供的最大资助（contribution）金额。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	ec_max_contribution	DOUBLE	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
639a5c93-084c-5a9b-8911-52a923e0ab0e	subject_area	cordis_temporary.project_subject_areas.subject_area	f	Active	\N	subject_area(STRING): 关联的学科领域标识（subject area，STRING），作为外键指向学科领域实体，并与 project 共同构成本表的联合主键。	subject_area(STRING): 关联的学科领域标识（subject area，STRING），作为外键指向学科领域实体，并与 project 共同构成本表的联合主键。	subject_area(STRING): 关联的学科领域标识（subject area，STRING），作为外键指向学科领域实体，并与 project 共同构成本表的联合主键。	\N	\N	\N	t	t	cordis_temporary	project_subject_areas	64db1cbc-0840-47d4-96de-edeebe954ae9	subject_area	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
7d1f01f2-f430-5cbb-bf63-39f167f6a481	geocode_regions_3	cordis_temporary.institutions.geocode_regions_3	f	Active	\N	geocode_regions_3(STRING): 科研机构所在的三级地理编码区域（geocode region level 3）代码，外键，用于关联地理区域信息。	geocode_regions_3(STRING): 科研机构所在的三级地理编码区域（geocode region level 3）代码，外键，用于关联地理区域信息。	geocode_regions_3(STRING): 科研机构所在的三级地理编码区域（geocode region level 3）代码，外键，用于关联地理区域信息。	\N	\N	\N	t	t	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	geocode_regions_3	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
938da35f-973c-519b-9b6b-8fb2278b9324	ec_fund_scheme	cordis_temporary.projects.ec_fund_scheme	f	Active	\N	ec_fund_scheme(STRING): 欧盟委员会（EC）资助计划，作为外键关联。	ec_fund_scheme(STRING): 欧盟委员会（EC）资助计划，作为外键关联。	ec_fund_scheme(STRING): 欧盟委员会（EC）资助计划，作为外键关联。	\N	\N	\N	t	t	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	ec_fund_scheme	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
8b2aec85-d96e-5a77-9e09-6d02bc15925f	ec_ref	cordis_temporary.projects.ec_ref	f	Active	\N	ec_ref(STRING): 欧盟委员会（EC）的项目参考编号。	ec_ref(STRING): 欧盟委员会（EC）的项目参考编号。	ec_ref(STRING): 欧盟委员会（EC）的项目参考编号。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	ec_ref	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
85a724bc-e06a-57e6-8690-31bccfde0e6a	start_year	cordis_temporary.projects.start_year	f	Active	\N	start_year(INTEGER): 科研项目开始的年份。	start_year(INTEGER): 科研项目开始的年份。	start_year(INTEGER): 科研项目开始的年份。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	start_year	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
d37ffdbc-49bb-5b67-b809-6314d7443b98	title	cordis_temporary.subject_areas.title	f	Active	\N	title(STRING): 学科领域的标题（title），即该领域的名称。	title(STRING): 学科领域的标题（title），即该领域的名称。	title(STRING): 学科领域的标题（title），即该领域的名称。	\N	\N	\N	t	f	cordis_temporary	subject_areas	919004a6-67ec-4d2d-bf0f-18ae953dad15	title	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
c4c437ec-e7de-5590-9265-a2c21674ae4d	description	cordis_temporary.subject_areas.description	f	Active	\N	description(STRING): 学科领域的描述（description）文本，对该领域含义的说明。	description(STRING): 学科领域的描述（description）文本，对该领域含义的说明。	description(STRING): 学科领域的描述（description）文本，对该领域含义的说明。	\N	\N	\N	t	f	cordis_temporary	subject_areas	919004a6-67ec-4d2d-bf0f-18ae953dad15	description	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
234503d9-6d52-55a1-8580-a60c02b2cbf7	project	cordis_temporary.project_topics.project	t	Active	\N	project(INTEGER): 该关联记录所指向的 CORDIS 项目（project）标识，作为外键引用项目表，并与 topic 共同构成联合主键。	project(INTEGER): 该关联记录所指向的 CORDIS 项目（project）标识，作为外键引用项目表，并与 topic 共同构成联合主键。	project(INTEGER): 该关联记录所指向的 CORDIS 项目（project）标识，作为外键引用项目表，并与 topic 共同构成联合主键。	\N	\N	\N	f	t	cordis_temporary	project_topics	cd961474-8eff-4886-97d1-6345c73e864b	project	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
507ba30e-555e-5d20-88d1-2f3b21163ba3	topic	cordis_temporary.project_topics.topic	f	Active	\N	topic(STRING): 该关联记录所指向的主题（topic）代码，作为外键引用主题相关数据，并与 project 共同构成联合主键。	topic(STRING): 该关联记录所指向的主题（topic）代码，作为外键引用主题相关数据，并与 project 共同构成联合主键。	topic(STRING): 该关联记录所指向的主题（topic）代码，作为外键引用主题相关数据，并与 project 共同构成联合主键。	\N	\N	\N	t	t	cordis_temporary	project_topics	cd961474-8eff-4886-97d1-6345c73e864b	topic	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e542e785-7a32-50a8-ae51-68ae440db03d	project	cordis_temporary.project_subject_areas.project	t	Active	\N	project(INTEGER): 关联的项目标识（project，INTEGER），作为外键指向 CORDIS 项目实体，并与 subject_area 共同构成本表的联合主键。	project(INTEGER): 关联的项目标识（project，INTEGER），作为外键指向 CORDIS 项目实体，并与 subject_area 共同构成本表的联合主键。	project(INTEGER): 关联的项目标识（project，INTEGER），作为外键指向 CORDIS 项目实体，并与 subject_area 共同构成本表的联合主键。	\N	\N	\N	f	t	cordis_temporary	project_subject_areas	64db1cbc-0840-47d4-96de-edeebe954ae9	project	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
7e738b51-9263-5bcb-aed0-e5739092724b	code	cordis_temporary.erc_panels.code	t	Active	\N	code(STRING): ERC 学科评审组（panel）的唯一标识代码，为本表主键。	code(STRING): ERC 学科评审组（panel）的唯一标识代码，为本表主键。	code(STRING): ERC 学科评审组（panel）的唯一标识代码，为本表主键。	\N	\N	\N	f	t	cordis_temporary	erc_panels	d172eb52-7fff-4cc8-b2ad-e61821067136	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
5c6509a9-b8f8-5a92-a007-e3a6453613a7	description	cordis_temporary.erc_panels.description	f	Active	\N	description(STRING): 该 ERC 学科评审组的描述说明文本。	description(STRING): 该 ERC 学科评审组的描述说明文本。	description(STRING): 该 ERC 学科评审组的描述说明文本。	\N	\N	\N	t	f	cordis_temporary	erc_panels	d172eb52-7fff-4cc8-b2ad-e61821067136	description	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
650253ec-5c99-5ae8-8666-7c61dcd9f4b1	code	cordis_temporary.erc_research_domains.code	t	Active	\N	code(STRING): ERC 研究领域的唯一代码标识（主键）	code(STRING): ERC 研究领域的唯一代码标识（主键）	code(STRING): ERC 研究领域的唯一代码标识（主键）	\N	\N	\N	f	t	cordis_temporary	erc_research_domains	8d7100b2-8b83-4be9-922f-29f482ef3b8a	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
74927d59-86e2-56d0-9c44-a8b838ea8a55	project	cordis_temporary.project_erc_panels.project	t	Active	\N	project(INTEGER): 关联的项目标识，指向 project 表主键的外键，标识该关联所属的CORDIS项目。	project(INTEGER): 关联的项目标识，指向 project 表主键的外键，标识该关联所属的CORDIS项目。	project(INTEGER): 关联的项目标识，指向 project 表主键的外键，标识该关联所属的CORDIS项目。	\N	\N	\N	f	t	cordis_temporary	project_erc_panels	af01bc68-175f-4680-a45b-7ce1df299761	project	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
fac5e9b4-f75b-505e-9326-6b3d6f8935b0	panel	cordis_temporary.project_erc_panels.panel	f	Active	\N	panel(STRING): 项目所关联的欧洲研究理事会（ERC）评审学科组（panel）代码，为指向 ERC 学科组表的外键。	panel(STRING): 项目所关联的欧洲研究理事会（ERC）评审学科组（panel）代码，为指向 ERC 学科组表的外键。	panel(STRING): 项目所关联的欧洲研究理事会（ERC）评审学科组（panel）代码，为指向 ERC 学科组表的外键。	\N	\N	\N	t	t	cordis_temporary	project_erc_panels	af01bc68-175f-4680-a45b-7ce1df299761	panel	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
7d0c4475-d518-5a49-b9ed-7ce9dc623b08	grid_id	cordis_temporary.institutions.grid_id	f	Active	\N	grid_id(STRING): 科研机构的 GRID 标识 ID。	grid_id(STRING): 科研机构的 GRID 标识 ID。	grid_id(STRING): 科研机构的 GRID 标识 ID。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	grid_id	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
b625cd5f-5ba4-5d28-a887-b9ce09a062bc	acronym	cordis_temporary.institutions.acronym	f	Active	\N	acronym(STRING): 科研机构的缩写（首字母缩略词）。	acronym(STRING): 科研机构的缩写（首字母缩略词）。	acronym(STRING): 科研机构的缩写（首字母缩略词）。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	acronym	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
5f1c507d-b2fe-512b-bf99-1b0955cfd069	website	cordis_temporary.institutions.website	f	Active	\N	website(STRING): 科研机构的官方网站网址。	website(STRING): 科研机构的官方网站网址。	website(STRING): 科研机构的官方网站网址。	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	website	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
46d8c81d-51d8-5ef2-a0b9-c4a7110c3c9f	unics_id	cordis_temporary.project_members.unics_id	t	Active	\N	unics_id(INTEGER): 项目成员记录的唯一标识（UNICS ID），作为主键。	unics_id(INTEGER): 项目成员记录的唯一标识（UNICS ID），作为主键。	unics_id(INTEGER): 项目成员记录的唯一标识（UNICS ID），作为主键。	\N	\N	\N	f	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	unics_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
7dfb9d05-5718-5291-8161-569b6f807699	project	cordis_temporary.project_members.project	f	Active	\N	project(INTEGER): 该成员所关联的项目标识（外键，指向项目表）。	project(INTEGER): 该成员所关联的项目标识（外键，指向项目表）。	project(INTEGER): 该成员所关联的项目标识（外键，指向项目表）。	\N	\N	\N	t	t	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	project	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
f0917586-bfbc-5f3a-8365-732ae34e2406	pic_number	cordis_temporary.project_members.pic_number	f	Active	\N	pic_number(STRING): 项目成员的 PIC 编号（Participant Identification Code，欧盟参与者识别码）。	pic_number(STRING): 项目成员的 PIC 编号（Participant Identification Code，欧盟参与者识别码）。	pic_number(STRING): 项目成员的 PIC 编号（Participant Identification Code，欧盟参与者识别码）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	pic_number	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
a1bb8784-4bac-573a-9de5-8810c09e5e3b	rcn	cordis_temporary.project_members.rcn	f	Active	\N	rcn(STRING): 成员记录的 RCN 编号（Record Control Number，CORDIS 记录控制号）。	rcn(STRING): 成员记录的 RCN 编号（Record Control Number，CORDIS 记录控制号）。	rcn(STRING): 成员记录的 RCN 编号（Record Control Number，CORDIS 记录控制号）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	rcn	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
6b8a8e50-5bf9-5307-afdd-ca7e3ae26041	activity_type	cordis_temporary.project_members.activity_type	f	Active	\N	activity_type(STRING): 项目成员的活动类型（外键，关联活动类型分类）。	activity_type(STRING): 项目成员的活动类型（外键，关联活动类型分类）。	activity_type(STRING): 项目成员的活动类型（外键，关联活动类型分类）。	\N	\N	\N	t	t	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	activity_type	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
18b08caf-e6e1-5e44-a637-9637daa5f46b	country	cordis_temporary.project_members.country	f	Active	\N	country(STRING): 项目成员所在的国家。	country(STRING): 项目成员所在的国家。	country(STRING): 项目成员所在的国家。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	country	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
931ef3bd-ed69-51b6-811c-fce4b850c0ba	city	cordis_temporary.project_members.city	f	Active	\N	city(STRING): 项目成员所在的城市。	city(STRING): 项目成员所在的城市。	city(STRING): 项目成员所在的城市。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	city	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
6776b1f8-7cb3-532c-9712-a2ecad55ff85	postal_code	cordis_temporary.project_members.postal_code	f	Active	\N	postal_code(STRING): 项目成员地址的邮政编码。	postal_code(STRING): 项目成员地址的邮政编码。	postal_code(STRING): 项目成员地址的邮政编码。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	postal_code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
4cfad750-de9a-559d-a655-165cd088ef9c	ec_contribution	cordis_temporary.project_members.ec_contribution	f	Active	\N	ec_contribution(DOUBLE): 该项目成员获得的欧盟委员会（EC）资助金额（ec contribution）。	ec_contribution(DOUBLE): 该项目成员获得的欧盟委员会（EC）资助金额（ec contribution）。	ec_contribution(DOUBLE): 该项目成员获得的欧盟委员会（EC）资助金额（ec contribution）。	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	ec_contribution	DOUBLE	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
b9fb4092-cf11-5360-8e06-93bf316a3164	institution_id	cordis_temporary.project_members.institution_id	f	Active	\N	institution_id(INTEGER): 关联的机构（institution）唯一标识，为外键。	institution_id(INTEGER): 关联的机构（institution）唯一标识，为外键。	institution_id(INTEGER): 关联的机构（institution）唯一标识，为外键。	\N	\N	\N	t	t	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	institution_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e6270c4f-d40e-5130-a0ff-4ca3f3978c0e	member_role	cordis_temporary.project_members.member_role	f	Active	\N	member_role(STRING): 该成员在项目中的角色（member role），为外键。	member_role(STRING): 该成员在项目中的角色（member role），为外键。	member_role(STRING): 该成员在项目中的角色（member role），为外键。	\N	\N	\N	t	t	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	member_role	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
d89a02ac-58e5-5cf9-899c-577d956384d7	geocode_regions_3	cordis_temporary.project_members.geocode_regions_3	f	Active	\N	geocode_regions_3(STRING): 成员对应的三级地理区划代码（geocode regions 3），为外键。	geocode_regions_3(STRING): 成员对应的三级地理区划代码（geocode regions 3），为外键。	geocode_regions_3(STRING): 成员对应的三级地理区划代码（geocode regions 3），为外键。	\N	\N	\N	t	t	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	geocode_regions_3	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
20a9ee1b-db41-583f-b296-14afdab0c055	code	cordis_temporary.project_member_roles.code	t	Active	\N	code(STRING): 项目成员角色（project member role）的唯一标识代码，为本表主键。	code(STRING): 项目成员角色（project member role）的唯一标识代码，为本表主键。	code(STRING): 项目成员角色（project member role）的唯一标识代码，为本表主键。	\N	\N	\N	f	t	cordis_temporary	project_member_roles	e85848dd-cca7-4995-b740-36a916a789eb	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
f2ddaaad-dedf-5611-8dad-10c567f2287c	description	cordis_temporary.project_member_roles.description	f	Active	\N	description(STRING): 对项目成员角色（project member role）含义的文字说明。	description(STRING): 对项目成员角色（project member role）含义的文字说明。	description(STRING): 对项目成员角色（project member role）含义的文字说明。	\N	\N	\N	t	f	cordis_temporary	project_member_roles	e85848dd-cca7-4995-b740-36a916a789eb	description	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
c6357c03-2c46-5e33-87c5-88d767910eb0	code	cordis_temporary.activity_types.code	t	Active	\N	code(STRING): 科研活动类型（activity type）的唯一标识代码，STRING 类型，主键。	code(STRING): 科研活动类型（activity type）的唯一标识代码，STRING 类型，主键。	code(STRING): 科研活动类型（activity type）的唯一标识代码，STRING 类型，主键。	\N	\N	\N	f	t	cordis_temporary	activity_types	db5af359-7d66-498f-b1d9-5aada88f34b5	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
d6459c77-2aec-536e-9b0b-3278ef480b58	description	cordis_temporary.activity_types.description	f	Active	\N	description(STRING): 科研活动类型的文字说明，STRING 类型，用于解释该活动类型的含义。	description(STRING): 科研活动类型的文字说明，STRING 类型，用于解释该活动类型的含义。	description(STRING): 科研活动类型的文字说明，STRING 类型，用于解释该活动类型的含义。	\N	\N	\N	t	f	cordis_temporary	activity_types	db5af359-7d66-498f-b1d9-5aada88f34b5	description	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
0b58d135-b4f3-5448-919e-af54804de85b	unics_id	cordis_temporary.projects.unics_id	t	Active	\N	unics_id(INTEGER): 科研项目在 UNICS 中的唯一标识，为该表主键。	unics_id(INTEGER): 科研项目在 UNICS 中的唯一标识，为该表主键。	unics_id(INTEGER): 科研项目在 UNICS 中的唯一标识，为该表主键。	\N	\N	\N	f	t	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	unics_id	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
e5b9a4ba-58c6-5f7b-9dbc-6cb52670617b	end_date	cordis_temporary.projects.end_date	f	Active	\N	end_date(DATE): 科研项目的结束日期。	end_date(DATE): 科研项目的结束日期。	end_date(DATE): 科研项目的结束日期。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	end_date	DATE	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
fe127671-8b8f-5e5c-bebd-cf8fe68669d7	total_cost	cordis_temporary.projects.total_cost	f	Active	\N	total_cost(DOUBLE): 科研项目实施的总成本（total cost）金额。	total_cost(DOUBLE): 科研项目实施的总成本（total cost）金额。	total_cost(DOUBLE): 科研项目实施的总成本（total cost）金额。	\N	\N	\N	t	f	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	total_cost	DOUBLE	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
11222c24-47af-594a-9f5b-cf2f011bb7b5	framework_program	cordis_temporary.projects.framework_program	f	Active	\N	framework_program(STRING): 项目所属的研发框架计划（framework program），以外键关联对应实体。	framework_program(STRING): 项目所属的研发框架计划（framework program），以外键关联对应实体。	framework_program(STRING): 项目所属的研发框架计划（framework program），以外键关联对应实体。	\N	\N	\N	t	t	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	framework_program	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
17f167f3-ace6-52b5-80bc-a18ca7cc9046	principal_investigator	cordis_temporary.projects.principal_investigator	f	Active	\N	principal_investigator(INTEGER): 科研项目的主导研究者（principal investigator），以外键关联对应实体。	principal_investigator(INTEGER): 科研项目的主导研究者（principal investigator），以外键关联对应实体。	principal_investigator(INTEGER): 科研项目的主导研究者（principal investigator），以外键关联对应实体。	\N	\N	\N	t	t	cordis_temporary	projects	804b8988-7d87-4a2c-9086-6be7b216f565	principal_investigator	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
0d27a56d-e442-5afc-a8b9-0e21aa5e6d68	title	cordis_temporary.funding_schemes.title	f	Active	\N	title(STRING): 资助方式（funding scheme）的名称或标题，即该代码对应资助方式的可读名称。	title(STRING): 资助方式（funding scheme）的名称或标题，即该代码对应资助方式的可读名称。	title(STRING): 资助方式（funding scheme）的名称或标题，即该代码对应资助方式的可读名称。	\N	\N	\N	t	f	cordis_temporary	funding_schemes	8c160313-6794-48e9-9d43-06ef6d146023	title	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
1c0048b0-fbf6-5c65-a8c6-8db36ff3bfd5	ec_framework_program_name	cordis_temporary.ec_framework_programs.ec_framework_program_name	t	Active	\N	ec_framework_program_name(STRING): 欧盟框架计划（EC Framework Programme）的名称，作为主键唯一标识表中每条框架计划记录。	ec_framework_program_name(STRING): 欧盟框架计划（EC Framework Programme）的名称，作为主键唯一标识表中每条框架计划记录。	ec_framework_program_name(STRING): 欧盟框架计划（EC Framework Programme）的名称，作为主键唯一标识表中每条框架计划记录。	\N	\N	\N	f	t	cordis_temporary	ec_framework_programs	6b6bda9e-cd24-48cb-848d-a9945edcc139	ec_framework_program_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
a354d23b-a7e1-5001-82f1-0fd6f97d65bf	code	cordis_temporary.programmes.code	t	Active	\N	code(STRING): 经费计划的唯一标识代码（主键）。	code(STRING): 经费计划的唯一标识代码（主键）。	code(STRING): 经费计划的唯一标识代码（主键）。	\N	\N	\N	f	t	cordis_temporary	programmes	ced13c31-3076-4620-a122-b53f6bfbc8d1	code	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
8281e9a2-fe9c-5e5d-b60b-fdd8da1156a7	title	cordis_temporary.programmes.title	f	Active	\N	title(STRING): 经费计划的完整官方名称（title）。	title(STRING): 经费计划的完整官方名称（title）。	title(STRING): 经费计划的完整官方名称（title）。	\N	\N	\N	t	f	cordis_temporary	programmes	ced13c31-3076-4620-a122-b53f6bfbc8d1	title	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
1d124e44-ce61-52ab-b4f5-4532c14491f1	short_name	cordis_temporary.programmes.short_name	f	Active	\N	short_name(STRING): 经费计划的简短名称（short name），便于引用与显示。	short_name(STRING): 经费计划的简短名称（short name），便于引用与显示。	short_name(STRING): 经费计划的简短名称（short name），便于引用与显示。	\N	\N	\N	t	f	cordis_temporary	programmes	ced13c31-3076-4620-a122-b53f6bfbc8d1	short_name	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
0625dd8c-6d9b-5812-8d61-1d79b894a9b6	parent	cordis_temporary.programmes.parent	f	Active	\N	parent(STRING): 上级（父级）经费计划的代码（外键），表示计划之间的层级关系。	parent(STRING): 上级（父级）经费计划的代码（外键），表示计划之间的层级关系。	parent(STRING): 上级（父级）经费计划的代码（外键），表示计划之间的层级关系。	\N	\N	\N	t	t	cordis_temporary	programmes	ced13c31-3076-4620-a122-b53f6bfbc8d1	parent	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
6aa8e21c-3faa-53dd-aa0b-5aae05d15b47	project	cordis_temporary.project_programmes.project	t	Active	\N	project(INTEGER): 项目标识（project，INTEGER），作为主键/外键标识参与本「项目-经费计划关联」的项目。	project(INTEGER): 项目标识（project，INTEGER），作为主键/外键标识参与本「项目-经费计划关联」的项目。	project(INTEGER): 项目标识（project，INTEGER），作为主键/外键标识参与本「项目-经费计划关联」的项目。	\N	\N	\N	f	t	cordis_temporary	project_programmes	93e9b14a-3710-413d-b611-255bf90040d3	project	INTEGER	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
088f245d-84b3-57f6-964e-ef2a643d5122	programme	cordis_temporary.project_programmes.programme	f	Active	\N	programme(STRING): 经费计划（programme，STRING），作为主键/外键标识与本关联中项目相对应的经费计划。	programme(STRING): 经费计划（programme，STRING），作为主键/外键标识与本关联中项目相对应的经费计划。	programme(STRING): 经费计划（programme，STRING），作为主键/外键标识与本关联中项目相对应的经费计划。	\N	\N	\N	t	t	cordis_temporary	project_programmes	93e9b14a-3710-413d-b611-255bf90040d3	programme	STRING	2026-09-23 14:01:56.321671+00	2026-09-23 14:01:56.321671+00
2480dca3-9cd4-415f-8a87-6040b6d581f5	document_vectors	\N	f	Active	\N	document_vectors(STRING): 物理列 institutions.document_vectors（tsvector）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	document_vectors(STRING): 物理列 institutions.document_vectors（tsvector）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	document_vectors(STRING): 物理列 institutions.document_vectors（tsvector）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	\N	\N	\N	t	f	cordis_temporary	institutions	02237d15-fa57-4db5-824a-df2a18bb6c35	document_vectors	STRING	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
b8f8ea6b-aa52-41c6-9a32-f45f500ac94b	region_code	\N	f	Active	\N	region_code(STRING): 物理列 project_members.region_code（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	region_code(STRING): 物理列 project_members.region_code（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	region_code(STRING): 物理列 project_members.region_code（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	region_code	STRING	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
da24e1e3-bb9d-449c-b0c7-f0a3bc305d03	region_name	\N	f	Active	\N	region_name(STRING): 物理列 project_members.region_name（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	region_name(STRING): 物理列 project_members.region_name（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	region_name(STRING): 物理列 project_members.region_name（text）。作者数据库备份自带物理列（restore.original.sql），未纳入作者语义标注（tables.json/DICTIONARY/catalog 均无）——无业务语义标注，仅物理承接（T015 PHYSEXTRA-001）	\N	\N	\N	t	f	cordis_temporary	project_members	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	region_name	STRING	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
\.
COPY public.t_semantic_data_column_value (value_id, name, qualified_name, value, description, column_name_en, table_name_en, db_name_en, value_type, status, created_at, updated_at) FROM stdin;
7f5cfe05-3aca-4361-9566-898e927f9b24	7DUP	\N	7DUP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b4bd0009-a5d5-451c-8bdf-bb77df0c5743	ACRO	\N	ACRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7818277d-8edd-4f08-ab5e-83d6277d1e83	ADOQ	\N	ADOQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
60d52b0c-8cb6-49c3-8f6f-9af59ea9e5ee	AECE	\N	AECE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
627d0e7a-0854-40ec-81b2-537f69e7be63	3S	\N	3S		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a532d5bd-38e5-4f8d-a623-e7cc35a55ad1	4M	\N	4M		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
79b10529-4c27-4bbe-8d4e-63df9978acf2	3DCC	\N	3DCC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8891f823-ddfd-4a30-8ed0-1453a86cae15	Afghanistan	\N	Afghanistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b081039-f2e9-45b6-8ef3-4bd1ed97d870	Åland Islands	\N	Åland Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f46354d-257e-4e60-81ac-3508c3c25b4d	Albania	\N	Albania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2b058cb-0c9c-4bf4-bd21-6bf4489fafe6	Algeria	\N	Algeria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a3a765b-36ee-42fa-aa33-d9355e075e32	American Samoa	\N	American Samoa		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
67356c87-ca3d-4fd7-b143-386eb8ffa2e2	Andorra	\N	Andorra		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
63190473-1555-473e-9983-3528086986b8	Angola	\N	Angola		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ba32b9d-4ae4-45e7-910c-1120b36effc7	Anguilla	\N	Anguilla		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cf4f2d0c-6507-45f7-9495-507442a38f45	Antarctica	\N	Antarctica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47d9fb83-7f50-433c-8504-4145bd633af7	Antigua and Barbuda	\N	Antigua and Barbuda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d647d92-12a0-471f-9688-d04e0f482814	Argentina	\N	Argentina		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
55160331-563e-4a84-9af0-d955189aae78	Armenia	\N	Armenia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
834f8295-9afc-4655-af69-903c09920bb4	Aruba	\N	Aruba		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fbfd5045-f5b3-4224-87ca-fdf59595caf9	Australia	\N	Australia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58d710e3-873f-40ec-85eb-b0b5666d0c7e	Austria	\N	Austria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
95f92361-2756-4f72-8cf4-ff39abfb1d45	Azerbaijan	\N	Azerbaijan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3a91961e-b0e6-4340-9ee5-fa00963d1e23	Bahamas	\N	Bahamas		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cdee7589-6fc0-4302-873c-3376dd33676d	Bahrain	\N	Bahrain		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4291744c-badf-4bcd-a824-5e8b34ceaa19	Bangladesh	\N	Bangladesh		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9a61bafc-7f34-41b3-ae20-a846634a8110	Barbados	\N	Barbados		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
82a44d8c-b7ef-4b47-840c-371fbd123d40	Belarus	\N	Belarus		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2a7e2220-0204-4657-90bc-4652ed2da95c	Belgium	\N	Belgium		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bb01782e-de27-4a55-9121-81a15ae49505	Belize	\N	Belize		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d9ff0c19-3684-420f-a17a-b21036bfadbe	Benin	\N	Benin		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ef7586d-aea4-4de2-9d92-e5b9c3be20a8	Bermuda	\N	Bermuda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
402e193e-26b6-4dca-bf18-db03bd2edda7	BES islands	\N	BES islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a650204f-fccb-43ac-8650-0ac309b7c161	Bhutan	\N	Bhutan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d482f3c7-dbd3-4bfc-a388-67a0ee6f043d	Bolivia	\N	Bolivia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
08499dfa-cb52-40d3-818d-591d6cc87d2b	Bosnia and Herzegovina	\N	Bosnia and Herzegovina		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22a4eb2f-b2de-42dc-b3a9-87560e295127	Botswana	\N	Botswana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a6840a5-c951-4dfe-bce6-30286a1b4099	Bouvet Island	\N	Bouvet Island		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe1330ad-4f85-4c3a-b221-fc492cd525c6	Brazil	\N	Brazil		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5cb04ab6-a0d6-4cff-b2c4-e6bce4b96b2a	British Indian Ocean Territory	\N	British Indian Ocean Territory		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8f5cacbb-2281-4f22-ac1f-7528a9d84f7e	British Virgin Islands	\N	British Virgin Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4125cea3-6e3b-489b-939d-47a52ca84b12	Brunei	\N	Brunei		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e4f5ba00-13ff-47c9-9702-afae2893f02e	Bulgaria	\N	Bulgaria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2278fdbe-d8ac-4348-9dd4-84fc1f95952b	Burkina Faso	\N	Burkina Faso		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8909b22-d41f-4663-b113-f5ccf3b33832	Burundi	\N	Burundi		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1606409a-4165-482e-9667-5cdfc3f73c0f	Cambodia	\N	Cambodia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
84db7697-817c-4f70-a6c1-4277b38bac61	Cameroon	\N	Cameroon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35cfb797-225d-4ab3-bd99-3afce2b8a5c4	Canada	\N	Canada		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a94999b-ee7a-470b-abc4-3830025f3df5	Cape Verde	\N	Cape Verde		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b23b0e7b-b8b9-40f2-acb8-853c2c08d34d	Cayman Islands	\N	Cayman Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c5632e70-01d2-4b0c-90f4-8db91a439a33	Central African Republic	\N	Central African Republic		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2c02ea6f-5460-4831-946e-043abceea111	Chad	\N	Chad		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
535b6213-cbec-4095-9af6-bbb504919d40	Chile	\N	Chile		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a9626c63-39fd-4048-b0d9-4c564cefec2d	China	\N	China		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e3d6a34-9f28-46de-b1a6-546d2e2e9753	Christmas Island	\N	Christmas Island		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c77a80c8-b18a-485f-ba8a-2bcf5f4fc5d6	Cocos (Keeling) Islands	\N	Cocos (Keeling) Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c902f51f-f421-41b6-aceb-ed4314b20384	Colombia	\N	Colombia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
399413b2-b936-46fb-8624-ceca55508b47	Comoros	\N	Comoros		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
79bcf2a3-03bf-47f2-8479-562412d0bd29	Cook Islands	\N	Cook Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3eb7f7a7-cc0f-4986-ad20-13f37f3defe2	Costa Rica	\N	Costa Rica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc05be71-e938-46ba-84ed-ce205d7daf23	Croatia	\N	Croatia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7c73d55a-fd5a-4ed5-b5ef-5752576ba95f	Cuba	\N	Cuba		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eaae156f-103a-4cd5-828c-c41d5d74e3a9	Curaçao	\N	Curaçao		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
052e555e-2254-4bc2-85d4-2f7310067fff	Cyprus	\N	Cyprus		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d94a324-02ad-4dc5-a285-701d064194b2	Czech Republic	\N	Czech Republic		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20e3f8fd-cb6a-4969-b00c-bcb5efbcda18	Denmark	\N	Denmark		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c08c0be-7239-4137-b7b6-7b4e47b73d2c	Djibouti	\N	Djibouti		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2a49443c-77f7-4219-a341-5ef4c55b7980	Dominica	\N	Dominica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16650b40-18f2-4f9b-8604-fe59e1e6c6a8	Dominican Republic	\N	Dominican Republic		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8cb423a-2e6c-4e92-b5ce-b21bc9fcd5c8	DR Congo	\N	DR Congo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2202e55d-bbe5-41b2-87f8-14e1540498a2	Ecuador	\N	Ecuador		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52a88ac8-f104-4fae-85e6-d3b9cdd766a6	Egypt	\N	Egypt		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a41bc9da-df11-495c-88c5-cd8eb051bfd1	El Salvador	\N	El Salvador		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d39bb5c4-8d6a-45c0-9c02-ecee5ab203ec	Equatorial Guinea	\N	Equatorial Guinea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec8e575e-5149-4bc5-8c90-395d3c7481f3	Eritrea	\N	Eritrea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
488db660-13b2-49b8-a738-0e0ad95c714f	Estonia	\N	Estonia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c75304e1-a994-4dc5-919b-0fb9cd98fc91	Ethiopia	\N	Ethiopia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
157d2798-c67d-4b4c-a740-0f956471271c	Falkland Islands	\N	Falkland Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0ca5508-3cdd-4d62-a1c2-4d9c997cfd7f	Faroe Islands	\N	Faroe Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7693da2f-80c7-43e5-8b18-8f977dd24a50	Fiji	\N	Fiji		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80dd12f1-0937-401a-9535-f9d017b28609	Finland	\N	Finland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8ca6a59-8744-474f-8217-3cecc0fbeb58	France	\N	France		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28afd688-3264-4bd3-9518-29b04952632a	French Guiana	\N	French Guiana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dd802caa-5111-42c7-b820-abdfa0d8abe1	French Polynesia	\N	French Polynesia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
13aea138-bc7e-418f-aed9-24385479ecd4	French Southern and Antarctic Lands	\N	French Southern and Antarctic Lands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
332cb3f8-750c-441c-80fe-d5ba9267fc43	Gabon	\N	Gabon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c70442fb-b41f-4f45-a1fc-459e240d83fa	Gambia	\N	Gambia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
77e2df58-b056-49bb-bb2e-975a72e89aed	Georgia	\N	Georgia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
94fb8864-dd12-49d2-9813-fcde0517ba73	Germany	\N	Germany		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e81a1721-02b3-44ce-af9f-150081e1e508	Ghana	\N	Ghana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
49361355-dc38-4887-8363-793958c69fd8	Gibraltar	\N	Gibraltar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
724d61a9-21e9-4c29-9e4d-12a73593fa93	Greece	\N	Greece		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29d5352f-bc88-447f-98f2-bc2132d819eb	Greenland	\N	Greenland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c735602-ea8e-48b1-b12d-d4de4258bed0	Grenada	\N	Grenada		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3fbc7a8c-4fd2-45e1-9940-5ade5be94073	Guadeloupe	\N	Guadeloupe		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9fee9d4-bb2c-4895-bfc4-8a56d6cfef20	Guam	\N	Guam		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d304121d-5ee6-440c-bc96-5b4995154ba6	Guatemala	\N	Guatemala		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
099a8a37-3e4e-4fdc-b084-54f76e11d390	Guernsey	\N	Guernsey		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d285af5d-8c73-48df-aed1-a5141bbb5367	Guinea	\N	Guinea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cedbec82-c17c-4239-a91b-445c82dbb896	Guinea-Bissau	\N	Guinea-Bissau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d606562-4a92-4be6-af74-0a1d0b72ce32	Guyana	\N	Guyana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5b3e281a-fb79-472d-a9a0-e75adf858377	Haiti	\N	Haiti		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3956a520-5994-4535-aae8-2b6409b3c752	Malta	\N	Malta		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e44d1a58-0ec6-4739-b4f5-a2575290c223	Heard Island and McDonald Islands	\N	Heard Island and McDonald Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3bf1490c-ec84-4294-9b5d-3afe80b01358	Honduras	\N	Honduras		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be6d1e93-e5ab-4591-9cd0-d83c62eeae40	Hong Kong	\N	Hong Kong		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
62dd466d-02fa-4edc-a596-64ae9dc58faa	Hungary	\N	Hungary		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d5715211-0797-4d35-9fd6-f80488470856	Iceland	\N	Iceland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cb6cf777-6515-481b-8d09-a6211043d98b	India	\N	India		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
426e8d8b-b556-4261-b4be-52ae106a9cc8	Indonesia	\N	Indonesia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9648f1d3-96f1-41f2-90fe-94d9b0c32922	Iran	\N	Iran		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3f28662-7d0b-4ff3-9b06-b7e958f907ba	Iraq	\N	Iraq		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
531c12ae-103f-4144-b500-8efa6d71960c	Ireland	\N	Ireland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6366888b-e595-44b5-b613-d20ec6864b45	Isle of Man	\N	Isle of Man		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f2b199b-9516-4265-a82c-8e3bed0a6ab2	Israel	\N	Israel		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a974c10a-6576-4ab1-a6a6-53d21a628939	Italy	\N	Italy		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78abb915-bb22-43b8-bd63-f3dc6b2b822f	Ivory Coast	\N	Ivory Coast		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6fc77f2-0dc0-44c8-8251-6f937ae87863	Jamaica	\N	Jamaica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
828dd826-8a4b-44f0-99a9-90558d1c3d0c	Japan	\N	Japan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a732d4fa-57b6-4e7f-a33e-f90efbac01a1	Jersey	\N	Jersey		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2be91812-875e-4e00-95dc-3eedf036f373	Jordan	\N	Jordan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc44643b-c1e4-404d-8f96-3851721e7673	Kazakhstan	\N	Kazakhstan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
69373deb-cb86-451a-8d7e-d7ec025e4e30	Kenya	\N	Kenya		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a77b459-229d-4bed-b2d6-c0db265505fd	Kiribati	\N	Kiribati		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b620a31f-5c87-4d04-8436-9ea58dece2ba	Kosovo	\N	Kosovo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
664f4f8a-2993-4686-9232-f90f28cc5797	Kuwait	\N	Kuwait		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1b7c0f5-a677-416a-9dd0-075c45d2c9ee	Kyrgyzstan	\N	Kyrgyzstan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56926d74-9800-4d1c-8992-230c6e267031	Laos	\N	Laos		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6bfb808f-408e-4552-a846-e81237404af8	Latvia	\N	Latvia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1d99f6c-fd45-42db-b657-6aecdacfa98e	Lebanon	\N	Lebanon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f0d26e60-4d96-4d50-8d4f-03741549d4ec	Lesotho	\N	Lesotho		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f941f654-2b6a-4847-a611-e808a4af68c4	Liberia	\N	Liberia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e584dc31-141a-4580-9ea7-f69425309267	Libya	\N	Libya		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7731d446-0339-4d34-b561-db92e13e8934	Liechtenstein	\N	Liechtenstein		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3d017101-a4b7-4765-af96-a2360a65f643	Lithuania	\N	Lithuania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f1acb291-ebf9-4454-a02d-6e1b8506bca2	Luxembourg	\N	Luxembourg		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e76e8699-5fa1-4a1c-a33d-082cd9c09256	Macau	\N	Macau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4ca0a10f-8f91-4147-aa3b-11baa330024f	Macedonia	\N	Macedonia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58a385c1-e021-4755-bd7e-8c293b6d7d62	Madagascar	\N	Madagascar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a6d682d1-df34-4051-936e-caa3100a7e85	Malawi	\N	Malawi		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0e30974d-47bc-4c69-960f-d692f8f124a7	Malaysia	\N	Malaysia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6d9b6083-34dc-44cf-93d8-795b736cef08	Maldives	\N	Maldives		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce8cb716-188b-4d4b-a3ba-6224a843c3d8	Mali	\N	Mali		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e1d6dad-fa1b-4ae6-97df-87b05d380121	Marshall Islands	\N	Marshall Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
40d6556d-ebcd-4823-a4ae-9477308753d1	Martinique	\N	Martinique		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cba04a44-6e39-4f84-bcc8-dcb4f6e407e1	Mauritania	\N	Mauritania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b1129a9b-5381-452e-88e0-d2e9a183d0a2	Mauritius	\N	Mauritius		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fda729ca-38f6-4a0e-a5fb-ce58b1a71d50	Mayotte	\N	Mayotte		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
63ee1fe8-9cf5-42b0-bcba-6d8e1c04b27c	Mexico	\N	Mexico		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
45752dea-57a6-4805-82f5-ad6efa8dc43f	Micronesia	\N	Micronesia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2e22e2aa-b7e5-4351-9412-e23184daaed5	Moldova	\N	Moldova		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f96a5006-5f7e-474c-82a3-fc0113bf4f6e	Monaco	\N	Monaco		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
71a5dd76-d090-40d6-8b4a-0f555f39a5ef	Mongolia	\N	Mongolia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
64305477-360e-4c78-aff1-44e226a8bb2f	Montenegro	\N	Montenegro		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3bea65c4-d496-464d-acf6-5d5417ea312f	Montserrat	\N	Montserrat		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e0a396fd-972c-47a0-8b3c-564d18d32843	Morocco	\N	Morocco		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5789c728-a51b-4ea1-9cb6-e34c18b8fc6c	Mozambique	\N	Mozambique		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
394216a2-0b4c-481b-8642-6acf0d2b6463	Myanmar	\N	Myanmar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4de10d49-02d6-4a54-a50e-dd39effab9d9	Namibia	\N	Namibia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6350246-a991-4727-a369-4218b212d5fa	Nauru	\N	Nauru		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39e366d6-e1d7-4aef-ab68-d84eab4616fa	Nepal	\N	Nepal		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9d2c097f-6011-4118-bf68-d153c8fe6cff	Netherlands	\N	Netherlands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a32d54e-53ca-49ad-bd6b-85f0b86b6253	Netherlands Antilles	\N	Netherlands Antilles		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39ae897c-54a9-4245-813f-44a096d40e69	New Caledonia	\N	New Caledonia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ffa41d2f-b105-44f8-8b41-82e4c0c1fd31	New Zealand	\N	New Zealand		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
116d8378-5086-4c08-822c-d86e78cb951b	Nicaragua	\N	Nicaragua		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc7de0b5-3eb8-4da4-a317-0614f644e82b	Niger	\N	Niger		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba1a2c89-f1d5-4405-8c5f-db85871e7970	Nigeria	\N	Nigeria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ef3083a0-4a02-4719-a7b0-9e4f9e57ec45	Niue	\N	Niue		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
11398785-1eb5-421d-9bf0-4c5e39dd272e	Norfolk Island	\N	Norfolk Island		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22256acd-0917-45f4-86a8-d50ba569b87d	Northern Mariana Islands	\N	Northern Mariana Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
12c232a4-1e25-450c-a387-39512b0b853a	North Korea	\N	North Korea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
11d1b088-462f-47cc-8f35-4a39bab8509b	Norway	\N	Norway		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ee1d335a-1036-463a-b52d-9938268709ad	Oman	\N	Oman		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56cfa8f6-1938-447e-9309-e487fa687a98	Pakistan	\N	Pakistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b83014f1-a75e-457c-a064-323842a07de8	Palau	\N	Palau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d55e0bcd-d0c5-4de4-8ec1-ac40bfb0fdee	Palestine	\N	Palestine		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33057f28-418f-4f01-ae39-dce76997c08b	Panama	\N	Panama		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20883202-0021-43bd-b761-49a5c4e26f68	Papua New Guinea	\N	Papua New Guinea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2b4f08fa-90d5-4bf4-bf1e-517d73a215d5	Paraguay	\N	Paraguay		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dfd0bb2c-d03f-4a4a-8ad1-0a09030f5475	Peru	\N	Peru		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d36fe9f5-59fa-47c5-ab60-64e890d7f025	Philippines	\N	Philippines		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0d463214-6d6b-4c23-9180-75ede462baac	South Africa	\N	South Africa		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4ce8ff5b-4dab-4787-b414-7e0ea0438320	Pitcairn Islands	\N	Pitcairn Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
98a00317-453a-499b-a2c1-afee1fa3d44e	Poland	\N	Poland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
243f1bb4-30ea-4f9d-883e-1d7b8e093fb4	Portugal	\N	Portugal		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba2345d0-71ce-49b6-831f-eea8145e7a51	Puerto Rico	\N	Puerto Rico		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56c5464c-06d3-4480-9a0b-cdce5b5f37dd	Qatar	\N	Qatar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
573de850-8930-4fdf-b614-3a39fb2ae777	Republic of the Congo	\N	Republic of the Congo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
48c0dd03-165e-48cd-90a7-6ba3174b72da	Réunion	\N	Réunion		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd5b9d9e-17fa-47ad-9f3a-c43dd9522b3d	Romania	\N	Romania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d1ad905-a749-4a67-92b3-162e96eaacfd	Russia	\N	Russia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5fedcc7e-99dc-4ef0-a2da-674b63533b45	Rwanda	\N	Rwanda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
05744cf3-78f0-4bb5-be0e-9fd46dc57923	Saint Barthélemy	\N	Saint Barthélemy		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1da3bba6-83bb-4062-b748-cbcca2f06272	Saint Kitts and Nevis	\N	Saint Kitts and Nevis		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ca7ad961-6d64-47e9-98be-186c47e94aef	Saint Lucia	\N	Saint Lucia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f950f416-a3f3-4a6c-8365-7432346709e4	Saint Martin	\N	Saint Martin		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22e18cfc-7251-4ad7-8e59-807c892c97d1	Saint Pierre and Miquelon	\N	Saint Pierre and Miquelon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d8b1afdb-8ce6-4d72-b73d-aee0f172e4b7	Saint Vincent and the Grenadines	\N	Saint Vincent and the Grenadines		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
75818853-0b3b-427f-8479-6746cce8f9d8	Samoa	\N	Samoa		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5eb9f7c2-242f-4cb8-bc97-2437936a24b6	San Marino	\N	San Marino		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
305713ad-26c6-4e1b-a61c-2002fbe42eb3	São Tomé and Príncipe	\N	São Tomé and Príncipe		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4e572f94-2af9-476d-b431-8a56ab346f94	Saudi Arabia	\N	Saudi Arabia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aed068df-db17-49db-84e9-53a67bf186cc	Senegal	\N	Senegal		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ad7428e-109e-4a24-94c8-a9f2147c8410	Serbia	\N	Serbia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ea68261-44de-4eae-a195-bff0b6eb3dfa	Seychelles	\N	Seychelles		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
460da8d5-919a-4a2b-9987-7d714c7784d2	Sierra Leone	\N	Sierra Leone		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
618ef382-262a-451c-a05b-91f7814ae031	Singapore	\N	Singapore		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed1d23e8-3ded-4989-bdc1-39acaba2ee43	Sint Maarten	\N	Sint Maarten		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b2a17505-7a25-4504-9735-f1a96966c36c	Slovakia	\N	Slovakia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b855dec2-0601-4997-8b15-9f84970fbf02	Slovenia	\N	Slovenia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
72b57144-4ead-4e81-9d4a-dedeac06bf63	Solomon Islands	\N	Solomon Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78cd4aa1-a2f4-4799-b441-f0b14d6cc666	Somalia	\N	Somalia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b4bd1cc3-5467-4961-832d-a35dbdadfaf6	PE9	\N	PE9		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cd952f35-af02-4d99-b596-60d804a28a92	South Georgia	\N	South Georgia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9dca03e0-13ae-4df7-8c38-e062caab3698	South Korea	\N	South Korea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dacf9573-08c1-4a6a-a8f4-a2eb8aa8f5e3	South Sudan	\N	South Sudan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5d9f700f-a777-449f-b808-9a561ec452c3	CA	\N	CA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cfb7b45d-958a-4047-9d66-7844d923c8fb	Spain	\N	Spain		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a99fa7b-b65f-4e43-91ee-cfe2373cdde2	Sri Lanka	\N	Sri Lanka		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e674888b-1418-48f9-b9f6-253ffe84a1c4	Sudan	\N	Sudan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
923132e2-34bb-4db1-9e92-725f744c2f95	Suriname	\N	Suriname		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32213699-c40e-4af0-946d-dabbbadfa128	Svalbard and Jan Mayen	\N	Svalbard and Jan Mayen		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df252477-5b3f-412e-9c21-3053d53bbb02	Swaziland	\N	Swaziland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
57dcf2fc-7d99-4d7a-9578-57e30ebd0f81	Sweden	\N	Sweden		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3459e7e0-1ac4-4b98-b00c-02a27ec70adb	Switzerland	\N	Switzerland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c95ce0b5-c4b3-4567-98c4-98807073ce70	Syria	\N	Syria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f765da19-b191-44aa-86da-36a89cc7acc8	Taiwan	\N	Taiwan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
38d40099-1b08-4668-a67d-2425b017895f	Tajikistan	\N	Tajikistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58b72722-135c-4a98-bc39-8dd0f685ad62	Tanzania	\N	Tanzania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4dae1754-7a73-4bb3-b905-c563bda74217	Thailand	\N	Thailand		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f39d49f9-cffc-41f8-8f51-5d878c55a9c6	Timor-Leste	\N	Timor-Leste		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d142fce-7bd7-4fc2-aa0e-da335b291ace	Togo	\N	Togo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ff106f7d-7cf5-4a11-8981-4593c5cd957b	Tokelau	\N	Tokelau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3908c240-015b-42df-9d95-09dec6683c53	Tonga	\N	Tonga		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0be4576-6ad0-4ddd-a664-1b29df9ad5fe	Trinidad and Tobago	\N	Trinidad and Tobago		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
533a2f36-7da6-4354-8ad8-e9ecda7c5379	Tunisia	\N	Tunisia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3d49e3d3-6f17-4a2a-8575-ce552d3b7b6e	Turkey	\N	Turkey		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce019847-c49f-48ff-834c-0de00616bdcb	Turkmenistan	\N	Turkmenistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6efcf92a-167e-49fe-b28e-2a78280bc3f5	Turks and Caicos Islands	\N	Turks and Caicos Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4adacb56-e908-49f6-8fb3-96c705489ca1	Tuvalu	\N	Tuvalu		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ff913c1-44e9-4d4e-b260-0c0f1c3e8ae6	Uganda	\N	Uganda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16528b48-f21c-4caa-8402-53c833945084	Ukraine	\N	Ukraine		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47a3ba00-7aa7-40cf-8f9a-692a9efe47ce	United Arab Emirates	\N	United Arab Emirates		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a06f89c2-b7cf-40a5-91d9-3a01f5b1d117	United Kingdom	\N	United Kingdom		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c0118a6-4a5f-40be-ba13-9cd1b3f2e784	SH3	\N	SH3		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a1c4de3d-efb8-4fb2-be4b-d8fa30430d50	United States	\N	United States		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
09f65cb0-d900-40e4-bfb9-4d203a1c8914	United States Minor Outlying Islands	\N	United States Minor Outlying Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
27bae5ff-0623-499e-bcfc-b009e77bd267	United States Virgin Islands	\N	United States Virgin Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a45a95e-c613-4aff-924b-5ca01bd81c26	Uruguay	\N	Uruguay		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7ae251c0-315b-4622-9351-990073cc34e4	Uzbekistan	\N	Uzbekistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fdb24619-6580-4ab3-97d8-df93c74173e4	Vanuatu	\N	Vanuatu		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85859e1e-ff8d-4661-9fa5-f37f28815d6c	Vatican City	\N	Vatican City		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d9558797-c93b-4df8-9514-50f43e4305b9	Venezuela	\N	Venezuela		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
66214f75-87c8-4b81-8f5b-d2c50af2ae83	Vietnam	\N	Vietnam		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cb8e3206-8bc8-4878-810c-405e5e1156e1	2DDip	\N	2DDip		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
77cb332e-5871-4ecb-af6d-ded4d0e37940	Wallis and Futuna	\N	Wallis and Futuna		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
360f5a0a-4081-499f-822f-93ecd320a7a0	Western Sahara	\N	Western Sahara		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6bf4edc4-cea8-4283-a479-039e4cba344d	Yemen	\N	Yemen		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df36f4c6-898a-48a2-bf14-78cf987c094b	Yugoslavia	\N	Yugoslavia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
874b02a6-2ded-4d77-905b-24bc01210c27	Zambia	\N	Zambia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
03774c0e-abb9-4c68-ba2b-0df762690440	Zimbabwe	\N	Zimbabwe		country_name	countries	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d99398e6-2202-4bf8-8a1b-a2ac1d35b760	ID1	\N	ID1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f6ea60b-0ef0-4fcb-9b3e-c01ab66af530	LS1	\N	LS1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3620d1a8-f69d-4d11-8620-ce472c2c02f2	LS2	\N	LS2		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f508db1-a403-4062-878d-80265310cba2	LS3	\N	LS3		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c5da40fe-9156-456b-b7f7-d093208384fe	LS4	\N	LS4		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c553900d-0345-472d-a321-d4838f54631b	LS5	\N	LS5		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33b6a2f1-989e-480c-b9e5-99b9220a3c35	LS6	\N	LS6		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e58dbede-9d3d-4d70-9db6-cf835e6333bc	LS7	\N	LS7		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec8457e8-5c96-4277-a8f0-2469219354c7	LS8	\N	LS8		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ee7870d4-e182-4a75-83fb-9c313f3ae9b3	LS9	\N	LS9		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b244ebb-5174-48bd-b729-1fe73d773875	PE1	\N	PE1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4e0d8aa9-f8aa-4f67-aabd-f4357a1f9b35	PE10	\N	PE10		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7efd9164-9edf-4063-942e-8d50edc2a935	PE2	\N	PE2		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
edd4223a-0284-41f0-a75f-622766d68dbe	PE3	\N	PE3		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
59741db2-6c26-4004-bc01-e6e02be778d6	PE4	\N	PE4		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
485a364a-6239-4eb6-9537-e936cefb9c1d	PE5	\N	PE5		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
57ed33b1-c281-48e5-8955-f54a656b03be	PE6	\N	PE6		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d07f5dd-7e33-4eb1-9677-126a791c8eac	PE7	\N	PE7		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b2f46516-11ab-458b-a504-c155c16c5d4a	PE8	\N	PE8		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
69a414ff-d15a-4659-a69d-dad598d8e5eb	SH1	\N	SH1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
15790be8-9dcd-4959-a642-c834cff84662	SH2	\N	SH2		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cf2f0f18-c915-4e14-ba22-5e9290c05338	SH4	\N	SH4		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
43f3e464-0c2a-4124-bb13-369224452427	SH5	\N	SH5		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
db7fa02e-210d-4470-a6b2-fff554969d47	SH6	\N	SH6		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26909bb4-2aa4-4cab-854c-507328d7a446	€ROSNZ	\N	€ROSNZ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba48ebdc-1231-4134-abad-c24787a20a6a	03K	\N	03K		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ebbdad4-3f3e-41c7-8230-a58e74ee9836	0DISCRIMINATION	\N	0DISCRIMINATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60b99f0e-f26d-4931-99c5-ca8460941625	0E-BUILDINGS	\N	0E-BUILDINGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2fe8e44b-4f4a-464b-9192-13b2cfecf8a4	0MSPIN	\N	0MSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc30ba3b-0525-4111-bdfe-19d3abd7960d	10000 DIGITS	\N	10000 DIGITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1842b14-3fdd-4fe1-a17d-54462a899271	1000kmPLUS	\N	1000kmPLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba84625d-6ea8-4026-9281-4e9b1ce90f89	100 Archaic Genomes	\N	100 Archaic Genomes		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
147a202d-6540-4e0a-9e7e-f537ce5422a9	112CO2	\N	112CO2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bf41acd-7d75-4176-909b-cee2dbaf7906	123STABLE	\N	123STABLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a38a5879-d7af-4437-b62c-79e5d442d7fb	14_3_3	\N	14_3_3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bea9709f-7b8f-4b1d-a139-e49abc6b6f78	14-3-3Stabs	\N	14-3-3Stabs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
249861c5-873d-4669-a826-677a60a81d61	14Constraint	\N	14Constraint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
48e2b296-70c2-4395-b83b-374a0b08102c	15CBOOKTRADE	\N	15CBOOKTRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
43408e26-0b6f-4700-8253-bf9c51a26002	16gAirTest	\N	16gAirTest		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bd44358-cda7-4703-b968-65f3e7d69fc1	16gAirTest-Phase2	\N	16gAirTest-Phase2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5a09ae53-84f7-4eea-978b-56cf32136d97	1960s Bombay Cinema	\N	1960s Bombay Cinema		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3402f800-655f-4f5b-968b-d7883993bdeb	19TH-CENTURY_EUCLID	\N	19TH-CENTURY_EUCLID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bb7c33b5-6125-4c49-8b1a-53f22ac8f3f8	1CELL-MICROPROBE	\N	1CELL-MICROPROBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
50a5f103-d8c1-4318-8fb7-fa58d55e6684	1DDIPOLARGAS	\N	1DDIPOLARGAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
93ec2ef1-adf1-41f4-9427-d7f1a341321c	1D-Engine	\N	1D-Engine		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b90bc66-54dd-49e8-9763-84585dc55866	1DH2OP	\N	1DH2OP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2295f782-9dc6-4a93-8869-76430e6fd0b9	1D-Neon	\N	1D-Neon		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8c6bf0d-34eb-4089-a159-51fe3acc6eb2	1DSOLVE	\N	1DSOLVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e59fed17-ed10-4c74-8ae3-dd2017517e0c	1MoleculeNearPlasmon	\N	1MoleculeNearPlasmon		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47ff39dc-4b8d-47e1-b7ff-5485d2d6f447	1st-principles-discs	\N	1st-principles-discs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a03ee96-a564-4894-8441-3c1bb0a39a6e	1stProposal	\N	1stProposal		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
272e621a-145f-41b9-b91c-13e3de3613cf	1-SWARM	\N	1-SWARM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ca177c5-751d-4e70-a424-41587f8908bd	1-SWITCH	\N	1-SWITCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20f4452e-5a1a-4b9e-a3e0-e99054499b84	1toStopVax	\N	1toStopVax		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78189075-6637-49e6-b479-248f601f0869	2007UWM	\N	2007UWM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0b7f8e0f-36ba-4bd1-8d1f-4f179750e5ce	200SMEchallenge	\N	200SMEchallenge		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
14f7a719-3fde-4ce5-9e0a-f492a0697449	20-20 3D Media	\N	20-20 3D Media		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cc2decb5-f88f-44d2-a038-0a1422ca1823	2020 INTERFACE	\N	2020 INTERFACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd79ec16-acc1-4f66-87a7-ae778fc9486e	2021 GRIP	\N	2021 GRIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
447c4e33-420b-4840-b8f1-de1626b2dc2f	2050AP	\N	2050AP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d6e02f6-1eec-4734-a634-8e64fb78c517	20PLµS	\N	20PLµS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
66d0a669-1034-415e-81d8-141cdddad450	20SComplexity	\N	20SComplexity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ff71b8a7-0110-40e5-b7ec-82c32af57bc8	20SInhibitor	\N	20SInhibitor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad489543-fee7-45f3-b484-605988997715	21Alpha	\N	21Alpha		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c112fb9-28ec-4209-9f5b-b96fca298431	2-3-AUT	\N	2-3-AUT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c81cdae2-1daf-4665-b007-dd8356db4c84	2-3SST2016	\N	2-3SST2016		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3aecea79-51b4-4002-94d4-8e2c93019056	2-3SST2018-20	\N	2-3SST2018-20		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c542d698-83a2-4ca2-9c1f-2245e1d67dfb	24G	\N	24G		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ca5cf4ab-071d-4af7-aac9-703b4dbcb5f2	26S PROTEASOME	\N	26S PROTEASOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9eecf9c4-2e44-4baf-b94d-0c672cc89a92	28 June 1914	\N	28 June 1914		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e6cede24-c08d-49a0-a911-f3d3f7763757	2-BE-SAFE	\N	2-BE-SAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a985267-d25f-4140-b512-422773ba65e7	2BFUNTEX	\N	2BFUNTEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88a29c25-baa5-4e18-9ded-7a6a2061963f	2B-ROBUST	\N	2B-ROBUST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
504f03b4-6554-4040-87f7-88f922144561	2CE MECP2	\N	2CE MECP2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9135433f-8489-4603-8153-c01e6ad6b835	2D-4-CO2	\N	2D-4-CO2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b26ace5-350b-4e4f-9bda-e65788fe31c3	2D4D	\N	2D4D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aee9c42d-0ce9-49f7-9435-5beb72059f61	2D4QT	\N	2D4QT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
25042d5c-c466-4fd5-959c-ba2a7b80c850	2D-CHEM	\N	2D-CHEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
acfd5b4e-05f0-4256-a2cf-bd0c9530f7b4	2DCHEX	\N	2DCHEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8aa06c41-3ad3-4028-9ec2-b1d628d09102	2D-COF-WS	\N	2D-COF-WS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
caa421df-7fda-473c-888f-df01ec19d560	2DECIDE	\N	2DECIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0723398c-c64b-4dc9-b493-45cf5245a4ea	2D-EG-FET	\N	2D-EG-FET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
74954d15-d360-487c-9dad-ef3a0a40c12d	2D-EMI	\N	2D-EMI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1822ecc8-55ce-4950-9790-b0ea61eded52	2D-EPL	\N	2D-EPL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37a0e8ca-f716-415e-ae9e-fbcb4ba056ac	2D-HETERO	\N	2D-HETERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0f7d11a7-f73c-4671-8045-10bb4117baa7	2D Hetero-architecture	\N	2D Hetero-architecture		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1f20aff-32d1-40a7-a61d-19d565e895f1	2D-HETEROSTRUCTURES	\N	2D-HETEROSTRUCTURES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b709023a-9f19-45e9-8f79-490893ab3afe	2DHIBSA	\N	2DHIBSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
84a5dbff-d3c9-49f1-adb2-0b552cd825ab	2D-Ink	\N	2D-Ink		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e86cf6c7-8ec4-427f-8a19-0009cbfc7ff9	2D-INK	\N	2D-INK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6238b726-5c06-4f2e-8d49-34c441b5061d	2DInterFOX	\N	2DInterFOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8d5c0e99-bf86-448a-bbc5-1a3183724555	2DIR SPECTROMETER	\N	2DIR SPECTROMETER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c32430d4-f720-4dc0-88ec-168dc2584e1e	2D-Liquid	\N	2D-Liquid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b99590b-054b-4d6e-b043-b215fda8816c	2D-LOTTO	\N	2D-LOTTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b1c7ef25-7091-465b-b77e-ef6e48d2e1e9	2DMAGICS	\N	2DMAGICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88808d70-282e-47ee-a212-fa4f33034a65	2DMAGSPIN	\N	2DMAGSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
54c3b07a-0f59-4772-b89a-50e7d639af16	2DMAP	\N	2DMAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6027bd35-ddbf-46a4-9133-0b19d0c42cec	2DMAT4ENERGY	\N	2DMAT4ENERGY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
46107c3e-4f67-44bb-8131-737ab0db5367	2DMATER	\N	2DMATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be1ee0fe-5428-4e75-94c8-6eb7caecda43	2D-MES	\N	2D-MES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
112b2409-fc94-4b24-a32f-ea44fb72b086	2DNano	\N	2DNano		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c14e308-43a5-42f3-bdf8-2377ab2b1bb9	2DNANOCAPS	\N	2DNANOCAPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2c5a484-6ff6-481d-90e1-b1c817632959	2D-NANOLATTICES	\N	2D-NANOLATTICES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b1390e0-f745-49d7-8f20-61d2c740d19f	2DNANOPTICA	\N	2DNANOPTICA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a03254d-5c3b-4307-a2ac-492b33b77da4	2DNanoSpec	\N	2DNanoSpec		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
405d1ca3-2f00-4ade-8467-6c7ce12c9453	2D_PHOT	\N	2D_PHOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3bd315b-b62c-4ce4-86e0-3549fee6619a	2D-PnictoChem	\N	2D-PnictoChem		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b079c01d-5f4a-42be-8b74-67df1b52a9f4	2DQOptics	\N	2DQOptics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc984eb9-0d28-4aba-a1ef-895420672647	2DQP	\N	2DQP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6b78bdec-eff8-4a96-8532-d6df3b57811e	2D-QuEST	\N	2D-QuEST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eb23dbe3-9abe-4412-9f8c-a90cae7dc944	2DSi	\N	2DSi		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7cc1a54-0f94-4252-ab1b-196d512c5586	2D-SIPC	\N	2D-SIPC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
688d9b5f-a59c-4399-965a-7c91e1f903cf	2D-SMARTiES	\N	2D-SMARTiES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d4bd4dd6-3196-4e47-bbc5-d5248f1d79df	2DSPIN	\N	2DSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c2149b8-b62d-4693-999c-c9a04a77f690	2DSTOP	\N	2DSTOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3465120f-8e8a-4d43-8cc8-00a884718304	2D–SYNETRA	\N	2D–SYNETRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b0691029-e83b-4700-9010-b3f3472b1b67	2DTHERMS	\N	2DTHERMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
50ae8ff0-b503-4409-8ac7-67a85eb91714	2DTMCH2	\N	2DTMCH2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4c8f6c80-e6d8-4e10-94f7-f90bfed59362	2D-TOPSENSE	\N	2D-TOPSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
77c967bf-ece3-46c5-9704-48b78f3271e5	2DTriCat4Energy	\N	2DTriCat4Energy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c05cf20-bd0a-4022-8f1d-e9d5fb311689	2DTWISTMDs	\N	2DTWISTMDs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce50c0c9-6a7f-4b6f-9994-a0023508c94e	2D-USD	\N	2D-USD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96493252-80d2-4824-9fbb-47ecbe161707	2DValley	\N	2DValley		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5740bd6d-8343-4f85-b128-99047e8292ab	2DvdWHs	\N	2DvdWHs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
da9134ce-56ad-4157-9e05-b5b0d2c3dad2	2Exciting	\N	2Exciting		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
761a366c-ebd8-4d4c-b24c-31b71d3f9f77	2F4BIODYN	\N	2F4BIODYN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e40bb82e-c4ac-4266-b8d6-c68bd3d5c745	2for1-SingletFission	\N	2for1-SingletFission		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2bfc7a77-91b6-4ca1-bc3d-26610ac53a55	2G BIOPIC	\N	2G BIOPIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0c9e6845-bbf3-496d-af6b-7e3f5dda0478	2G-CSAFE	\N	2G-CSAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fab2482d-4fba-4aba-b5ff-77169816a9d7	2GENRETURN	\N	2GENRETURN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
90b7bc37-c9b4-40cb-90a8-1fdf55fd278b	2-HIT	\N	2-HIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3eeef53b-da13-4621-b417-244f856c54b1	2-IMMERSE	\N	2-IMMERSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8b534967-438e-4436-8786-1d12e27e1613	2ISECAP	\N	2ISECAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6d7a002c-1d21-4eb5-b056-af95445b0de3	2LIVEr	\N	2LIVEr		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
732137e4-d5b0-4f15-a69f-7aad57cf48bb	2LOOPACCURACY4LHC	\N	2LOOPACCURACY4LHC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bbe53d7-4a84-4011-90eb-c3f09fc5f27a	2MODEACHIP	\N	2MODEACHIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c675d9d-eec9-45c4-b76b-124ccffe24e7	2MODELS	\N	2MODELS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
faad7b64-e125-418a-a18b-21f3025d315a	2MOVE2	\N	2MOVE2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6382213f-016a-42d3-9073-37129beac142	2MoveMate4Melanoma	\N	2MoveMate4Melanoma		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a85baad-0f28-4ae4-8981-c5e9a7f46155	2-NanoSi	\N	2-NanoSi		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a0f184c-a96a-468b-9447-0738caaadd2c	2ND-CHANCE	\N	2ND-CHANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
27fb244e-e94d-487a-9482-32d66ced72b7	2NDVEGOIL	\N	2NDVEGOIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d4f92414-539d-4de4-8a80-f44e923cfa9a	2NIGHT-2GETHER	\N	2NIGHT-2GETHER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc231df2-c7b4-472a-a539-87d76e3cd207	2O2ACTIVATION	\N	2O2ACTIVATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5dd43c99-c8a1-46cd-8fa3-8c54a2b1abfc	2PARMA	\N	2PARMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bee343b7-0cec-4759-bd41-9560d91d982f	2PM	\N	2PM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fca0c157-0edd-4790-b126-349763b62f6a	2PM T cell Imaging	\N	2PM T cell Imaging		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d08dd359-1aff-41bc-a6f0-3a81561aa001	2SEXES_1GENOME	\N	2SEXES_1GENOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
46de66a5-1952-4c39-9d1c-7e84d750db61	2shRNA	\N	2shRNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9049850c-231e-4a13-be3a-6df46fce610f	2SST2015	\N	2SST2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f03037f7-fc54-4c0b-b9e9-e7bbca2bd22d	2STEPPARKIN	\N	2STEPPARKIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
adaf079b-47cc-4a21-bdf6-3292ea2515e9	2STOP_TBE	\N	2STOP_TBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6e74bc7b-0af0-4bf0-a3f7-90dc73a3c3c9	2WAYS	\N	2WAYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b628abc-de05-42e1-bc73-acd7338ba782	2WIDE_SENSE	\N	2WIDE_SENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2493e0ad-8945-47dd-b4b3-7672271c38ba	3DCELLART	\N	3DCELLART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e4804514-189b-4b62-96bc-79866cdc152b	31P_SPECTRA_3T	\N	31P_SPECTRA_3T		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aedd8eb3-5549-4b7f-9ca8-13b5aae00922	321	\N	321		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
41bd56e7-ae17-4eb8-ab36-81d7851cf4eb	321526	\N	321526		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fdf763ae-fe2f-457a-a09c-a46c26e64ef6	321NOW	\N	321NOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0d304be-82aa-4bfb-beb8-552532bbd514	3-5-FIRST	\N	3-5-FIRST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
59eb3cce-c63b-4c58-80a1-6ecb72133512	3ants	\N	3ants		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0501fc2f-a0d5-40a9-a71d-88f0ce453adf	3Bee Hive-Tech	\N	3Bee Hive-Tech		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d94fc496-ac4d-4999-9253-1e28a3de0cf5	3beLiEVe	\N	3beLiEVe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28746c1d-d031-43c8-9388-a038d7a6dee5	3CBIOTECH	\N	3CBIOTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e11f4a8-684b-48d1-b134-13c0ebcd7a87	3Ccar	\N	3Ccar		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6694d701-8c8d-41dd-baa0-b2f9d9ddc224	3C-SiC Si	\N	3C-SiC Si		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
97a6e95f-f4d9-4080-8160-918e55d83e7e	3D	\N	3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58f4ec50-d6db-47d5-9c0d-3a4928c023ea	3D2DPrint	\N	3D2DPrint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1367ff7-e8ec-497a-b88d-11f7f4b20532	3D3CSI	\N	3D3CSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d8873a63-3221-4875-90c0-476189dd9fed	3D4YOU	\N	3D4YOU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5aa81caa-856e-40ab-96dd-554b2cfa0274	3D-ADAPT	\N	3D-ADAPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
68cf6356-1a5c-4755-a25b-6c73fa47a71a	3DAddChip	\N	3DAddChip		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
83b4e91a-0707-4393-b28c-903ed9cd8011	3DALIGN	\N	3DALIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16a8d6fa-aa6c-46b2-b83b-6d29a9816ea2	3DAM	\N	3DAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
02a6ba06-50ec-424a-9563-b07d7b8c73e3	3D-AM-TERA	\N	3D-AM-TERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
811b2ba8-8d83-4b7b-8ea7-7197eb97fe3a	3D-APP	\N	3D-APP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
11e82219-2853-4bda-81e5-8fed468bf142	3DBAG	\N	3DBAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a950bdf4-7e77-46ce-b1f7-45b18fb853f0	3DBattery	\N	3DBattery		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a4a7b7d9-2505-41a2-bca1-5f4790e2acfc	3DBIOLUNG	\N	3DBIOLUNG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f2cc32cf-cf66-4f2e-bbaf-55d8097891eb	3D-BioMat	\N	3D-BioMat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4066bfa8-2c4d-4ee0-b04d-7166a5481b65	3D BIOMIMETICS	\N	3D BIOMIMETICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5138b6ed-ba2b-433f-b840-e34f28ab7231	3DBonding	\N	3DBonding		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3935047a-1ba9-453a-9897-65388c202a84	3DBrainStrom	\N	3DBrainStrom		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d7e17044-c9e1-4931-ae8f-07b3d0456825	3DBREASTCANCER	\N	3DBREASTCANCER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
72fcb29b-eb07-4238-a91f-29073772980a	3DCanPredict	\N	3DCanPredict		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f1baa32d-8586-4f5a-8c89-f59538021f1f	3D-CAP	\N	3D-CAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8e1107ff-0754-414c-97ec-8780ca51dbcf	3-D Cardioid	\N	3-D Cardioid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
efeb11fb-0e7c-4602-851d-b1790a16a3e8	3DCellPhase-	\N	3DCellPhase-		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae8cecf6-1219-4ebe-841e-681a84eb9e32	3D Cer-Met	\N	3D Cer-Met		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
55d17ea4-dbd8-4791-8a67-034ecda99968	3Dcis	\N	3Dcis		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0d65102-7825-4160-aaa9-65a77d5ad53c	3D-COFORM	\N	3D-COFORM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3cbac1ab-7cef-482e-9e9b-0c68cef7819a	3D-COMPETE	\N	3D-COMPETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2458f8d2-ea96-4a3d-ae5e-9a1bea4665b2	3DCOMPLETE	\N	3DCOMPLETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
93d94886-2a36-40c3-a2fb-1790a343d080	3DConfigurator	\N	3DConfigurator		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78579091-a167-41d9-9362-27e13926dc3f	3DCONTACT	\N	3DCONTACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9937116-7bbd-4e21-b6a7-1792d4f5b4a2	3Dconvert	\N	3Dconvert		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6579e730-340e-423c-9d62-62a3ae592329	3D-COUNT	\N	3D-COUNT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3ce28fa-28f8-4362-a9e7-6bdfea551938	3D-DERMAL	\N	3D-DERMAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9abee911-e25f-4a85-b674-a22d4ad3a23b	3D-E	\N	3D-E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a8c021c-fd73-4a52-b350-10a5ec6fb781	3DEpi	\N	3DEpi		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
967b79ac-290d-4f20-8da1-c7d9fccfeb78	3DEPLAN	\N	3DEPLAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2547b691-d263-41b1-92eb-6f93edb277c6	3D-FABRIC	\N	3D-FABRIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28075358-0256-4975-ac67-fb4e7adbbac8	3D-FIREFLUC	\N	3D-FIREFLUC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32bef480-7999-45b0-90c1-0ab35423ea3d	3DFIRELAB	\N	3DFIRELAB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9326c40f-6da8-4ad8-b69f-dc2608290b67	3DFlameGT	\N	3DFlameGT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc7f4a57-513b-4487-b1e8-bff794061c76	3D-FM	\N	3D-FM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
693cb5c6-9328-4d76-a7d6-b29ca8efd31b	3D-FNPWriting	\N	3D-FNPWriting		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2172f8e8-46d8-4f89-b686-a42d20055c3d	3D-FOGROD	\N	3D-FOGROD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7634a597-ff8b-4022-8f0a-ed8411a4ffaa	3D-FORENSICS	\N	3D-FORENSICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f6f6d24e-2676-4221-8242-7f0985229e35	3D-Forensics/FTI	\N	3D-Forensics/FTI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9a217f1f-a941-4043-810d-de0239dd8ccb	3DFOSSILDIET	\N	3DFOSSILDIET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e686edb8-8b9e-49a0-97da-cf345f4fa07f	3DFSE	\N	3DFSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
622af0a4-7adf-4bc9-8847-6e6f6b32c0dd	3D-GATED	\N	3D-GATED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a58ae4cb-bd87-48c6-bded-04f921b8ea87	3D GENE SHAPE	\N	3D GENE SHAPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
752e8694-768a-45bc-ac03-b5618a9c4397	3D Genome Dynamics	\N	3D Genome Dynamics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed8cff36-da2e-4443-8106-2365b059d8fc	3DGUIDE	\N	3DGUIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80af6d91-49d4-4c62-afd4-712075534207	3D HCS imaging	\N	3D HCS imaging		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e80495e5-abfd-4e62-aaa5-68f48cec2708	3D-HIPMAS	\N	3D-HIPMAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f9c06b9-b732-4865-8b30-80039d685b52	3D HMEC-MT-TIP	\N	3D HMEC-MT-TIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4c3dd2ba-7036-4b51-8ae8-6650af0d19fe	3DHumanSpinalCord	\N	3DHumanSpinalCord		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae496af0-b9d4-4875-9a53-2164c20c9e86	3DICE	\N	3DICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c99a2b4-e9bd-4570-8a71-4a43ccbf3b45	3DIMAGE	\N	3DIMAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b62ffe49-c6c8-4fb7-b7fc-f497d208d045	3DInAction	\N	3DInAction		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4e11b336-aec2-4e47-9fff-22a68dbc7f53	3D-In-Macro	\N	3D-In-Macro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f24a8e16-5fd8-4cb4-9e84-a34823bc147e	3DINVITRONPC	\N	3DINVITRONPC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60efb245-8f7c-43de-b482-40b2019436ae	3DIS-NN	\N	3DIS-NN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9d04fd8-ff02-4f50-9dc5-032b8eb3ad04	3D-JOINT	\N	3D-JOINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
609fb85c-24f1-44e2-9cf4-ea25b705ef4c	3DKF	\N	3DKF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e68ad22d-5429-4ce5-af8d-2417d4512d75	3D-LEAP	\N	3D-LEAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f7810bf-019e-4fb1-9fff-a764f55e37e7	3DLENS	\N	3DLENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d36773b-3f26-47e4-a2c1-a5944ec79670	3DLife	\N	3DLife		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
914e4462-8bc3-4251-8858-f21543647474	3D-LIGHTTRANS	\N	3D-LIGHTTRANS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
887f2a60-4de8-4145-9dd0-019ad2b89492	3D-LIVE	\N	3D-LIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f295d51e-0b46-4071-98c4-0e76e79388e4	3D-loop	\N	3D-loop		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a45b9463-1385-46c0-9550-d4aa71f01fb5	3DLT	\N	3DLT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5666f387-2033-49df-a53d-7e41365ad515	3D MAGiC	\N	3D MAGiC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
25d01681-f905-48d3-a294-5f895076e210	3DMAGNANOW	\N	3DMAGNANOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf5f3f75-ca65-4b87-b722-d8d45339e299	3D-Maps	\N	3D-Maps		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
91e203ce-2160-4662-ac1b-dcd48399852d	3D-MASSOMICS	\N	3D-MASSOMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30494cbc-b566-4003-8e94-2aca1983345f	3Dmaterials4Energy	\N	3Dmaterials4Energy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a8deabd3-f971-4794-b742-170bc4552b31	3D-MIFS	\N	3D-MIFS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
638e266d-c97d-4144-b3af-5eb2c09fc9f8	3DMIG	\N	3DMIG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86ffb8a5-d86c-4cbe-bf2c-5bb09c78b9e9	3DMOSHBOND	\N	3DMOSHBOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
492d7539-d546-4b6f-9f4a-1908fc451278	3DMP	\N	3DMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86b24c8d-60ec-42a7-9a93-9d6d110d676e	3DMUCHO	\N	3DMUCHO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce48fea7-e58d-4f7b-9cd1-de39d1f2c386	3DMULTICAT	\N	3DMULTICAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
53f2b188-4007-4270-a81d-4be62c4626e3	3D Multicell Growth	\N	3D Multicell Growth		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cbec3b6-7b6a-4702-b9da-2a715a60c9b0	3D Multiscale Model	\N	3D Multiscale Model		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7a641e3-2fc4-43d3-bac1-446395e3dd53	3D-MUSE	\N	3D-MUSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
40fe4f51-a35b-49ad-8a77-49e26983c0f3	3D-NANOBIODEVICE	\N	3D-NANOBIODEVICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
38c66631-58bc-40f0-9114-c21e3b0d6973	3D NANOCHEMISCOPE	\N	3D NANOCHEMISCOPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
970cac68-6446-4326-9905-c8af8af4a5a8	3D-NANOFOOD	\N	3D-NANOFOOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba63df9b-7fa1-435b-aab3-d888282dbaf3	3DNANOMAG	\N	3DNANOMAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1db9c7c6-dfab-4f20-9c64-122626f3104c	3DNANOMECH	\N	3DNANOMECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fec8d4a3-2f0e-4ab0-8a82-9146cd808436	3D-nanoMorph	\N	3D-nanoMorph		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c77e7ebd-b0dc-461a-a1ec-0cd120a915e7	3DNCPM	\N	3DNCPM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4f1730f8-bb7a-4325-a778-d54f45bbe830	3D NEONET	\N	3D NEONET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0111a677-370f-44d7-a81a-46bbe050de4e	3DNET	\N	3DNET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f23049f0-a20a-49b8-a72e-5246071da5a0	3DNeuroN	\N	3DNeuroN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
595477a4-e6dd-4319-acfa-53e8d8e2ac01	3D NKCC1	\N	3D NKCC1		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7fb663ac-c589-42fe-9f5f-fb7af48b8707	3D NOAM	\N	3D NOAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d493b3f4-f697-47dc-b58f-f8eb8fcd38ae	3DNSBT	\N	3DNSBT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cced354c-655a-4f60-b169-064be6731003	3D-OA-HISTO	\N	3D-OA-HISTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aef0494c-406f-40da-a0e7-acbacd522727	3D-omics	\N	3D-omics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37e4efaf-ba4b-48f2-bdda-8c010a3fa95e	3DPartForm	\N	3DPartForm		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6715c49a-4581-4151-a775-f40cb0f31822	3DPBio	\N	3DPBio		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f92803fb-ae73-4497-99a7-d819e76c4d61	3DPD	\N	3DPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
43e564de-4244-4e6e-9cf6-92c7e6d64b6b	3DPHONE	\N	3DPHONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3a346898-e815-4fb0-abc7-8f2000c2a590	3DPILcat	\N	3DPILcat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cfb00e2-d086-4fbc-afb3-7f5619ae8280	3D-PITOTI	\N	3D-PITOTI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
984533da-a74d-4e8d-b121-3f47cd59a4f3	3D-PIV	\N	3D-PIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b55f9445-9be4-4801-a2cc-3188732fea55	3D-Plant2Cells	\N	3D-Plant2Cells		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cbb43649-4f90-4a5f-a40c-4a8fe3694025	3DPLASTICITY	\N	3DPLASTICITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b91ac9cf-992c-4223-870c-4c102f0fa13d	3D-POWER	\N	3D-POWER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad3f5302-009c-458f-8b52-d45185182121	3DPresence	\N	3DPresence		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6678577d-bc50-4a72-a8f8-55faf654af13	3D-PRESS	\N	3D-PRESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
519f478d-4695-45a3-959f-07668244d317	3DPRINTEDOPTICS	\N	3DPRINTEDOPTICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5687445c-1ffb-4acc-a002-278361bffb62	3D - PRINTGRAPH	\N	3D - PRINTGRAPH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a9ead17-605b-41b2-a4ea-502ddba8b7ad	3DPRINT-VASCU-CHIP	\N	3DPRINT-VASCU-CHIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
45c9695a-744b-43b1-874d-a42ba2336b06	3DPROPLYDS	\N	3DPROPLYDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1916939d-b695-4936-95fb-a9da77eff894	3DProSeed	\N	3DProSeed		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cc0eac03-5d2a-4493-a3f5-5646a8521abb	3DPROTEINPUZZLES	\N	3DPROTEINPUZZLES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be5a91ae-e35f-40ee-a165-bf148d894a77	3D-PXM	\N	3D-PXM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
566f1cb4-9199-4f72-a758-74c4a1e6973d	3DQDOTS	\N	3DQDOTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
83fc5825-efd9-4b72-b532-40c223abdeb0	3DQuant	\N	3DQuant		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1706c2c-e5de-4cc3-9a90-9adf71054cb5	3DQUANTGRAV	\N	3DQUANTGRAV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
66c82fd0-ceef-4754-9058-e281d0d6dcd3	3D-QUEST	\N	3D-QUEST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f9d3aa6e-beb4-416b-875b-575684036547	3D Reloaded	\N	3D Reloaded		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b834b0b5-47e4-43ff-824e-bc812b911823	3D-REPAIR	\N	3D-REPAIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e62e7ab3-3a92-4e48-8ea7-5ae3e303eba7	3D-REVOLUTION	\N	3D-REVOLUTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7ec913f8-9187-474b-9d4f-9315a73d2cd4	3DRM	\N	3DRM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a8dc481-dddf-45ea-aed0-085608f816d9	3D-Roving Deposition	\N	3D-Roving Deposition		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c00bcb4-48af-4022-8f3d-d0e0161c4804	3D RZP	\N	3D RZP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eede3da3-fb66-478a-a066-30489b3ae009	3DSCAN	\N	3DSCAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
155846f1-f073-42a0-b90a-bba1622bda98	3DScavengers	\N	3DScavengers		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6543153a-267e-4f11-80c2-18a8d2623c2b	3D-SE	\N	3D-SE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a85cbdd4-fcca-4b71-9563-6a23010aa75c	3D-SITS	\N	3D-SITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3771e4c7-3d12-419e-8ccb-b6dfa2115fd1	3D-SMoHC	\N	3D-SMoHC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2ac6f34-920c-45b5-8006-503935de6eb8	3DSPIN	\N	3DSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ad9706e-14a7-40b0-97a7-710c99029b47	3DSSS	\N	3DSSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
99566710-43e5-4c01-9161-f372365a68eb	3DSTAR	\N	3DSTAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
036cd367-452b-4602-a98d-3e63c0a2c9ce	3D SWARMING	\N	3D SWARMING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa882bb5-c33d-419a-93fa-b994eeddde1a	3DTransducers	\N	3DTransducers		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e870b0f8-853f-4785-9df3-2358f43e5926	3DTRAY	\N	3DTRAY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a8e1a2c6-946d-455b-9d5d-f60074df934a	3D_Tryps	\N	3D_Tryps		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
db5ccfd4-fe5a-4062-8640-d2d14bac74f0	3DTTool	\N	3DTTool		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
754e4665-d8ed-437e-b40c-b25715fa3fe3	3D Tune-In	\N	3D Tune-In		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3a50b0b5-dd3a-425c-8dff-cd2801b0907b	3DTVS	\N	3DTVS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3d62d520-2713-4da2-afbe-0799e5d26aca	3DUNDERWORLD	\N	3DUNDERWORLD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
72d6ac09-ee4d-404c-929d-6cbd1b3fd370	3DV	\N	3DV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5bc4e8be-4ced-4421-9203-6cff71150484	3DVasCMD	\N	3DVasCMD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
801ede42-0168-4c20-bc80-570966fd3a0d	3D-VIEW	\N	3D-VIEW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f3a1425-b0b3-48ad-8926-8569340b55c6	3DviralRNA	\N	3DviralRNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
98d83f04-7d24-4681-be90-1a29b48294eb	3D VIVANT	\N	3D VIVANT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35c2a693-e6da-4445-b76e-f838fac1df94	3DWATERWAVES	\N	3DWATERWAVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e76b4d73-247c-4a22-9cec-0fbf55682bdd	3DWISE	\N	3DWISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4bb36281-464c-4b32-9ed0-1189acfbce85	3DX-FLASH	\N	3DX-FLASH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9dca284b-a72b-4dd3-8f21-63e26bf2198c	3D-Xist	\N	3D-Xist		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
27d8cc1e-a331-4bae-a71e-fad0e9761c24	3DX-LIGHT	\N	3DX-LIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fae41974-0779-41d1-9950-947687b32d54	3DZZI	\N	3DZZI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3da52a00-060c-4e7a-8348-1672fc772ffd	3E	\N	3E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
384fdcc4-4ab5-4567-815c-082beae106e5	3eFERRO	\N	3eFERRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b6fb40b-6550-4c99-acb2-6bada449f56e	3EMOTION	\N	3EMOTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eb267b6d-e4c6-449c-9418-fc6d8c3205e4	3ENCULT	\N	3ENCULT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
151a2ad6-debc-404d-a84c-47d6a566dca6	3F-FutureFreshFruit	\N	3F-FutureFreshFruit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
95e0cb4c-8b86-45ad-813a-d8e551695372	3FLEX	\N	3FLEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c9b34eb-101d-4f0a-80f4-173dff209b1e	3GB-TEST	\N	3GB-TEST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a41af6ee-aca2-4eb8-a32e-c87572336fbc	3H-ADC	\N	3H-ADC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
832aaa92-9878-4bc3-8440-5d5e5e1d9b63	3IBS	\N	3IBS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eaf223d4-afff-4f71-9be1-cf3db4cbb0d5	3-i ICT	\N	3-i ICT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
75ad1338-870f-4096-92e8-a640d98c324d	3ITD	\N	3ITD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7415c1d1-bda6-4da9-a629-7a4d4bfef832	3L-HeCoMe	\N	3L-HeCoMe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3fb22b3f-244f-4e84-94d5-a35de57696bb	3MC	\N	3MC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d8db42c-5da7-4ac5-91bf-dea5b1bb800f	3MICRON	\N	3MICRON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
03856c4f-e0ad-4d53-ab7e-1420d67372fe	3PEAT	\N	3PEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
752ba750-e69a-450c-8035-46749c6a8b8f	3PLAST	\N	3PLAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e681ffa2-4a29-4895-b076-109ccb0d7ee9	3Ps	\N	3Ps		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
27dab802-0442-4222-b3c9-004acdc6b15f	3rd HAND	\N	3rd HAND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2a1258b9-de34-4b38-886a-610eeba03392	3S	\N	3S		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4ad83c81-cf7c-4ae6-8e72-728c6fba00c7	3S-BTMUC	\N	3S-BTMUC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a390fe1-9c09-474f-9c6c-ccfb3239b418	3SMP	\N	3SMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d707d886-ddd4-4f8d-925d-8ae7ef76fe7e	3SPIN	\N	3SPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16b81b1c-c68e-4f39-baa4-4d2aed0e2218	3SR	\N	3SR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29fbd31b-7fe4-4558-b2f1-dc0c4752edfe	3SST2015	\N	3SST2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
68474de2-24c1-4ff8-9f97-eb3e3a238c34	3STARS	\N	3STARS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4603aa9f-c3e4-4363-bb31-8540f9bf3b26	3TANIUM	\N	3TANIUM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
34f5eb4a-dd35-4545-bced-262d32cb69ea	3TO4	\N	3TO4		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d48d2142-e956-45bd-972f-b4801b96d863	3-TOP	\N	3-TOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
71e6f319-3dc5-4009-afb9-c3fd7b464730	3TR	\N	3TR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0577e1ca-d1a2-454c-bcc6-b6ac04fa24f7	3VAL	\N	3VAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
436d94a4-4c7b-45a3-83eb-354eff434177	3W-RGB	\N	3W-RGB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e437d5b2-fa28-481e-b112-86b75bf96407	3x3D Imaging	\N	3x3D Imaging		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f4813275-f356-4a60-80e8-7c96e7012a41	40CACQED	\N	40CACQED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc3b2b40-d2f1-4bf6-a327-539fcab20947	43CAQIP	\N	43CAQIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
514da167-2f19-43e3-90df-24095e70ad99	45HC.com	\N	45HC.com		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d055b039-6d8e-4997-b60b-7444e7b66121	4AirCRAFT	\N	4AirCRAFT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3936af5d-0d18-444d-bd75-035a0bb1ff26	4 ALL	\N	4 ALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
74fa7c2f-e1ed-4dca-8d41-ff3046e636fb	4C	\N	4C		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
98954d6e-2749-41cf-b91c-3444f75500b9	4CaaST	\N	4CaaST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
765f9c59-6308-4aeb-a4ff-38efd64283e2	4CB	\N	4CB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a6415045-522b-41e3-916b-5739d04b5e2c	4CH	\N	4CH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dd836bdb-bbaa-4b98-8730-f4699de94b78	4CWhite	\N	4CWhite		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dffec0fd-8766-4825-ba51-863c1b5da10f	4D	\N	4D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
04f075be-3b82-4dd6-982e-afe8f4772b8e	4D4F	\N	4D4F		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe2177e6-8b6c-4ad2-bee2-8eff0c9a90db	4D4Life	\N	4D4Life		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
781bdef1-3475-422f-9eac-9aab649c9fc1	4D-Biogel	\N	4D-Biogel		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa4786dc-bc7e-4209-9999-6782efffd1d5	4D-BIOMAP	\N	4D-BIOMAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aab7f85d-b374-4b17-b849-a47eec0cdae3	4DBIOSERS	\N	4DBIOSERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1bba10ba-18f5-415a-9953-ff2de471b015	4D-BOUNDARIES	\N	4D-BOUNDARIES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df36e19f-4d30-457c-8bb1-a07c8731f624	4DCELLFATE	\N	4DCELLFATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc20dc7d-efb1-401c-a3c5-14e39ca758ab	4D-CH-WORLD	\N	4D-CH-WORLD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b5e2e4fe-818e-430c-b03a-700aaa5986f3	4DCO-GC	\N	4DCO-GC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec00838c-b7c2-4b0f-a7ca-a3802ad988ae	4D-EEG	\N	4D-EEG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
890938e4-f8a3-4787-8a02-d8ecfb48ab0b	4D-GenEx	\N	4D-GenEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4aa7b503-41e9-4600-8670-386ec7056e56	4D-GENOME	\N	4D-GENOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
15667260-2097-44ae-864f-c77075c55ead	4DGenomeReg	\N	4DGenomeReg		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba747b2f-c199-4f4e-9da2-234659baadb3	4DHeart	\N	4DHeart		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b287572a-b645-4535-bb2e-790f59b5ca94	4D hybrid	\N	4D hybrid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ea9b3cf7-84b9-4b79-9cb4-112c706bb753	4D IMAGING	\N	4D IMAGING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
837e47ed-244c-42d7-933d-cc6e2bd44e9e	4D lipid phase	\N	4D lipid phase		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
299ee2ca-fff0-4f00-833b-245dfc123e27	4-D nanoSCOPE	\N	4-D nanoSCOPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
92f6fd82-0097-4521-ac36-18d2b33f5cd2	4D-PET	\N	4D-PET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b6ef6ca8-c110-4892-971c-698fb0e21300	4DPHOTON	\N	4DPHOTON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be600be2-276a-4bd9-8908-c4d22eea3864	4D-PhytoHybrid	\N	4D-PhytoHybrid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f0ce806-b2da-43bc-a32e-87299ec0aa4c	A2F2	\N	A2F2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa96a4d4-56de-4a09-bd1f-b256b76ace40	4D PICTURE	\N	4D PICTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b353d7f-38ca-477b-9ef4-732db9abfe1e	5G-MoNArch	\N	5G-MoNArch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bacf34bb-3a7a-4dd8-a65d-a833e317780f	4D-POLYSENSE	\N	4D-POLYSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
92773d35-4c73-412a-ae1d-10aa808146c1	4DPrintedHeart	\N	4DPrintedHeart		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a851ed76-a8fc-4500-a64e-22b24430f6fa	4D_REEF	\N	4D_REEF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d8005665-d5d4-40b2-872c-338577848bf4	4DRepLy	\N	4DRepLy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47b5bca2-7d6a-4b19-a651-fbca1ed76227	4D STENT	\N	4D STENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c5f44903-3fa4-46f9-ae31-bf258e80e661	4DVIDEO	\N	4DVIDEO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a693ef78-38a5-4a42-a4a3-0aaa017cffb6	4F4REJUVENGLIA	\N	4F4REJUVENGLIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
66800186-8362-4b76-881e-f59021fb2e49	4F CROPS	\N	4F CROPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2ec87516-de7d-4e2c-98ae-54542deee450	4f-Mag	\N	4f-Mag		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce74fe4e-b1c3-464a-a514-b26eabde7d6e	4FNANOMAG	\N	4FNANOMAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc6c8ee0-1f72-440b-b631-93020917eb32	4FOLD	\N	4FOLD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ee306fea-10fb-492e-bb04-9f1d9feabe6d	4FOLD Phase 2	\N	4FOLD Phase 2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2ea86403-18ad-450e-a082-4a3f76e3ad03	4FUN	\N	4FUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80130386-4e0a-4bae-bcff-b2bef0c73313	4Gen Light Aircraft	\N	4Gen Light Aircraft		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a86b2f77-b519-447f-9553-98856deecaa9	4G-PHOTOCAT	\N	4G-PHOTOCAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe1ade80-1531-4339-851d-cb7cede0c69c	4-IN THE LUNG RUN	\N	4-IN THE LUNG RUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37c3b7a1-8e80-49b4-bb41-0e1b35cd3bf1	4I-TRACTION	\N	4I-TRACTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e0c6847d-d693-4bae-a28f-70ca72097d1b	4lessCH4	\N	4lessCH4		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a9fa54d-021a-43a5-b04f-996d5b6ff188	4M	\N	4M		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c93787e8-7480-449a-8547-cb57b534d141	4M2020	\N	4M2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
64f663f1-a226-425d-b6f3-3cc6dcf1d541	4NEM	\N	4NEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e0ef0853-5314-4b76-a38e-c3a99fc46de2	4-OCEANS	\N	4-OCEANS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f576800-b3eb-49cc-b964-41e97f0af549	4PHOTON	\N	4PHOTON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
90e7ad96-55c7-4c8f-9ed5-643c3b5f27d5	4PI-SKY	\N	4PI-SKY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5a600f0b-354f-44b5-9721-1adc10a56d23	4PRIMA	\N	4PRIMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fadec1d2-01c8-4529-ae85-7ee5da84b581	4REFINERY	\N	4REFINERY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8891a7ff-28a8-4674-aa0b-88723055f61a	4RinEU	\N	4RinEU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8aec0e65-12f5-4bd7-ad63-46c70d4adfb5	4S	\N	4S		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5372af45-9eae-45e2-9bc2-576cdec222c7	4SBATT	\N	4SBATT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e2ea26e-bb74-4c49-9d21-08bcb482e006	4SBLOCK	\N	4SBLOCK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8ab4bd6-d322-4d81-aafa-7601749fd1bb	4SEAS	\N	4SEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b6c0774-27e1-4b11-841b-4c9d856570c7	4SECURAIL	\N	4SECURAIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
38925555-9af6-453a-8d79-3ef037e26f08	4SUNS	\N	4SUNS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
54b07c6d-dcf5-4828-a863-46f8a2fff7b4	4Sure	\N	4Sure		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
08bbadcd-c9ad-4ae5-bdb6-d3c04bb32d6f	4TH-NU-AVENUE	\N	4TH-NU-AVENUE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
34ee8adc-400c-4a1f-a3a0-1de7ec0d6276	4-TOPS	\N	4-TOPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
50b261d2-0c6d-4b5c-b547-c4f2cc658e9f	4U2Night	\N	4U2Night		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
38232738-560c-4610-8a78-1a0d7fe2d0df	4.UNCAN.eu	\N	4.UNCAN.eu		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e4311c41-36b1-46e6-8776-bde3d1a6d435	4WARD	\N	4WARD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
24a2b781-516a-47de-a5b2-0f373d6a0c20	5-Alive	\N	5-Alive		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d84a0128-9d43-43a9-a639-e521c5bff312	5COFM	\N	5COFM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f588d54-d829-4b95-b082-45f0bb955266	5CYRQOL	\N	5CYRQOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ba75d1e-bbab-45fe-9218-5d38700b7245	5D-AeroSafe	\N	5D-AeroSafe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f82e9d9d-bac2-42d9-acf9-9f7b91c87fa2	5D Heart Patch	\N	5D Heart Patch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2c7a71a5-3a55-4c93-9114-517695515960	AAASP	\N	AAASP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d7bd2c4a-6f28-4547-a34c-23dd11b6e981	5D NanoPrinting	\N	5D NanoPrinting		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52cffbd6-6d88-4493-8d58-9effaee58e64	5D-NanoTrack	\N	5D-NanoTrack		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
14be4bff-1164-4530-be5c-8a41b8e50d4d	5E	\N	5E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
24157899-686f-4c75-9dad-7459781bf4a1	5-FU PGX	\N	5-FU PGX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa3badc7-3c19-4203-bf43-ccec1290098e	5GaaS	\N	5GaaS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39194ba9-0d6e-48fe-9e23-9ac68e43530d	5G-ACE	\N	5G-ACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
963e052c-dfe1-4cec-a56d-c2b7e97592ba	5G-ALLSTAR	\N	5G-ALLSTAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dcb3db57-50ae-4820-bfae-805332d3b03f	5GASP	\N	5GASP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
371e4953-38b3-4e4e-aaa1-c7ae0ec1d3f2	5G-AURA	\N	5G-AURA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f4e0258-35e2-4f54-ad2e-957e136cd14f	5G-Blueprint	\N	5G-Blueprint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
926a6f6f-f3d7-4eb8-88e4-81d6ada7a937	5GCAR	\N	5GCAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c05f90c4-d8ab-4d6e-aeae-09c7bc45e7ce	5G-CARMEN	\N	5G-CARMEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f6cc3a5d-8ad0-41df-8a72-66fb42412c8b	5G CHAMPION	\N	5G CHAMPION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bd776ed-15a7-4806-a2d0-c67ab08a891c	5GCITY	\N	5GCITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4cc538cb-1a78-4d25-9970-1df482bc2419	5G-CLARITY	\N	5G-CLARITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
de482b3b-8ec1-468b-bf6b-8ca765554732	5G-COMPLETE	\N	5G-COMPLETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3d037c1-2f2a-4e9d-b629-8665e2c08816	5G CONNI	\N	5G CONNI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b433a9cf-f0dd-401c-aaba-75485752df1f	5G-CORAL	\N	5G-CORAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0dd123f9-2f02-480d-8f11-44647cf76376	5GCroCo	\N	5GCroCo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f3216a5-cefc-4f28-8b79-cb1e4e54e93e	5G-Crosshaul	\N	5G-Crosshaul		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c335538d-6fcc-46ad-a0f6-3e60f9bed19b	5G-DIVE	\N	5G-DIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
92a60fbc-193d-4732-a1b6-d67d08cd926b	5G-DRIVE	\N	5G-DRIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9d16e2ce-2d98-4cd0-9cfe-b8600aa89a6f	5G!Drones	\N	5G!Drones		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ffe7f7b-4632-4737-becd-e7142f2a1ba1	5GENESIS	\N	5GENESIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35b4f4c0-7644-4166-9d47-eec80847a1d7	5G-Enhance	\N	5G-Enhance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29afe89c-112f-424c-8f5b-9ecd14a9a27e	5G-ENSURE	\N	5G-ENSURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
83b7d1e1-c761-4ef3-990c-b4b05148d815	5G-EPICENTRE	\N	5G-EPICENTRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5a5cacc2-5fe9-4347-8dde-1417bbba628b	5G-ERA	\N	5G-ERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d79e097-9886-45e0-858c-aa65fc913687	5G ESSENCE	\N	5G ESSENCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85de2dc0-7592-4fe5-ab50-8537aed634db	5G EVE	\N	5G EVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32f96c35-8e8b-47b5-80cb-81dcfaf7000c	5GEx	\N	5GEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c97a16c-3c27-436b-be4c-a840660c5fd8	5G_GaN2	\N	5G_GaN2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b9fbe73-cb01-4b11-a2d2-c8a3bef40621	5G-HEART	\N	5G-HEART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf105095-d814-46bf-bcf9-663dccc1987c	5GhOSTS	\N	5GhOSTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ca17de78-5105-49d8-8509-1511457a090f	5G-IANA	\N	5G-IANA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cc99d0b6-cfc5-4ac9-8b0a-44679aac6cd4	5G-INDUCE	\N	5G-INDUCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cd70243b-5c18-4631-8f4b-f5551e6d70b9	5GINFIRE	\N	5GINFIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7fab377-a6e5-4c7d-8cb7-27989ecfe998	5G-LOGINNOV	\N	5G-LOGINNOV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f4aa0ea6-c5aa-48b4-baf6-c01b946e135c	5GMED	\N	5GMED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
15a6ad10-5745-4b6f-9bb8-e6814fb772b1	5G-MEDIA	\N	5G-MEDIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc703d8e-ac19-44ab-ae5e-a47d61bb23b1	5GMediaHUB	\N	5GMediaHUB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3de6383a-ebb2-441b-a35d-2585f88c8d15	5GMETA	\N	5GMETA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58de9b49-c538-422d-bebb-988c97599b12	5G MiEdge	\N	5G MiEdge		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0069a0ba-3e65-497b-a2a1-3cde7b13e4d2	5G-MOBIX	\N	5G-MOBIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6fa123fc-0254-4561-9c85-32dd80d5a702	5G NORMA	\N	5G NORMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2873d61e-2d06-42a0-a280-c8a69ace063c	5GNOW	\N	5GNOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ecaa40cb-cc8d-4ca1-8253-40aaa49b5d2e	5GPagoda	\N	5GPagoda		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42638878-1720-4696-a3a9-229ae54c6b55	5G-PHOS	\N	5G-PHOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1b13dcf-768f-4049-9296-127b010ba17f	5G-PICTURE	\N	5G-PICTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
72e1fa20-ec5c-4e93-b046-0a5b4b7f8a16	5GRAIL	\N	5GRAIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d25ed213-a722-4bc4-8599-6655893a5299	5GRANGE	\N	5GRANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52eada7f-48f9-4906-a4e8-60aeaa6dba6e	5G-RECORDS	\N	5G-RECORDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9cf4cb0d-3041-4714-ae2f-4baafcc7193a	5G-ROUTES	\N	5G-ROUTES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
08c4db59-38d5-4108-a08e-ce63755659b0	5GROWTH	\N	5GROWTH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35ee7213-df62-475a-b788-f9ea40d1aaa8	5G-SMART	\N	5G-SMART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa94bfa3-be5f-4078-951f-f45f6861c285	5GSmartFact	\N	5GSmartFact		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be7f74b8-1c95-4d7c-8cef-a446e20c699f	5GSOLAR	\N	5GSOLAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
95fb5682-a5bc-40c5-8f2b-734fd8b171de	5G-SOLUTIONS	\N	5G-SOLUTIONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0150abaa-f9ed-4867-afa6-be83455bf479	5G STEP FWD	\N	5G STEP FWD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35f8e7c4-c953-42a6-8018-c6cd8d97a86e	5GTANGO	\N	5GTANGO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa4f64eb-38ea-49bb-8151-ae0ffd33f4df	5G-TIMBER	\N	5G-TIMBER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a9c06850-cf2f-46ea-9103-ae1bf6435041	5G-TOURS	\N	5G-TOURS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6caa97e6-ffe2-4233-96ba-88b5a8eb0fa4	5GTRACK	\N	5GTRACK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37187422-ada7-457c-8048-580df600a60e	5G-TRAIN	\N	5G-TRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f1c771ef-b8a1-487c-85c3-443ab243dcc9	5G-TRANSFORMER	\N	5G-TRANSFORMER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a1ff6663-7a31-45fb-a00a-d90a16c2fb65	5G-VICTORI	\N	5G-VICTORI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
925a6d1b-9b3f-4a9b-a153-7da9ab93794d	5G-VINNI	\N	5G-VINNI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
12907b14-ec36-40a6-bf87-cd4391759df7	5G Wireless	\N	5G Wireless		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
68e3dbcb-96f1-4259-801b-5d4b55705fc5	5G-Xcast	\N	5G-Xcast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
935fefec-723d-46e0-97b9-6a4f74975e19	5G-XHaul	\N	5G-XHaul		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3cd28069-63ea-4059-82b0-54548c1d8cfc	5GZORRO	\N	5GZORRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5344c2f2-28ef-4e30-a76b-35e803db73f3	5HTCircuits	\N	5HTCircuits		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2e021190-d684-4125-b892-d6d43dd1c115	5HT-DREADD	\N	5HT-DREADD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cde728ba-182a-4ff0-9c5a-ef948278ef76	5HT-OPTOGENETICS	\N	5HT-OPTOGENETICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
efdffc75-d276-478e-b233-f1c2cc353a39	5-HT Radiotracers	\N	5-HT Radiotracers		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4881d20c-dd3a-46ed-adf4-ba8e584fd1c6	5 LIVES	\N	5 LIVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f46d89aa-d9c6-4339-b5c6-116248f4152d	5TOI_4EWAS	\N	5TOI_4EWAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
443c84d2-fc63-4f2c-934e-e4897bfd4245	6CHOICE	\N	6CHOICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8067449a-4356-42f0-847e-3db9edac8446	6DEPLOY	\N	6DEPLOY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20cd336f-6b07-4fdd-9e9a-8a177e30eb4b	6DEPLOY-2	\N	6DEPLOY-2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7417a358-9212-47a3-ba8b-79cfe95a8f53	6D STRINGS	\N	6D STRINGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a58cc4f-20f1-47bd-8d9e-20c332cb2b7e	6G BRAINS	\N	6G BRAINS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e74a5924-1f1c-4e2b-bd58-48a52ea738b7	6G Channel Coding	\N	6G Channel Coding		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2f58b42-3264-4712-b322-2113e3c83f60	6GStart	\N	6GStart		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b7d8389e-69cb-4c4f-b4c3-be8c94261fec	6i-DIRS	\N	6i-DIRS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c104bed1-f1a0-4a23-8c7f-a8f45a02a50e	6-SENSE	\N	6-SENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
83efdc11-6b57-4d6d-83a2-4fd2fbfca60a	720IEQ	\N	720IEQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1e5857f9-aea3-4b7f-acb6-bda976f41ceb	79GHz	\N	79GHz		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2830805e-f2e2-416e-97f2-9d4aec4cf3ca	7DUP	\N	7DUP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e70ba742-649c-456f-b852-e68d109e4826	7MW-WEC-BY-11	\N	7MW-WEC-BY-11		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f8ab510-5b38-477a-8f90-4864e18160c8	7SHIELD	\N	7SHIELD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a47a3b5-0ad4-47e4-9763-20b1b93643c2	7TReImHo	\N	7TReImHo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
12cbbf38-fb55-49a0-a537-ae1986084204	80Days	\N	80Days		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0d10233f-9c18-4d49-bc7d-ac1e6a6c76f8	9eGEN	\N	9eGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ef020380-d84a-4718-9300-41444c8fcebd	9 SALT	\N	9 SALT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a2b1e8b9-7925-4e56-8d94-175d88d5d68b	A20APOPTOSIS	\N	A20APOPTOSIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1c0693a-5596-417f-8cc9-7ed3e90f825a	A20 DC SUBSETS	\N	A20 DC SUBSETS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1147f23e-523e-4217-80be-89731bb9ed29	A20 IN ALLERGY	\N	A20 IN ALLERGY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6e2c4057-9b74-442f-adb0-f39fdfd712bc	A2C2	\N	A2C2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
01f76bb1-bcc7-455f-98bd-b63f9945d766	A2CM	\N	A2CM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4dd1d6eb-bff0-4466-9138-27bc3fdbafa5	A2F Conference	\N	A2F Conference		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9965404e-ea40-4751-a782-4f86cbbf3a56	A2M2TECH	\N	A2M2TECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1273f20d-0abc-4cbb-9d83-f5915e4dcebf	A2Miro	\N	A2Miro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb9193a0-7998-46b2-ab48-4b343b8ca871	A2MIRO	\N	A2MIRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1bf25d08-9ddc-4cc0-8cd0-751e7a9c6037	A2MStools	\N	A2MStools		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31591dc0-8bf0-4859-b541-719ab4a0c3ba	A2-NET-TEAM	\N	A2-NET-TEAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28cb98a0-e6c0-4702-8db2-b3c7a9a83f1c	A2PBEER	\N	A2PBEER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a133c50f-bfd6-4990-97ba-123109f7a118	A3	\N	A3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aebb185b-5a6f-4f42-8914-aa59a6e14f7d	A3BL	\N	A3BL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc16747a-2205-482d-8d01-c494ef0d0a17	A3R	\N	A3R		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
92d5afeb-913b-4076-a4c0-3d19de43ef5f	A4A	\N	A4A		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4cacccb8-92db-47a8-a763-8113031fd9ec	A4B	\N	A4B		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8b9a1a5e-6720-4eb0-a162-bc09a14af254	A4BLUE	\N	A4BLUE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78a3851f-6b14-4866-ba53-f54d7637b46e	A4CLOUD	\N	A4CLOUD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39651167-40e0-4822-960f-daf74f688442	A4L_ACTIONS	\N	A4L_ACTIONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
62f2b99c-4da6-4f4d-9e9c-c2868eb7ae78	AA	\N	AA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9e88b411-20f2-4f8a-abc5-57d6ef3cb111	AAA	\N	AAA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2816bc6-010e-4785-81dd-d83d9d0920c0	AAA+LON	\N	AAA+LON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
51ea02e3-c2da-4ac6-ad20-fecfe85dbdaf	AAA-PREVENT	\N	AAA-PREVENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6ea778b3-f9ae-48ac-9cbd-c915ef108960	AAATSI	\N	AAATSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1c07d9b-de32-467f-afaa-75b5ab324127	AAC	\N	AAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1e1fdc06-945a-411e-91fe-ccc88765e8d2	AACCT	\N	AACCT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
79e40382-868c-4d6f-ae94-fa734318bd14	AaDAMS	\N	AaDAMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
45c4ea56-3b12-40bd-a4f6-cbe59ff9b933	AAL2	\N	AAL2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4816b354-775a-4f58-942f-5c0db3970730	AALIANCE	\N	AALIANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32fa6904-6554-4bf4-a9b0-0c670ebd24d1	AALIANCE2	\N	AALIANCE2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ad0124e-35d3-4f6f-9ff0-dadd24f50e4a	AAMDDR	\N	AAMDDR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b3a6013-2b4f-4174-9dc0-810c9f801108	AAMOT	\N	AAMOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
283cdb1a-5326-4b80-8fcb-96a023852c81	AANChOR	\N	AANChOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b2aa4f1b-504d-451a-8b52-b02e4c4cf5a0	AAPD	\N	AAPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6ccb417e-52ac-4899-9066-caf567644fc6	AAPLQIC	\N	AAPLQIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9585770a-e1ea-4c8f-a592-1eeaa979842a	AARC	\N	AARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e35e279-3a9d-425c-bf68-95b4e2269b19	AARC2	\N	AARC2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f1689b4c-476b-4818-9167-99eb44306ae9	AAREA	\N	AAREA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a36be1eb-fcf1-4a8b-80f6-7c2da1637533	AARN	\N	AARN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0604aadc-b979-4791-b529-4f57cb4714e4	ADA	\N	ADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e2cea07-e147-4e1a-b6c3-e005ac31f352	AArteMIS	\N	AArteMIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b7b5a5dd-d7ef-497a-b1d2-417e5e142667	AARTFAAC	\N	AARTFAAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4f5eee42-7649-44cc-9c19-74dbf808ee5b	AAS	\N	AAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f80d113-e591-41ac-9839-f4504e528a3e	AAT	\N	AAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
565fc537-9a94-499e-a5fb-7291ec156c71	AAT-NAA	\N	AAT-NAA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6b37798d-702f-4b33-b20a-8c9800c4962b	AAVEYE	\N	AAVEYE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e61168cb-bdc3-423c-8ba2-a12e661e1714	AAV-FACTORY	\N	AAV-FACTORY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
50459c45-9b28-4317-86ad-d33712823018	AB4Rail	\N	AB4Rail		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e8904294-3701-45a2-a5a6-9afd8474b2ee	ABACCR	\N	ABACCR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bca38be4-13e2-4b4d-bd7c-67cefbddfea1	ABACUS	\N	ABACUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
84e67e07-d1e4-4e4a-93f8-6ec50df1efd7	ABAG	\N	ABAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
64c82f8d-24b7-4dbc-b0c9-737093860930	ABA-GrowthBalance	\N	ABA-GrowthBalance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dd25b899-79c3-436e-8b11-4d2b0c114e25	A-BAM	\N	A-BAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33f2eb11-61c3-4d83-9f23-02013b85ce4a	ABANDONMENT	\N	ABANDONMENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
853976af-031f-4214-bfe1-d1cea42c3eec	ABASynth	\N	ABASynth		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e017d758-e18f-4954-ab3d-ee1d87754d99	ABATSYNAPSE	\N	ABATSYNAPSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ee5973a-c798-4844-8bf9-8ec398e8f07f	ABBI	\N	ABBI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bfd9b7b3-576f-4c00-bf07-15342af7696a	ABC	\N	ABC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
adf1ac39-3867-481c-b155-cbf741d067fc	ABC 21	\N	ABC 21		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26638caf-f11c-4636-b989-39783c242e96	ABC4EU	\N	ABC4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9f52eb0-e15d-4829-b086-be0c57c95c2f	ABC4Trust	\N	ABC4Trust		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
efe6ffd0-610f-41e8-bf9a-a1b2459bee87	ABCDE	\N	ABCDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dd2f0f68-5509-4dc5-a4cf-96cc2e53d24a	A-B-C-Deep	\N	A-B-C-Deep		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3604957e-7ed8-4969-b46b-9d0906710892	abcdeSIM-VR	\N	abcdeSIM-VR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5bcfb81d-3507-482e-9ad9-395a15455eeb	ABC DJ	\N	ABC DJ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dab7fa2f-4fbb-4b5c-aade-c75e42826026	ABC-EU-XVA	\N	ABC-EU-XVA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7da368dd-21f5-4c34-8201-c73dd443abb8	ABCIT	\N	ABCIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b930ed5-ff56-418f-9dcf-f2db193fb5e2	ABC-S	\N	ABC-S		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2fa47842-0668-46eb-af64-e50e8780b1c0	ABC-SALT	\N	ABC-SALT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0977ffa6-01d3-48d7-974a-3c0fc791ab88	ABCTRANSPORT	\N	ABCTRANSPORT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
269f0fd1-81a3-4c99-919e-e0e3e61b4803	ABC TRANSPORTER	\N	ABC TRANSPORTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f42280e2-c4b4-44f7-bc7d-ae3bbc912f03	AbCURE_COPD	\N	AbCURE_COPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e50e6780-8084-4051-a9d8-15247f070610	ABCvolume	\N	ABCvolume		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a211604f-afc9-49f7-9aee-e5270f928f8c	ABD	\N	ABD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f2e88c27-dca6-4a81-901e-766ceefae068	ABDES	\N	ABDES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
067c14c2-0154-4af2-acac-cfe6787051f4	ABDESIGN	\N	ABDESIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
735df2ba-61f6-4c26-960a-f43f0fdf2a7c	AB-DiRecT	\N	AB-DiRecT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f51b0745-4cf0-4cd1-8b96-729372428656	ABEL	\N	ABEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3072985c-a889-4ade-a7f0-912002e1ffc6	AB ENGINE	\N	AB ENGINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
79938042-c983-4eeb-87c7-90661e88757a	ABEP	\N	ABEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c19b5f5f-65fa-46d5-a9f3-43238e55350b	ABESTII	\N	ABESTII		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
98afbb12-a441-4b11-9eff-9333ebff6bce	ACM	\N	ACM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ff0d3f71-93c2-4099-a0ee-22e9e4a2d516	ABEST III	\N	ABEST III		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a5feef1-feb6-40ad-9129-6198d6ee98fb	Actsa	\N	Actsa		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2a3124ce-eb80-4f2d-bff0-d80ec5e6508a	ABETAALPHASYNTAU	\N	ABETAALPHASYNTAU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d9cdabd1-4550-4dd9-958d-385961ec3da7	ABETACOGNITION	\N	ABETACOGNITION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f2fe50d-75bf-4384-b65b-31011b08b33f	ABETAPRESYNASTRO	\N	ABETAPRESYNASTRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cb766e80-cb25-49f8-914e-fae4eef898e7	ABFT SNP	\N	ABFT SNP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0f917c84-18b3-4d98-b789-0c226a4055c1	ABIADA	\N	ABIADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f843e522-2227-4cac-922f-cb77bbd42a36	ABI Energy	\N	ABI Energy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
acf5b391-fa0c-4272-b5dd-8f2ca0c7e306	A-BINGOS	\N	A-BINGOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d8b71fd8-8109-4d15-8eff-7517f62ecdeb	AB INITIO	\N	AB INITIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a12a662-8330-4681-81cd-8e22683e82a9	ab initio and QMC	\N	ab initio and QMC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a063bcff-f571-443d-a931-df043325b656	ABINITIODGA	\N	ABINITIODGA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
97d86ef2-4a21-4d18-86d8-bcf2f00f8abe	ABIO	\N	ABIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a8ab8fe9-7a65-4efe-897f-af8cf69ee157	AbioEvo	\N	AbioEvo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e4b61bb-ac2c-42e8-81ea-b023073db513	ABIOMATER	\N	ABIOMATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
723acfe0-1a44-4a74-ad92-59eacb6be040	ABIONYS	\N	ABIONYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
752cc417-1a0f-4f59-9fc2-1d4ac7e72bc2	ABIOPES	\N	ABIOPES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
62d11a6f-5146-4c68-b2a2-50f64d771a1f	ABIOS	\N	ABIOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bfcc9f54-2ecd-4437-b7f3-75a1837e3f44	ABIRISK	\N	ABIRISK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1388052a-76f7-4126-ba22-27a16feddc4c	ABISSE	\N	ABISSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d14e06c2-95a8-4beb-a7b1-ff4db12a45a4	ABJM	\N	ABJM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e76ee3c6-d1ef-4bd0-97e0-e06f0399be46	ABLADE	\N	ABLADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c898dfae-765a-49ab-8398-1e4e96086dee	ABLAMOD	\N	ABLAMOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
76fcfbb5-c2f6-419f-8815-e8ff9fc1ec1d	ABLASE	\N	ABLASE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a90ee286-51bb-48a1-be80-3a75371f2461	ABLAVIEW	\N	ABLAVIEW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2213aa58-a388-4924-93b8-61606b9e170d	ABLE	\N	ABLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9893ed9f-d154-434c-a499-9da84cfdc98f	AbleGames	\N	AbleGames		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16b163e2-3cb0-48f1-9df1-f9f30d741a0f	ABODYFORCE	\N	ABODYFORCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
94afab59-4805-4428-99a8-7d1ee8c6e91b	ABOLED	\N	ABOLED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3c93a83-fe03-49e9-8358-f43f893d43ed	ABOPEN	\N	ABOPEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f9a35d4c-19d5-4f63-8866-d61b87a03f23	AboutFlow	\N	AboutFlow		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
030ece0b-646e-4dd8-904c-a32f9c5408c5	ABPP-PROTDRUG	\N	ABPP-PROTDRUG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e0285410-0fde-4ddb-92e6-b090c363b1d8	AB-Prevention	\N	AB-Prevention		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3d7b575-ad77-4655-90ad-5843618a75da	AbQuantumSpec	\N	AbQuantumSpec		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
897ee644-fb8a-4b04-8f38-4e86d6c76192	ABRACADABRA	\N	ABRACADABRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4bc4cf95-0d5b-4c2a-914f-918e9910227c	ABRAM	\N	ABRAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
154f415c-3541-46f2-b968-5788ec27f25a	AIR	\N	AIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a28c38a1-5961-4009-83f3-27784573374d	ABREM	\N	ABREM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42c4a0ea-d25e-4014-b52a-e131cfa7cd88	ABRIM	\N	ABRIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eea2eafd-8890-4315-99a1-3f0e8b7ac7f7	ABRSEIST	\N	ABRSEIST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a8e2971-24e5-4108-9093-36ab8c37ecb3	ABrucioli	\N	ABrucioli		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2249e690-8dd1-465d-abfd-4424f40e0b3c	ABRUPT	\N	ABRUPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8de39dd-2797-4c20-b382-8aacc817619e	ABSENS	\N	ABSENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4622efd3-e303-406f-94d3-605ea1585ffa	Absent Presences	\N	Absent Presences		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b7570713-fbb6-4b55-9ab2-1bdc3f2ef3d7	ABSHA	\N	ABSHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
38076e97-8df4-4bee-8ca6-945076888492	ABSolEU	\N	ABSolEU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
63bf3480-467d-4978-b194-dc449b039a36	ABSOLUTE	\N	ABSOLUTE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
537e1e22-5cb6-4975-b787-054865670c70	ABSOLUTESPIN	\N	ABSOLUTESPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b96c1504-fa93-4198-91e5-cf87237032fa	ABSOLUTISM	\N	ABSOLUTISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78d0c331-fba6-42bb-8f3b-7a8ca5817153	ABSORBNET	\N	ABSORBNET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b5bae17d-966e-431c-a2c4-efec7bf35f5b	ABSREF	\N	ABSREF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9522cba2-7c83-43c6-bd08-42d273a07e36	ABSTRACTION	\N	ABSTRACTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cd4246f-19bf-4c5e-89bd-35f58983e32d	ABSTRESS	\N	ABSTRESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d52ad304-28d4-40a8-b160-c021f194e674	AB-SWITCH	\N	AB-SWITCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b4dab35f-58e7-4d62-aec8-89f8613da3c0	AbsZero	\N	AbsZero		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a62d208-dcb8-4678-bdd8-a7d6a80b8c67	ABT	\N	ABT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b835db2d-c1ba-4349-b836-a6306de9581f	ABU-MATRAN	\N	ABU-MATRAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eec0d665-ba2c-4188-a11e-31efbeab22bc	ABV	\N	ABV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a3a777fa-7283-48ea-b61d-5eeada4669b2	ABWET	\N	ABWET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e7a1d0b0-67c9-4dd2-9b6f-ff79e884f344	ABwipe	\N	ABwipe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f4b5bf8-6d9d-407c-8091-ba5c083ec76a	ABYSS	\N	ABYSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9e12c0a2-3d10-446d-ba82-e85f36ca26c3	ACACIA	\N	ACACIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aaf298bd-b2eb-45af-abcb-ac5797f0ded5	A CACTUS	\N	A CACTUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
89605063-078c-4493-b49c-daf252d16c7d	ACAD	\N	ACAD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d7ca34f9-3df6-468a-8ad7-ea7719d14818	ACADEMIA	\N	ACADEMIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2f5813b1-1057-4b32-af55-cd767dbd620e	ACADEMIC GMP	\N	ACADEMIC GMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7ce82688-3a4c-4eb5-bda5-a6db91dda5f3	AcadHist	\N	AcadHist		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9a4fdbfe-00a9-411a-abc3-b5892121a036	ACADIS	\N	ACADIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eba7919c-ff7b-4392-ab83-0fa6512d43b4	ACANTO	\N	ACANTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
716df075-a1d8-4da0-ae04-511ce8102b14	ACAP	\N	ACAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
49d4badb-fe51-4328-80b5-d291e04b2cb2	ACAPOLY	\N	ACAPOLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80b8146d-61e1-4e81-881e-efbf83549271	ACAR	\N	ACAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f5d04107-5dc4-4575-a03a-c5ec5db35a20	ACASIAS	\N	ACASIAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33e100d7-ce2e-4453-bc84-08e5b954d8d5	ACAT	\N	ACAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
004405e8-513d-43c7-85b5-7f22338c72c5	ACB	\N	ACB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f801d3f2-15d7-4c07-9232-997c289d2ae6	AC BREAKS THE SPHERE	\N	AC BREAKS THE SPHERE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26703649-1f4d-4b7f-ae78-597f5b25c587	ACC-3D	\N	ACC-3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b5eea7b8-341f-483b-ad30-8659ec61486b	ACCA	\N	ACCA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e0948f9-4457-4973-a7e8-87fe1bb9e3a1	ACCARC	\N	ACCARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a561727-66cf-4369-ae87-54cad1b11e3e	ACCDECMEM	\N	ACCDECMEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
54bd105e-1a62-4bea-aeda-3dc3ff25cbce	AccelCMR	\N	AccelCMR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
75089436-50fd-4b6c-b8df-0b9311fc6b00	ACCELERATE	\N	ACCELERATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ff0bf59-2b8c-4d32-b131-e01cfb0d3880	ACCELERATES	\N	ACCELERATES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
44d299a7-2c91-41b8-8ac6-e97c0d98512b	Accelerate SUNShINE	\N	Accelerate SUNShINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80ed2e8c-18c1-4949-9f73-4ba6e5437bdb	Accellta	\N	Accellta		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c13a9fe-7f3e-46b0-b19b-06899553f176	AccelOnChip	\N	AccelOnChip		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf96c17f-727d-482b-9b73-231fc092a623	AccelWater	\N	AccelWater		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dbb76f96-619a-4b7b-a55e-bf7624833e1a	ACCENT	\N	ACCENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e3c61f77-6044-4b7a-8c1d-19e8183ad8ce	ACCENTO	\N	ACCENTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b9606472-214d-4c2f-b590-ea3994d0290f	ACCENT-PLUS	\N	ACCENT-PLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
927cf18e-65bc-4bf9-9937-73085a6c10ff	ACCEPT	\N	ACCEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc994ae7-bf6d-4017-9246-e1c28135b4de	ACCEPTA	\N	ACCEPTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e5f108d1-cf50-44a1-98b3-5afd5b7f119b	ACCEPT PLURALISM	\N	ACCEPT PLURALISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
81139d1b-dede-4352-8ce0-87c3f9067b67	ACCESS	\N	ACCESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8e7d40e4-f546-43dd-8e5f-a5daa8c79767	ACCESS 2 ALL	\N	ACCESS 2 ALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0cfbdfdf-f35a-4f6b-afe9-6200f7a3656d	ACCESS2CANADA	\N	ACCESS2CANADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7304c948-99c8-4e68-9761-b8d0b42b6932	Access2EIC	\N	Access2EIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
18a026e7-1781-4a6a-8a98-07696886d753	ACCESS2EIC	\N	ACCESS2EIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
281ec6d7-1b69-47ea-8b99-b94fcf23e491	Access2Europe	\N	Access2Europe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a0eb9c84-2fd7-4b9b-8c5a-058a4a554728	ACCESS2MEXCYT	\N	ACCESS2MEXCYT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe1c651a-eede-47bb-b084-557a077b3fdc	ACCESS2WM	\N	ACCESS2WM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33c364ea-3d06-4165-93ed-02aafa7f5ceb	ACCESS4EU:NZ	\N	ACCESS4EU:NZ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be355ffa-17e6-40ac-99eb-8ae18c7dbb1f	ACCESS4SMES	\N	ACCESS4SMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a877f09-b932-4903-af0c-c983c04aaf6d	ACCESSIBLE	\N	ACCESSIBLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
093f164e-d5d8-437c-af88-f8bd00881861	ACCESS-ICT	\N	ACCESS-ICT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bad8f1d5-6637-418e-a850-c26fa7ee7ce0	AccesSME	\N	AccesSME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0764c6d-aa61-4d56-87ca-d83be21c0d37	ACCESSRU	\N	ACCESSRU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fece6577-1941-49a9-9c3b-5023542704d7	AccessVote	\N	AccessVote		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
97b6f497-1563-4237-b4af-946f30df59d1	ACC_EXT	\N	ACC_EXT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30b20be2-0398-4f2b-b464-4d1b2a510c57	ACCI	\N	ACCI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c1b95dd3-53f4-44f9-9e23-0def4a09afb1	ACCLAIM	\N	ACCLAIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4cda69e6-6fa9-463a-8c43-0c4c67432f16	ACCLIM	\N	ACCLIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b35f34a-c6c6-40ab-902c-c088d7e44c58	ACCLIMATE	\N	ACCLIMATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d5901d70-3e9f-4595-8679-1b8c9390d1cb	Acclimatize	\N	Acclimatize		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5dee6c2c-879a-4892-9e2b-0d0324b691e4	ACCLIPHOT	\N	ACCLIPHOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f3d9aec-b283-453d-a061-949716091c39	ACCMET	\N	ACCMET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
324e1e80-4528-4575-8d68-752f61901e4a	ACCOMIM	\N	ACCOMIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
589b5aae-aa02-43bd-b884-5907a6616260	ACCOMPANY	\N	ACCOMPANY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9a8f3dff-1bab-4962-92c2-cc54271cbf25	ACCOMPLI	\N	ACCOMPLI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30a39294-3313-44ed-b28f-043d2c095205	ACCOMPLISSH	\N	ACCOMPLISSH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
06cdee90-afdc-4df5-9012-760e52e69f71	ACCOPT	\N	ACCOPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56cd1d50-245d-4981-8d04-3719b9a7b22a	ACCORD	\N	ACCORD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e8eca762-99ef-4460-9517-46d3bcba241c	ACCORDANCE	\N	ACCORDANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f39ea45c-d2f2-4f84-bd4f-a802d4f30331	ACCORDION	\N	ACCORDION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dca03c14-85c6-4a91-bde1-35c99b709780	Accordion Bioreactor	\N	Accordion Bioreactor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
97dfeaae-4c27-4c55-b375-e3623486d3b9	ACCRA	\N	ACCRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
917a4b52-be4d-4630-8682-5a809a354b67	ACCRETE	\N	ACCRETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
62a13e07-9cbf-465c-b870-47db37699164	ACCRETION/EJECTION	\N	ACCRETION/EJECTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dfa430a6-7ed1-4706-8887-06252169324f	Accretion states	\N	Accretion states		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc9718bb-0f5f-44e0-9089-8845706e4bb2	ACCSESS	\N	ACCSESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
699132fb-0759-4653-b4f5-b8c714dd3c20	ACCTING	\N	ACCTING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a56d8fd5-397c-49cd-8004-efc1a08dca47	ACcTIOM	\N	ACcTIOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ccb0803-f3f8-4fa3-aa80-359291b12033	ACCUBLADE	\N	ACCUBLADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2f8b5170-3433-4f4b-a3ac-46ac6cc80db2	AccuCT	\N	AccuCT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bb24ba93-731b-4ec6-b13e-62552b9810fb	ACIGDSLE	\N	ACIGDSLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e8233427-17b5-4225-ade6-d330856cdb09	ACCULTURATION	\N	ACCULTURATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
daf72b32-9eb5-4e18-bd01-1304e9607ccd	ACCUPOL	\N	ACCUPOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
abf76676-cdba-4500-9975-3cace698a592	ACCURAT	\N	ACCURAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d115c898-b6c2-4311-9f97-065bbc1876bb	ACCURATE	\N	ACCURATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f35fa43c-83d7-49eb-b58c-647073af4872	ACCUS	\N	ACCUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
24f73d54-c3da-4506-af13-6a87423c7556	ACCUSIM	\N	ACCUSIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c098f3d8-42fa-4bed-8247-5e14a1516ab8	AccuWater	\N	AccuWater		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
132bb67d-1ae5-4701-89a4-5f06231997c8	ACCWA	\N	ACCWA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2964b7d7-b1ec-4868-9f1d-e5bc4a544617	ACDC	\N	ACDC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a94f339-1231-4333-9c7d-cfcbac0c3349	ACE	\N	ACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e0126a98-b75a-4308-ae53-17eb56578eb4	ACE Creative	\N	ACE Creative		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f5068999-ca04-422a-bd09-d888831f5aac	AceForm4.0	\N	AceForm4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5bd5f156-431c-4e14-b324-fafa92919d64	ACE_GFAT	\N	ACE_GFAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
87a19dde-8391-4882-be93-87edfba4a1e2	ACElab	\N	ACElab		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f596d0d8-3cef-46e9-9e45-c2f1a1d22d98	AceLSAA	\N	AceLSAA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce21c6a5-c112-4fe8-86f1-d8141bac7d90	ACEM RAIL	\N	ACEM RAIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8e63f84b-5dd4-4f22-9f3a-8474a69e06e6	ACEnano	\N	ACEnano		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
51330b99-bd2f-464b-895c-bb8865b75c0e	ACENTSPINTUB	\N	ACENTSPINTUB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
329528ad-b70e-4a46-b5a2-37575fee6cdd	ACE-OF-SPACE	\N	ACE-OF-SPACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c233e82a-8d73-4a75-bc3f-6b3911a83295	ACEOLE	\N	ACEOLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
05be44d7-ad22-404c-9929-4bcdebe2c73a	ACEP	\N	ACEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2907f39e-758a-4971-9317-bccdb22ef1e8	ACEPOL	\N	ACEPOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e65bed1c-04f9-4131-a4d5-f7767510a2e7	ACES	\N	ACES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a1755df2-7050-488b-8038-95a9eecbeffa	ACETOGENS	\N	ACETOGENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc9f8073-c8e5-4411-90a3-589c1754642b	ACETO-SAGATAC-HUMAN	\N	ACETO-SAGATAC-HUMAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47c4528a-5d63-4707-b9a2-8a2ddf53cfa6	AcetyLys	\N	AcetyLys		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4eacb852-1815-4a72-b18d-4766369ef413	ACFA 2020	\N	ACFA 2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2db6f2cf-50c3-4901-855a-3b634bdca9be	ACFD	\N	ACFD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26cb6e05-dc94-41e8-9781-b6c963af3e0e	ACfoil	\N	ACfoil		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
46bc900c-de1e-48d3-b4b7-13fdf08775e3	AC for PKU treatment	\N	AC for PKU treatment		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8febe856-2ce8-4191-bd7d-6a08423f12f2	ACHEON	\N	ACHEON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bcbcb198-494d-41ac-8737-438bc90b104e	ACHIEF	\N	ACHIEF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d5ada021-8f2b-42f4-9808-46d1c0d8e140	ACHIEVE	\N	ACHIEVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b315e1bc-af1d-43aa-a319-dc151fa386a8	ACHILES	\N	ACHILES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32909e2e-4a0c-4202-82e8-b0cf57aa93d5	Achilles	\N	Achilles		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bd8d006a-a864-4af7-b5c7-5e3afa7867a8	ACHILLES-HEEL	\N	ACHILLES-HEEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e695d2f-56d1-45bc-9663-da6d70ec3b94	ACHILLEUS	\N	ACHILLEUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f77e77b3-86de-4b1e-ba16-7f98b1bec388	ACHROMAS	\N	ACHROMAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0daafbc3-6450-48fd-9783-e22e6710e37f	AChSo	\N	AChSo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b0ee5cb9-4376-469a-a404-15ae61d8782e	ACI-AMS	\N	ACI-AMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f067d838-9495-4acf-ab30-f7f0d8e12907	ACID	\N	ACID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7ebce6c2-751f-4797-9a7c-c512bc269d8a	ACIDIBACLIGHT	\N	ACIDIBACLIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30bdb856-d780-45ee-b971-125c2d6a9ba8	AcidICC	\N	AcidICC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
564acb3c-caf0-4921-a929-d398b0dc0598	ACID-MARS	\N	ACID-MARS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc388561-2f3e-4acf-857c-fc4ddcf61db3	ACIN	\N	ACIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a15dade-6d45-4365-a89b-4537df0cebdb	A-CINCH	\N	A-CINCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f07e427c-9a7b-4528-bd8c-eb9819d58774	ACINO	\N	ACINO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a1209b9-c2da-4fb4-a02c-c1e62dc1e886	ACINPLAST	\N	ACINPLAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d4e505e5-f8e2-4bca-819f-70a211aa2822	ACI-UV	\N	ACI-UV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0148d368-f2cd-42a1-945f-57461f721665	ACLACL	\N	ACLACL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33111e92-5083-4efc-b313-8efffd4d90c3	ACMAC	\N	ACMAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ca86161-de28-4c2c-b00e-534f99490506	ACMC	\N	ACMC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8de3a9be-211b-4e75-9cc6-80714a2d66e8	ACME	\N	ACME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60a336aa-f79f-4e07-8393-df702aa6180a	ACMO	\N	ACMO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16b9e499-7cdb-4b99-baef-182ff8c098d8	ACMOL	\N	ACMOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
43449194-166f-4c1a-8b79-d8cf9f7fa8a0	ACO	\N	ACO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f850b888-aedb-4f25-9009-3944807e3b11	ACOBAR	\N	ACOBAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3eca607-816c-4e09-a3d7-c138e6173e21	ACOBSEC	\N	ACOBSEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc111bd5-1d66-47cc-a4cc-d904b40f929b	ACOC	\N	ACOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
63e90475-9618-4e52-9134-2704d49c5b8f	ACOC-TH	\N	ACOC-TH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2982ed35-a8cf-4be1-8709-b6bb3fe1de83	ACOCTIA	\N	ACOCTIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86a59f19-d30b-4f56-8835-a4c412b28f8c	ACoDM	\N	ACoDM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df8c8dd4-1728-4966-8d45-8135266e30b4	ACOFC	\N	ACOFC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e7ad187-4888-435d-b21b-991e75c8cb62	ACOFORS	\N	ACOFORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ccc6b4d8-2a49-4378-a046-56a4c42221ea	ACOLA	\N	ACOLA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b525fa6b-013c-457f-a2d6-2e071bd6fe3f	ACOM	\N	ACOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
91731a33-b7b6-4b48-9d9f-dd4bd0db64ca	ACOMIN	\N	ACOMIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
54084c9b-6593-47f0-8819-d85893bba0a1	ACONIT	\N	ACONIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0c616dc3-7954-471b-8e3b-71aa66cac0a0	ACONITE	\N	ACONITE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f2c62212-7b47-487d-bc68-ff950b32e94a	ACoolTouch	\N	ACoolTouch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20d3e667-0654-4c11-8b50-2c23ba80360a	ACOPS	\N	ACOPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1b1aa38-6fcc-4b3c-8b0e-67a73f4daa91	ACORN	\N	ACORN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c4f8f18-6777-4552-a2d1-e1a04148c79e	ACORN-BP	\N	ACORN-BP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cc061ce6-23b7-404f-8a85-9adb550ef114	ACOSA	\N	ACOSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e08bee2e-42ff-4675-9fe8-543fd417a74d	ACOSE	\N	ACOSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
72f95d6d-bbac-40fb-97c7-32c4c0bbb7fb	ACOSENSE	\N	ACOSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
34a517cc-c49e-410c-9874-acf37a277641	ACOSPECTOR	\N	ACOSPECTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb1a8bb7-2da9-4f3a-b183-fcc58943004b	ACOST	\N	ACOST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c9e1dfa-5fe0-4313-b208-1392bff26478	AF3	\N	AF3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d5c2c88-f187-4e7b-a7dc-7d8e3d6b00a0	ACOSVA	\N	ACOSVA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4bd1a4c6-874a-44a1-bc14-4aed1f470d6d	ACOTAAL	\N	ACOTAAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
73cab051-df15-4f35-a815-ca015d255d43	ACOULOMODE	\N	ACOULOMODE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a9161924-6229-4dc1-925b-ab7d898248ff	ACOUPLASMA	\N	ACOUPLASMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe8d75b0-ad2f-498c-a397-02f4dbc792fe	ACOUSEQ	\N	ACOUSEQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
765580fa-2e25-4149-a489-04283559a793	ACOUSTIC	\N	ACOUSTIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f925fa06-130f-4b08-b194-94f9fe0ebf9b	ACOUSTIC ATLAS	\N	ACOUSTIC ATLAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
48bc1857-8401-4beb-8764-862ff832698d	ACOUSTIC RAINFALL	\N	ACOUSTIC RAINFALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad946514-627f-4547-a2eb-4ce92d2703d9	Acoutect	\N	Acoutect		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
209f487d-b83f-4f35-89d7-2fdb12704bac	ACOUTRAIN	\N	ACOUTRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fda93663-492b-461a-bece-6c34e56b2dd5	ACPNMR	\N	ACPNMR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a32db66e-70b5-402e-b8fc-603ce96e6fb9	ACPRE	\N	ACPRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b4b2db3-b0a4-4876-9c1f-97346a098cca	ACQDIV	\N	ACQDIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d654a49f-ce73-48f9-b434-ec37fada0b60	ACQUIRE	\N	ACQUIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4bfbe59f-4219-4683-9457-6134bc881dff	ACQWA	\N	ACQWA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
364827ef-6405-4cac-bbc0-511d024a14b4	ACRCC	\N	ACRCC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58ff369b-71d9-4872-ae5e-261aad4e9bc6	AC REMOVAL MECHANISM	\N	AC REMOVAL MECHANISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6142e5d4-375f-46c9-8a51-28c5e8f11916	ACRES	\N	ACRES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
00355828-15e8-4cfa-af71-fde2b00d3da1	ACRIMAS	\N	ACRIMAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
62676ff2-a334-4ed2-aa6e-1aacedb3aac0	ACRIPET	\N	ACRIPET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a6c31a6-3ced-4e36-b0fe-6d30133160d2	ACRITAS	\N	ACRITAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
17bc3a44-445b-4b2f-a9da-c4cfd467c60d	ACRIT CY	\N	ACRIT CY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
804a389c-7a93-4ec5-8976-5928ab46997c	ACRO	\N	ACRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85952ef4-a7f3-41f3-8f19-b1531b349c52	ACROBA	\N	ACROBA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb3ef83e-e9c6-4ed1-bf54-7b637618a091	aCROBAT	\N	aCROBAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e534a776-49dd-4bea-af34-9e3ecb3fc7fd	ACROBAT	\N	ACROBAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f313a748-8f73-481d-8916-ecf96ee9cb82	ACRONAM-Speech	\N	ACRONAM-Speech		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c5a4170c-8ec9-4545-beba-54d2057df453	ACRoNNIM	\N	ACRoNNIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3bfdb67e-2e63-4eb7-86d2-b8af5c8ef9d9	ACROPOLIS	\N	ACROPOLIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
23603dd7-8318-475d-99c4-b1cd70e3a69c	ACROSS	\N	ACROSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
af6ef307-c285-43dc-bb47-8b232ed8d5ba	ACROSSBORDERS	\N	ACROSSBORDERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a7d23bd5-3c1c-442c-9341-e00634baa819	ACROSSING	\N	ACROSSING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e9374e3-79b1-4049-a4d3-abefa1b589d2	ACrossWire	\N	ACrossWire		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e763cdaa-405c-4c3f-bb16-c17ca6061e98	aCryComm	\N	aCryComm		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b7dcc8c4-7405-410c-ab7d-508c5ec22e64	ACSAC	\N	ACSAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df1511ad-e7ef-45ba-b6d9-0206534b3c8d	AcScapeStress	\N	AcScapeStress		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88aa4972-ca6f-4fc6-9f48-4ff9032cacb8	ACSELFASSEMBLY	\N	ACSELFASSEMBLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9d9f6315-ad8d-4e18-9ddf-f89b069c8fa4	ACSEPT	\N	ACSEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60b2eeed-8ab2-46df-8ab7-a33aab96878e	ACSI	\N	ACSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
53b392a0-4150-44ba-8cb1-6389a2b34b38	ACSol	\N	ACSol		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28aaf363-f103-4d34-ba03-5be4c6f81b80	ACT	\N	ACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa7650fa-66dc-4792-9fab-51a7a19d215d	ACT4INFRA	\N	ACT4INFRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
743f511c-112e-4e4f-92b4-b74aa6cb6b8f	ACT5G	\N	ACT5G		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
245752e3-c222-43a5-b5d9-361a23407d5f	AcTafactors	\N	AcTafactors		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fca5e3c3-9e29-44af-a4ce-439ac1530b19	AcTaferon	\N	AcTaferon		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cfffdc07-1a2a-420d-a5d9-41687bfd9007	ACT against AMR	\N	ACT against AMR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1022b6df-9fbe-445e-ab1f-256d096dc3ac	ACTAGREEN	\N	ACTAGREEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cc5f5f90-e427-446a-aade-39f04b2307f7	ACTAN	\N	ACTAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
21320cce-3c9d-41b2-a696-27d95782658d	Actanthrope	\N	Actanthrope		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dac5c8e3-ac4a-4cee-8626-596f9aace45b	ACTAR TPC	\N	ACTAR TPC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
83f569de-26e2-4550-b33b-e8bd28947eea	ActDisease	\N	ActDisease		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2983a83-71f4-4183-bd8e-498c574acb09	ACTECH	\N	ACTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f0817f1f-e3d5-4741-927b-e26af7d83a04	acteno	\N	acteno		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
772af63b-1319-45da-b94f-dbcdd618433a	Act-EPR	\N	Act-EPR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed591161-e005-4ce1-bbdf-7744ca032fb0	ACTIBIO	\N	ACTIBIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
105296ab-4761-45b4-a0e2-84a0939a879d	ACTICAPS	\N	ACTICAPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
73326040-0546-4274-88e1-7195ed82843c	ACTICELL	\N	ACTICELL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d7313c6e-e0a7-43c0-a591-610a0bd88c48	ACTICIPATE	\N	ACTICIPATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
06233545-68db-434a-b222-bd0d3eeca0d3	ACTiCLOUD	\N	ACTiCLOUD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e25e144e-2f8f-4025-9c06-24eb17ffcefa	ACTICO	\N	ACTICO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6667c6e4-8c26-4b6f-93db-c04429088a45	ACTICOSPACK	\N	ACTICOSPACK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4faa3fcb-0845-46fe-a14a-228ddcde9c6f	ActiDoC	\N	ActiDoC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85bc1bb2-4d3e-408c-9800-da6b6f89aee7	ActiDrops	\N	ActiDrops		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9a690d76-48e6-4da6-b174-8e2e1e0bf75d	ActiLit	\N	ActiLit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8fef346a-036b-4bda-8bc7-efbcaf453cbb	ACTINET-I3	\N	ACTINET-I3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2b8657fa-3125-48fe-8f78-b5bc5c6e5913	ActIng	\N	ActIng		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7ed4752b-6c52-458c-8209-353a7f541e5f	ACTING-NOW	\N	ACTING-NOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e7fd146-fd16-441f-8384-3a402a9c3e81	ACTINIT	\N	ACTINIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0835533e-3364-43e6-a830-956db5c495c9	ACTIN-NUCLEATORS	\N	ACTIN-NUCLEATORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
995d86a5-456d-4430-b674-f8e7171cf9d4	ACTINNUCLSHAPECANCER	\N	ACTINNUCLSHAPECANCER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
256fb9f7-7711-4343-b5ed-4069cfaafbed	ACTINONSRF	\N	ACTINONSRF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b45c335e-9383-4466-9b78-37216bf4074f	ActinSensor	\N	ActinSensor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
25ebdfc3-25c6-4677-b9e5-f7f4e4cfffe6	ACTION	\N	ACTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
11fcea3b-6c23-4b5c-bce5-2350912ae736	Action and Time	\N	Action and Time		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e7f20969-9487-43e3-9b99-d7ca70349405	ACTIONCONCEPTS	\N	ACTIONCONCEPTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5cdbc871-a009-48ad-bfcc-10194a46861d	ActionContraThreat	\N	ActionContraThreat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed38b6cc-2d64-4d56-8731-3239c99e5e66	ACTION COORDINATION	\N	ACTION COORDINATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd861037-4224-43ce-9242-3203d4c78033	ACTION-Grid	\N	ACTION-Grid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cdd49bc7-68cd-49be-889a-2324692453e7	ActIonHeat	\N	ActIonHeat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
40f1e3c2-bcaa-4207-8323-0f09392c73dd	ActionPlanT	\N	ActionPlanT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
94564e74-40a5-4cc9-96e2-42c307730dec	ACTIonRCraft	\N	ACTIonRCraft		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a0877875-1c16-499a-bfcd-92d7128315bb	ACTION TO GESTURE	\N	ACTION TO GESTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
492dde7e-9483-4d7a-a654-6a317f7a4bbc	ACTION-TV	\N	ACTION-TV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
807171c1-cd48-46dd-b405-f394e33cfcb6	ACTIPPTSENS	\N	ACTIPPTSENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a2630fbf-627d-44e2-9427-adefcf710668	ActiTOX	\N	ActiTOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b37ca13f-ac08-4241-856a-53f885bae8a0	ACTIVAGE	\N	ACTIVAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26591abd-fe0a-4bf4-a04c-a709184d9050	ACtIVAtE	\N	ACtIVAtE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5d5d8ed9-f72c-4cbb-91e7-6bf52249ef5b	ACTIVATE	\N	ACTIVATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
826fbd5e-3b8c-4176-87cf-0d6bcf2624fb	ACTIVATION OF XCI	\N	ACTIVATION OF XCI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c954448b-5924-4d13-9d0c-73718eccd3f3	ACTIVE	\N	ACTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c0d9049-2635-43c5-87e1-b584a68b3cd3	ACTIVE_ADAPTIVE	\N	ACTIVE_ADAPTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
264bd183-e599-4fe6-9ed7-5298fa4dc9d8	ACTIVEAGING	\N	ACTIVEAGING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
581eb970-5d83-40df-800b-f87334bc0424	ActiveBioFluids	\N	ActiveBioFluids		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3df182a-9eda-4995-bd95-8ebd6d6b96e9	ActiveCortex	\N	ActiveCortex		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f869e7ed-1b0c-42fd-923b-d67bd97bdd25	Active-DNA	\N	Active-DNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d6b248d-3ebc-417b-b65c-23af5d7f28f6	ACTIVEDYNAMICS	\N	ACTIVEDYNAMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a9ab758e-779b-4fbe-950e-a4023c2dbd54	activeFly	\N	activeFly		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
437d63c5-23ae-4395-a4ae-973ab0ec216b	ActiveGrid	\N	ActiveGrid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
979b0f17-a282-443d-adf9-ebe3cc48ea83	Active implants	\N	Active implants		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa18d113-c503-406b-bff6-4c515a6146c6	ACTIVE_MARS	\N	ACTIVE_MARS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7635da9e-89a0-4c3f-b975-f11b3f0cc45e	ActiveMatter	\N	ActiveMatter		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
771c8782-ffc7-4282-b6f6-86edae539fa9	ACTIVEMOTION3D	\N	ACTIVEMOTION3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fee22d08-d18f-4b57-a8aa-fef8344e5dfc	ACTIVE NANOPORES	\N	ACTIVE NANOPORES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
336d71bf-56b6-4513-a037-29be8f452084	ACTIVE NEC	\N	ACTIVE NEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f52ac23b-bab2-4341-925f-213808b38d38	ACTIVE_NEUROGENESIS	\N	ACTIVE_NEUROGENESIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
15ad66d1-f758-4dc5-8424-fa3ee12b14a1	ACTIVENP	\N	ACTIVENP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a0a0a572-f94c-425d-bf40-f478cb85ab64	ACTIVE PERMAFROST	\N	ACTIVE PERMAFROST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
993bdeab-43c5-471b-9712-6ebb4f3194be	ACTIVEPHANTOM	\N	ACTIVEPHANTOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d6cd2ab-a6a2-43a7-b21a-e07203867beb	ACTIVE SNIFFING	\N	ACTIVE SNIFFING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
11db15a1-9267-4a3b-9a60-2ad7f53115c9	ActiveTest	\N	ActiveTest		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2339e84-e0f9-482c-beac-464b3403087d	ActiveWindFarms	\N	ActiveWindFarms		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a12fd1a8-f350-427b-a711-6f12e8692d12	ACTIVIA	\N	ACTIVIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
059903ba-564c-416e-83f7-ff84def9c478	ACTIVIN AND CANCER	\N	ACTIVIN AND CANCER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad1a2cd0-c0ea-4a83-ba41-8c7ea7ba4e8d	ACTIVITY EXCHANGE	\N	ACTIVITY EXCHANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fae02ee2-ee19-4082-a57e-60fecc78fa2b	ACTIVITY & PLANETS	\N	ACTIVITY & PLANETS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
10fe1d81-39f5-4b55-a697-ab5e1984eb08	ACTIVMOBSEC	\N	ACTIVMOBSEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
99bc5c04-aeb8-4c7e-ad75-4eb5775f2ed1	ACTIVOXY	\N	ACTIVOXY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b74ecd41-a9d9-44f3-98e3-347060b72e62	ACTIVRENERGY	\N	ACTIVRENERGY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7259d0ef-53ad-49c7-94da-bee206d11a7d	ACTIWATE	\N	ACTIWATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
87c90461-bb64-48d5-b7fe-bbd0f8b7fbcc	ActLight	\N	ActLight		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2df361a1-7f34-49cd-8204-8ee14138bcc1	ACTMECH	\N	ACTMECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe137530-86a8-460e-ac07-3741bf6896f6	ACTMOST	\N	ACTMOST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd0f306f-cc20-466c-bf56-83b93cb451c5	ACTOIDS	\N	ACTOIDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
019347b5-12a9-4464-adfc-0ee3dc8f795a	ACTOMYO	\N	ACTOMYO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
659629e4-40c6-46b4-b4f7-cefc0dcd9fe3	ACTOMYOSIN RING	\N	ACTOMYOSIN RING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
84e96a35-1eb2-4354-b9b5-7e86b245752d	ACTOR	\N	ACTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5fac505d-2774-4361-9b79-9fa48d291a23	ACTORS	\N	ACTORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3310f33-64b9-41e7-88e7-2b09bfdeb925	ACTOSPED	\N	ACTOSPED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a4834e6d-57cf-4270-b074-47e44c3adf1a	ACTPD	\N	ACTPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
34ecbb63-2de6-4742-8ccc-3d6d43d4fac8	ACTPHAST	\N	ACTPHAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e5670434-6019-4f68-8387-02b02eb24530	ACTPHAST 4.0	\N	ACTPHAST 4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
93c87492-df03-4ea1-8404-56043621cf1a	ACTPHAST 4R	\N	ACTPHAST 4R		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b37fd917-f516-4f6e-9312-4dbdde5fbd58	ACTPUP	\N	ACTPUP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
734be2df-3e1d-4d7c-a8c9-53263aa5bffd	ACTrans	\N	ACTrans		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
12e6e4b8-994c-4e3a-bcd0-a8d7657e0989	ACTREAL	\N	ACTREAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c4350cf-b0d1-46f4-8420-87461065f5ec	ACTRIS	\N	ACTRIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
542ce8f8-a293-4a6c-811f-11eaa5092993	ACTRIS-2	\N	ACTRIS-2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b41d037-26c2-49f0-857b-51349a99da5d	ACTRIS IMP	\N	ACTRIS IMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad4602e1-fe4a-49cf-bbfa-88db4f680fa6	ACTRIS PPP	\N	ACTRIS PPP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ed4e418-b735-4f3c-96d4-437aa04cfd9e	ACTSELECTCONTEXT	\N	ACTSELECTCONTEXT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f59f0fd-574c-471d-962e-bbf91d807af6	ACTTiVAte	\N	ACTTiVAte		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f64763ed-10b8-4694-a8bd-7311215439e5	ACTUATION2015	\N	ACTUATION2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1cfcc810-a37d-48b6-94e1-9b1faedf4017	ACTUS	\N	ACTUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
123a5286-e6f4-483b-bd52-88bc4ab7ab7e	ACU-AHvE	\N	ACU-AHvE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
01da20c0-fbc1-496d-8f16-58b395101ca7	ACUHRA	\N	ACUHRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a24e9753-5256-48a5-b6d5-ff6ad33712d6	ACUITY	\N	ACUITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a06aaae-40f4-435c-9cec-d201db46872a	ACUMEN	\N	ACUMEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c9eabe5-04de-4456-a011-aff013caf4a4	ACUSEP	\N	ACUSEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
364cb9d7-c95c-4598-a529-1866abb22bba	ACUSLABS	\N	ACUSLABS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
06e258f9-44e9-4182-b03b-9be778fdd224	ACVOIHE	\N	ACVOIHE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7c06801e-38c2-4dc5-9ecc-1528c00aa07c	ACWIND	\N	ACWIND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a7e292be-3adc-436d-b1c7-2385472fb4e7	ACXIS	\N	ACXIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60f6d34e-ccee-489d-b731-2a286e2db828	AD4GD	\N	AD4GD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c1d07d2-e565-4573-a8ec-f06f76e7c8ed	Ada	\N	Ada		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20fff17e-af20-493c-97ae-9836b1bc5a30	ADABTS	\N	ADABTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2661c5a6-c8a5-4272-92e0-923f917fbe13	ADACOM	\N	ADACOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f0c45dd1-fafa-4f23-bf9d-5f47d3efb7a4	ADACORSA	\N	ADACORSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7c492ec9-000b-4904-b0a2-41b0f4fd9431	ADAFARM	\N	ADAFARM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf455e14-ab81-4832-be3f-600e872ff673	AD_AGING_AND_GENDER	\N	AD_AGING_AND_GENDER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5373e5cd-bc7b-43a4-99bb-7028f31010aa	ADAGIO	\N	ADAGIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
565c3b5a-4c10-4705-af80-c3b114b4b28c	AdAI	\N	AdAI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8749ef8a-bd7c-4ba5-97cf-508b6585469a	ADALAM	\N	ADALAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b0b0d5fc-2b84-41e4-ab66-b1a5b1ae77b5	ADAM	\N	ADAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a1ec811-323d-4dac-92d2-8a1642093bc7	ADAM-15 AND AF	\N	ADAM-15 AND AF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
110cbcb9-99a0-4a97-b341-22f961984b60	ADAM^2	\N	ADAM^2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4dca377f-f2f0-4397-9add-4382d7421487	ADAM4EVE	\N	ADAM4EVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f8a07d77-2850-4692-8581-23925adaa7d2	ADAM5	\N	ADAM5		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c65257d-8434-41b9-b76c-6108b0d38bf4	ADAMANT	\N	ADAMANT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a6310c92-9807-4f86-94aa-747b6e5be745	ADAMANTIUM	\N	ADAMANTIUM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3a7777cd-352b-4767-888b-765436b59607	AdamFrame	\N	AdamFrame		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2e50007-57b5-45a7-8439-a61d83388632	ADAMNEURON	\N	ADAMNEURON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2c15f0f-1d02-416d-8c86-ad0b097d92d7	ADAMOD	\N	ADAMOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a150aed4-470a-4f7a-9856-0c08f4d7d355	ADAMO Robot	\N	ADAMO Robot		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7805e005-0a36-4183-8b97-e73ef45f5cfb	Adams	\N	Adams		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d4a119c-ed1b-4853-b12b-70caaec4dd4f	ADAMS	\N	ADAMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
928e3171-5d81-4c7e-8e9c-5fc34e070cbf	Adams Hand	\N	Adams Hand		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b59032de-8d4f-4af7-9d42-3cdcedd5aa3b	ADAMtx	\N	ADAMtx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2a7be197-c3ae-4e35-982c-81e0791f59e8	ADAO	\N	ADAO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d70618af-c19a-4c29-a75a-12ff0bc98ee6	A-DAP	\N	A-DAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
18b7478f-e664-4eb0-8af1-595bd017929b	ADAPOND	\N	ADAPOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d41fe44-3864-43c6-aae0-76da1960c66e	Adapptise	\N	Adapptise		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b6a9194f-4f91-49b0-8149-d59698cbff63	ADaPt	\N	ADaPt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f045d694-a6a3-4633-9008-ec877b8ffd18	ADAPT	\N	ADAPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
19681de6-63de-4b33-99a5-02698126a413	ADAPT2FLOW	\N	ADAPT2FLOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b79cbbe9-b872-4b13-801b-0e3e13c6d0a4	Adapt4EE	\N	Adapt4EE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
02f902f0-49f8-40b6-980f-4e12384ca041	ADAPTATION	\N	ADAPTATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cc4ebf6-51cc-4a06-8f9c-7837e3176f4c	ADAPTAWHEAT	\N	ADAPTAWHEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5722c937-dacc-48cf-81c9-b417d8ad9b93	AdaptClim	\N	AdaptClim		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bde965f8-60e4-415b-96eb-5cba8d472f05	Adaptcontrol	\N	Adaptcontrol		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
23716663-d38e-4a74-8399-1d09e7f6f2fd	AdaptEconII	\N	AdaptEconII		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
717e2c55-f207-4576-afd1-11f39f93b3cc	adapTEd	\N	adapTEd		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4ea596ec-b19f-49db-a5ec-544428561010	ADAPTED	\N	ADAPTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f98eeab-5844-4efb-a46b-0c0036ad595a	ADAPTEM	\N	ADAPTEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b50c6c20-f251-4baf-9ce4-92ba2a35cd22	ADAPT-ENVGENOME	\N	ADAPT-ENVGENOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e64c84b8-4e55-44d8-a610-06ba0662d181	ADAPT_EVOL	\N	ADAPT_EVOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ba33acb-f546-4b60-ac54-0aaeb16e9770	ADAPTIMES	\N	ADAPTIMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa7efa4d-5bd0-49d1-b85c-3a02fe3dcc20	ADAPTING2UNCERTAINTY	\N	ADAPTING2UNCERTAINTY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cd4c5c0f-73f8-4693-b047-ca29f30b3f57	Adapting Dickens	\N	Adapting Dickens		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6f1aaac7-f75b-4117-a07e-bf4bbdad03fa	AdaptIVe	\N	AdaptIVe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56ef3a9f-b9f1-47af-bf1a-93e7b04c6407	ADaPTIVE	\N	ADaPTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c639263d-611c-4315-a09f-ed881217ac3c	ADAPTIVE	\N	ADAPTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b5460449-85e1-4cd4-a717-ad5aa19a8a9b	ADAPTIVE INVERSIONS	\N	ADAPTIVE INVERSIONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1677d148-444a-41a6-b87c-4dee390a86ef	AdaptiveResponse	\N	AdaptiveResponse		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ab33cc11-a232-40e5-a3b6-4854504de38b	ADAPTIVES	\N	ADAPTIVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
55ed9955-34c0-4377-bf03-8bcad111726a	Adaptive Simulations	\N	Adaptive Simulations		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
17621eed-1bdb-45e4-be1e-76ac68ed904c	ADAPTIVE SPECIATION	\N	ADAPTIVE SPECIATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dff55280-2aa6-47c9-9025-fc7bb23ed88d	AdaptiveSTED	\N	AdaptiveSTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
afb91f14-2557-476e-b7c7-e8554363df99	ADAPTIWALL	\N	ADAPTIWALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8e362211-e12c-46fe-83b6-48839b321df9	ADAPTNANO	\N	ADAPTNANO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3c12032f-b130-450c-89a0-7952fe9def33	AdAPtoGENE	\N	AdAPtoGENE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5759e90e-8ff3-44ea-be69-d227f2d225c4	ADAPTOMICS	\N	ADAPTOMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0d6d20d1-8f63-47b2-b863-d00a58b0ca06	ADAPTOS	\N	ADAPTOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
36193e8f-35b2-4620-a3f7-70263baed6a2	AdaptoSCOPE	\N	AdaptoSCOPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c23942e-7e46-45e4-8ce7-c884bf602012	ADAPTPOLY	\N	ADAPTPOLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a293bdd5-f2e1-48d8-9f0f-53ed6d505fe5	ADAPT-r	\N	ADAPT-r		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0b832d76-be4e-482e-ae0a-5199a709275d	ALFA	\N	ALFA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
386277dd-6086-4629-90ac-29f1b2358340	ADAPT-SMART	\N	ADAPT-SMART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c98497f4-993e-4bf7-9895-f92b46cf307c	AdapTT	\N	AdapTT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
442bd166-2e39-4967-af95-36d86fb1b07d	ADAR1 AND RNAI	\N	ADAR1 AND RNAI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1165d598-84af-4fe6-9b18-f4943795df9a	ADASANDME	\N	ADASANDME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d174daad-f1a1-443a-89ec-b3b26244d7fd	ADAS-EU	\N	ADAS-EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ff07484-4bdd-4239-96d1-156c79bacd15	AdaSmartRes	\N	AdaSmartRes		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3593ef1-8006-451e-97f2-9cb6ef8f9ce0	AD ASTRA	\N	AD ASTRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2af830b2-08b9-4b92-8e5c-e1594b6077d4	A-DATADRIVE-B	\N	A-DATADRIVE-B		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3841a1ed-2821-4ec3-8c3f-cebad3a45fa8	ADAVES	\N	ADAVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
adab6c89-5449-4725-9f04-344bdd21a64c	ADAW	\N	ADAW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5d3dea4d-aa05-479b-a293-cd285e32fbdc	ADBCRZB	\N	ADBCRZB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
efdb0824-7033-4669-9348-9f16d5a5b71f	AD BIOMARKERS	\N	AD BIOMARKERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0d900239-0d90-4cb8-9f60-d91ada2cc25e	ADC	\N	ADC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8dedd1d-3830-4469-9e7e-41aa875e3aa4	ADC2GBM	\N	ADC2GBM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8ee6c6a3-fa81-4da7-9a53-27e807889583	ADCC	\N	ADCC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6b3b296e-adeb-4b29-b585-e8ae564cdbde	ADCELLPACK	\N	ADCELLPACK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b24a659-9db4-4b78-9dd4-cdd708beee9c	ADCLICH	\N	ADCLICH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32d8c8a9-7b32-449a-b4bd-64d42c1d0e5b	ADDABU	\N	ADDABU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8b3e7ae3-9d90-464f-a41c-f1112252f9c4	ADDACT GmbH	\N	ADDACT GmbH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3634d8c0-3050-4c65-be4e-dcea53be5fad	ADDAPT	\N	ADDAPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
af4e91ee-c0e4-48e6-8d13-2d0ea578a640	ADDAPTTA SEALS	\N	ADDAPTTA SEALS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2598d57-4251-466a-85c2-52bd4e1c487b	ADD CONTROL	\N	ADD CONTROL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35eeb7c8-f84b-4436-8d12-992534f41304	ADDECCO	\N	ADDECCO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d799f125-381b-4fac-b629-57219b68aa59	ADDEGE	\N	ADDEGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56d75ffe-0a9b-4431-9678-4320d9fadd2d	AD Detect-Prevent	\N	AD Detect-Prevent		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2d0808a-9cfe-4e3a-99f7-489b200ddf51	ADDFACTOR	\N	ADDFACTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
08903c74-021e-4fd0-b1c8-d4e6beeefb45	AdD HyStor	\N	AdD HyStor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0a6d9dfa-522c-4002-ac1c-16a8938603a6	ADDIA	\N	ADDIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f50c821d-b0a6-4b98-990d-b2edf0b5d0e2	ADDICTION	\N	ADDICTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
59c450e0-af7c-42d8-b9b6-54dcbf8772da	ADDICTIONCIRCUITS	\N	ADDICTIONCIRCUITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
72f51a96-2ef8-499c-bd0b-94aca25e0b1c	ADDIFLAP	\N	ADDIFLAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be04a037-dc07-42e3-9383-e0ca2cb33fa9	ADDIMOT	\N	ADDIMOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae3c431f-0040-433f-bcd1-96606e5628bb	ADDIO	\N	ADDIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8ba53587-9c64-4eaa-9233-cf3e0f4aee2a	Addionics	\N	Addionics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb6c791b-e809-4b61-afac-cedb38210b12	ADDI-OPTIMISE	\N	ADDI-OPTIMISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f083cacb-4da9-4ef9-a0b2-e1e1c700eb33	ADDITAC	\N	ADDITAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2dda8f79-04dd-4105-ac43-11436a21dce4	ADDITION	\N	ADDITION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4fd8ee58-6d32-4c2c-9d93-1725559cbcf0	ADDITIVES	\N	ADDITIVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6379e2c3-72c7-4d1e-b3e0-1503d0ac6d92	AddMan	\N	AddMan		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f4a49744-8c93-4e55-9fe1-ee27d472528d	ADDNANO	\N	ADDNANO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a841b4d7-f035-4c8d-ac35-c490d7955506	ADD-ON	\N	ADD-ON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e47bd11-17fe-47af-9d92-f53fd552c760	ADDOPTML	\N	ADDOPTML		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
af09ca2d-bfb5-4833-be75-d5acf457a731	ADDovenom	\N	ADDovenom		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc741bf9-e9d2-4f68-b8c2-d24c54bc94fc	ADDPLUGIN	\N	ADDPLUGIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
89ac3101-8aa2-4d41-b102-79f56489497a	ADDPRIME	\N	ADDPRIME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
10960d22-c783-4c6a-96fa-06be6e06a49a	ADDPRIV	\N	ADDPRIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2af2deb8-21e7-4008-ab71-f5c54cf29978	aDDRess	\N	aDDRess		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1e44795-c71e-4f4d-a5cb-bfee0bcee88f	ADDRESS	\N	ADDRESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
998577d1-24b9-4ddc-9b44-60dd2ad15f09	ADDRESSING	\N	ADDRESSING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
de3f0865-bcd6-4228-83df-42c9501d9227	ADDSAFE	\N	ADDSAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2ec4ddb3-af44-467d-bdb5-8641d1dd2bfa	ADDUCE	\N	ADDUCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
971761e2-e147-44d5-951c-88c781a72a00	Adductomics	\N	Adductomics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7957fa1f-4f87-453b-bba4-2e9d827c4eb6	ADE	\N	ADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
949ae28e-2c5c-4400-86d4-0f2a68bcab90	ADEC	\N	ADEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
00044d33-f198-4442-8d21-8db01279e0d6	ADEL	\N	ADEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cc35dd2-a25c-4dd6-9d77-bd2a4bd33bce	ADELE	\N	ADELE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8ffc6aab-b033-4823-9aef-3e83272e1116	ADEMU	\N	ADEMU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
245fad43-2055-4643-a16d-2484d5e0db83	ADENEAS	\N	ADENEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d038b4e0-9531-41a2-90f9-a673481a351d	ADENOSINE	\N	ADENOSINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8313b6ff-f8ef-4894-a1c9-ae31b8d5a5cd	ADENOSINE-RECEPTOR	\N	ADENOSINE-RECEPTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3b3b2bf-802e-46ba-bbfc-81ceefe17f72	AdEPT	\N	AdEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d4ae6371-fb3a-495b-b6bd-383cddcc9eda	ADEPT	\N	ADEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ece41c5c-805f-4b5e-a3fa-40a10818395e	ADEPTNESS	\N	ADEPTNESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31aa2ef4-a7e0-4dc9-b7dd-cd4a29c10fae	ADEQUATE	\N	ADEQUATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b58e795-98d6-4b68-86c9-30320b72bfb9	ADERS	\N	ADERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
875fb5da-bb1e-4401-a553-3617f783c748	ADFIMAX	\N	ADFIMAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ac6d6ebc-c062-4864-8d04-db5eb76c1bf8	ADFLICO	\N	ADFLICO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3c53036a-699c-4807-8b65-8d7d373703f1	ADFU	\N	ADFU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f6a9c5e-1c10-4f6e-a12a-94b2aac97fca	ADGENTHE-CDA	\N	ADGENTHE-CDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
76ac534c-0125-4b34-9aba-13862e00150d	ADGLASS	\N	ADGLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c3c95fe-5c7a-463b-ad0b-6e35c7b4d521	AD-gut	\N	AD-gut		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56f8e966-19e3-413d-b46b-491ae0d296a9	ADHCEM	\N	ADHCEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a1cd9bf5-ede0-4625-b244-9be528cf2112	ADHDLightUp	\N	ADHDLightUp		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3bd7fd6d-5057-45f5-ae00-82af22746d75	ADHERE	\N	ADHERE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
13f3bad4-0fa5-429f-b36f-2a93e2fffd7c	ADHERO	\N	ADHERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9845167a-eef8-4865-ae69-7696a495b9c4	ADHESION	\N	ADHESION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bddc85d1-949b-4bc2-84ba-5842a81c05e8	AdheSurf	\N	AdheSurf		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec289147-2a27-4e7b-a22d-a8a5061f02f3	ADHESWITCHES	\N	ADHESWITCHES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e579b076-2c7e-4cfb-945f-5af22b843e73	AD-HOC	\N	AD-HOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b81a959e-9fba-45c4-bb82-0c96aa33a885	ADHOPHTA	\N	ADHOPHTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
faabe997-f09b-4fc5-9f42-5955be68b33c	ADIBAS	\N	ADIBAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
255dc51f-7f8f-4d0f-883a-40f4bc0b9eeb	ADIBET	\N	ADIBET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f03de5f8-695e-4302-a3a5-a54f4dcf3b52	A-DIET	\N	A-DIET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
781a2e2d-ff05-4dae-8504-e491eb4640ba	ADIFF	\N	ADIFF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
94f43074-152c-4a4b-a7de-c49d7152f0eb	ADIMMUNE	\N	ADIMMUNE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
98756eaa-f11b-430e-bef6-d846a5ebf0de	ADINE	\N	ADINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2c3a2401-08ea-4a53-8ba4-8a4da37dd78f	ADIOS-RU	\N	ADIOS-RU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6876959d-98dc-42c2-affa-08c9979bb46e	ADIPOA	\N	ADIPOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22ff2e1d-0870-4680-afe0-42ebdbe2dc72	ADIPOA2	\N	ADIPOA2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
40c7eb51-f9c4-44f4-ab3b-2475b97e0f9c	ADIPODIF	\N	ADIPODIF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eea13714-bc35-4dbe-98d0-18ab05096450	ADIPONRF2	\N	ADIPONRF2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30e04880-91fc-4598-a02b-a31e9a31c44c	ADIPOR	\N	ADIPOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85d8c07f-4cfc-478b-9fc5-01a20376fcc1	Adipose genetics	\N	Adipose genetics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cfe54364-a606-4883-88c2-45956c8c7c52	ADIR	\N	ADIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8f3b57e9-c06d-4a2c-a559-88a9f71f94ed	ADiRaS	\N	ADiRaS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2614b3c9-b3ba-4ca1-aff2-0e54470fc208	AdIrCAT	\N	AdIrCAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33109552-5995-4a41-845e-07d60946d4ac	AdiScale	\N	AdiScale		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ad5b3a6-1304-46a2-93cb-28524b89e450	ADITEC	\N	ADITEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
422fe24c-949a-444b-95da-a38ce01a7377	ADIX	\N	ADIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
201bb337-6438-4fae-8896-56b800302823	ADJSYN	\N	ADJSYN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b07a8846-adec-4515-af1c-6c309a950ebc	AdJUST	\N	AdJUST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
92514d72-5c03-4628-90a6-dd7253e04d3b	AdjustNet	\N	AdjustNet		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a318d557-816d-48f1-b1c1-deab0aff8961	ADJUTUB	\N	ADJUTUB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d8315df-5eb2-495d-88ed-3f1cecec95e6	ADJUV-ANT VACCINES	\N	ADJUV-ANT VACCINES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
402cf1e7-23c9-446f-a3d5-46685dc831c0	AdLibYeast	\N	AdLibYeast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
837a53a1-7072-47cc-a85b-362f5dea39a2	ADLIFE	\N	ADLIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
99a9b9a7-ff02-4654-b579-f43cd8b2d920	ADMACOM	\N	ADMACOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
41ccb095-1295-4665-9b7e-7607ed6f013e	ADMAIORA	\N	ADMAIORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
68fa7740-3d67-48e2-b528-2d4f8f428d70	ADMAIR	\N	ADMAIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2b470f24-7173-4ddf-827d-46ff5afc1151	ADMANTX	\N	ADMANTX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28e288fd-bae5-4aa0-a7cb-f629cdc5883d	ADMAP-GAS	\N	ADMAP-GAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
16ae802a-6fa5-4809-a1d0-2d2db3e51dad	ADMA TranS4MErs	\N	ADMA TranS4MErs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf750e71-2a88-49ff-9a77-a1e44acdfbce	ADMEHE	\N	ADMEHE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
612a290e-e357-4920-856d-7ce4d363b997	ADMEP	\N	ADMEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a544ee4-70b2-437a-83ba-9be21956556e	AdM-ERA	\N	AdM-ERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e3e40c32-bfa9-4736-bf22-0c16817a225e	ADMIENV	\N	ADMIENV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7a3adf70-2125-4b0b-90f4-61776cdaf9a5	ADMIGOV	\N	ADMIGOV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86dceaa5-50ee-48b6-a5e5-b27f17bddc78	ADMIN	\N	ADMIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a4681e9b-7c6d-454a-ab47-0acb0a03607c	ADMIP	\N	ADMIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f37858fb-44ca-413d-90b5-9aa551b2d02a	ADMIRATION	\N	ADMIRATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3e9d708-9293-42a2-b79b-7b60ce43059b	AdMiRe	\N	AdMiRe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9965b5b5-4883-4533-a02f-ab2d70170b94	ADMIRE	\N	ADMIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2c6dc01a-7ce1-4ae1-a445-28528b2ec8aa	ADMIT	\N	ADMIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
306c0f43-accb-4b80-9420-0119fd72b975	ADMITTED	\N	ADMITTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8944a8a-dd04-4d18-8126-c71adf56ccf4	ADMIXTURE	\N	ADMIXTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b21d008-704c-44dd-a83f-5276b1e0a1d2	ADMONT	\N	ADMONT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a0885297-62a3-45da-9900-7d2ab0904266	AdMoRe	\N	AdMoRe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4be19249-4fb3-4cf1-a439-414f83a40ab6	ADMORPH	\N	ADMORPH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d957b1b-4d88-4dac-b3f0-8268e0c4b673	ADMOS	\N	ADMOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
06913912-371c-4c20-abae-2d19a436c4aa	ADMS	\N	ADMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
90f65488-dafa-4850-ba7f-87f78929d0fa	ADNABIOARC	\N	ADNABIOARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
965739f9-8850-4a2b-9699-13754cf4a211	AdOC	\N	AdOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
214b3bdc-ff26-4691-bba7-6e9e65127663	ADOC	\N	ADOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
108d1258-df37-4cc1-979f-a8c62ae7f8ec	ADOCHA	\N	ADOCHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d54e185-4313-4fdf-baca-a44dfa7c4cdc	AdoDigitFamX	\N	AdoDigitFamX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6c7d985-0af4-4945-97d6-99ce8e8c2612	ADOLESCENT DEV	\N	ADOLESCENT DEV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd21e28e-6452-40c7-b3f5-2d3b02de44d0	Adolescent identity	\N	Adolescent identity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7da81b40-e457-41c1-a769-bc862a8e5553	AdOMiS	\N	AdOMiS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
35d9acee-8e03-4534-b21c-ca17c756d5b1	ADONIS	\N	ADONIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
267834a3-af47-4347-adca-5e8f5c8de9f0	ADOPD	\N	ADOPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c32e034-0c96-49d1-ac0b-c8c2c9815a92	ADOPSYS	\N	ADOPSYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
15fe3b8e-0468-4211-a94e-f7b52b4dd3ea	ADOPT BBMRI-ERIC	\N	ADOPT BBMRI-ERIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
50cdc61b-ac18-4152-a5d5-0909e63ab1ad	AdOptEx	\N	AdOptEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b9d20f88-07ff-4518-a86b-e9cf838d1183	ADOPT GRANDPARENTS	\N	ADOPT GRANDPARENTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2ffbdf1a-af42-4c21-b9b3-bb92bf7c0d81	ADOQ	\N	ADOQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f2cc6cd4-d050-4343-a0a5-6c7b74a3d8d7	ADOR	\N	ADOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a80788e8-625a-4ab4-ad21-2e57bb96a2e7	ADORA	\N	ADORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3900d55-07e6-456b-9817-c557639c5a0c	ADORNO	\N	ADORNO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a6b05f20-8d6e-4512-8e06-88bdc272ae37	ADOS	\N	ADOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
94ebef3e-b107-4cb3-aa1c-be2bfd4c27b9	ADOSE	\N	ADOSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e05ed7dd-532d-4b3a-acac-6bace381ef19	AD PATHOGENESIS	\N	AD PATHOGENESIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ecfa78d-f9e3-43da-8770-f08936e4d803	ADPROGRES	\N	ADPROGRES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
25398598-6f5e-4525-9b97-b9a8a46bee6d	ADR1EN	\N	ADR1EN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3a09a83a-70df-43cb-a504-b01dca517742	ADREEM	\N	ADREEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8431bb3a-98d0-4fef-8e9a-32e15cacf022	ADREM	\N	ADREM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
871ffecf-8d1a-4734-b2ca-c82fe5fb5fb8	ADRENAL ENZYMES	\N	ADRENAL ENZYMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
706d5ad8-bb66-4a1d-b6b9-f8c4ea8e4039	Adrenergic receptors	\N	Adrenergic receptors		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d7e32879-55d5-4ddc-90d7-4b08d97833d5	ADRIA	\N	ADRIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96c7ee44-1e08-4e24-8a2c-3d4ef66d872e	ADRIANA	\N	ADRIANA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e871563b-281c-49a1-87ce-f49f0550727d	AdriArchCult	\N	AdriArchCult		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d9c3db1-6804-4ac9-8ded-220486791d1a	ADRONE4LIFE	\N	ADRONE4LIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6dfc7f25-836f-4429-b1e1-7bb51770366a	ADS3DV	\N	ADS3DV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2affb95a-d7cf-4668-8897-9b109eb312d1	ADS CFT	\N	ADS CFT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e9071a07-edc3-4248-a88b-cf681df9a396	ADSCFTBNF	\N	ADSCFTBNF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a89266cd-28f1-40ee-92f5-8ea4dcd522b1	ADSCFT MUNICH	\N	ADSCFT MUNICH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5347cf03-63b7-4080-a9af-6384ad4e6a66	ADS-CFTSINGULARITIES	\N	ADS-CFTSINGULARITIES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9079c3d3-d944-482a-b420-0d2ebc9edb0a	AdS-CFT-solvable	\N	AdS-CFT-solvable		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c1b73ac0-d655-4aab-81ef-05c5cd17e961	ADSEAT	\N	ADSEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e919f431-0541-4b69-8b45-cbd5c80c6310	ADSNeSP	\N	ADSNeSP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
879ac25a-f675-419c-8941-60060c4d49e5	AdsorPLAYERS	\N	AdsorPLAYERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d7fe148b-2f58-4987-9c5b-140ca9b424c0	Adsor-Resor Cycle	\N	Adsor-Resor Cycle		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4729fb1a-d765-4bd1-9803-1296ce394741	ADSOR-RESOR CYCLE	\N	ADSOR-RESOR CYCLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b4e335e5-ccdb-4191-bf96-ac19dba6a538	ADSPRA	\N	ADSPRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
55f3fb89-64c2-424e-b41a-bd2998ff7d5b	ADS Project	\N	ADS Project		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8fb14c8-9d1d-406c-a583-4b75349eeb51	ADST	\N	ADST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bd0383b0-db3d-4d7b-b6b3-a0a92f5919b4	AD SYNAPTIC DEFICITS	\N	AD SYNAPTIC DEFICITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
516332e1-cad8-46a5-852b-e6dbe2b2c325	AD-TO-STORE	\N	AD-TO-STORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f0f7518-20d4-4543-9fc9-bf83b7d3d921	ADUKKIPA74	\N	ADUKKIPA74		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4fd08dca-d878-4dca-8af6-457b805ac018	ADULT	\N	ADULT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a5d75ac8-c2b9-4e67-a7a9-0eddd19a2501	ADVAGEN	\N	ADVAGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
898b2648-db05-45b5-9e55-f7270e1de266	ADVANC1-METH	\N	ADVANC1-METH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
33cf9a76-001c-4de0-bab6-01fbc26abb89	ADVaNCE	\N	ADVaNCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2bb1ec94-0791-44df-83ee-089582c34ad8	ADVANCE	\N	ADVANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88e73f5c-bdee-430d-a9fe-4b75606ced9c	ADVANCE-AGT	\N	ADVANCE-AGT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2c09a28e-e62e-4467-9b2a-f18985aa8adf	ADVANCED	\N	ADVANCED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f033996e-9300-426f-b6f3-c3084118f779	ADVANCED BIOANALYSIS	\N	ADVANCED BIOANALYSIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe69e07b-4bc6-400e-b493-87c9af1b3a90	ADVANCED-BIPV	\N	ADVANCED-BIPV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
077ddfad-8f2e-4784-ab91-27d151a17eb2	ADVANCEDMODNEURO	\N	ADVANCEDMODNEURO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
24889a01-8846-4d04-9c27-5efb3a27c590	ADVANCED_SAR	\N	ADVANCED_SAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6dbf90d2-eb48-4f09-a1fe-f67779ba4b8c	Advanced-SiMP	\N	Advanced-SiMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3fe5b7d-86a8-466b-baa8-e4243ecb34d0	AdvancedStarForm	\N	AdvancedStarForm		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b5210f39-83ce-4c71-b284-b785b3bc1f03	Advance_eLTER	\N	Advance_eLTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b1f441c-01c0-48ea-bd09-07ff048ccce2	ADVANCEETV	\N	ADVANCEETV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df0f1a3b-002d-4cff-a48d-687073dfd469	ADVANCE-FSP	\N	ADVANCE-FSP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f80a7c3-58f2-4302-b5dd-f6fca8baa677	ADVANCEFUEL	\N	ADVANCEFUEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e44172a3-01ae-410e-938d-2e5d493e78d6	ADVANCE_HTA	\N	ADVANCE_HTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
388ad261-ee50-4be1-9c3e-8b0852019c2f	ADVANCE-SIS	\N	ADVANCE-SIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8906e87c-3f41-4135-b856-6c92f9770b09	ADVANSYS	\N	ADVANSYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cbec7b21-800c-4aba-ad7e-c3eceaa27b00	ADVANTA	\N	ADVANTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4051faad-50f2-432b-9de9-66dcd1c90bc5	ADVANTAG5	\N	ADVANTAG5		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
096f4ee0-c733-40ac-b176-c4115c1e21a6	ADVANTAGE	\N	ADVANTAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b97cf073-d450-4fe8-907e-aaf92a4709dc	ADVANZ	\N	ADVANZ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d940fcf2-3e59-4298-9fea-75cc2b637200	ADVASCULATURE	\N	ADVASCULATURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f64eb26-783d-4456-85f8-6defe293b3bf	ADVCARBONMATLS	\N	ADVCARBONMATLS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8152eebe-a2c6-4f30-98fb-133aa4c588e1	AD-VEC	\N	AD-VEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c97d90e3-88f6-48a3-bd1e-4f75f953d944	ADVENT	\N	ADVENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d586e120-b9f2-4431-81a1-da6aab1f737c	ADVENTITIA	\N	ADVENTITIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa26031e-53bd-4449-800f-824728d3e9ae	ADVENTURE	\N	ADVENTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1f91053-6a9b-4726-817a-fb4fff0fb800	ADVERSARY	\N	ADVERSARY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
febaff58-4f66-4f49-ac6c-825e43ab4ce7	ADVICE	\N	ADVICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eee622f8-01c7-4010-ba54-73bcd2943966	AdvIOT	\N	AdvIOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bbca29de-4867-4275-98a6-808e04074e58	AD-VIP	\N	AD-VIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f4765306-e141-4248-89e0-214e9639413d	ADVISE	\N	ADVISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
73fd3960-f1a4-4464-ad6f-fefc63639d6a	ADVITAC	\N	ADVITAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
03056cf6-5cb8-40b9-b56f-7d15eed5f6b1	ADVOCATE	\N	ADVOCATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9594265e-4772-4761-a3af-32961628067f	ADVODID	\N	ADVODID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
638fc085-b719-4ab8-a2c2-0705910c8516	ADVOLUTA	\N	ADVOLUTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5bd508d9-88cd-467d-a469-08647fc059a2	ADVOS	\N	ADVOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8bcdafe-5b29-40da-99d7-b63114e8b491	ADVOS-COVID-19	\N	ADVOS-COVID-19		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e225dc8-7d76-477a-b732-8e816b2f12dc	AdvRootAgeStrig2010	\N	AdvRootAgeStrig2010		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22a81ac0-c4ba-4dc5-8438-2b419f82b196	Adv-SAEC	\N	Adv-SAEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
321b519a-a254-4757-a661-7fe24dd12c56	ADV VISUAL OPTICS	\N	ADV VISUAL OPTICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
00e0c606-68b5-4592-b963-fb69c68d71c4	ADWICE	\N	ADWICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cb442bb5-7500-4f42-97b5-ae9a60a08826	AD-WINE	\N	AD-WINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d787ba0f-4e6a-45aa-9aa9-70787b5db991	AD-WISE	\N	AD-WISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0df48fa-aede-43e3-9cd1-4e134dbfed96	AE4EU	\N	AE4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5b877906-d4d0-48fa-998a-fd6f9112d450	AECE	\N	AECE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58ad24df-0750-4d99-9b11-bb951ed984d1	AED	\N	AED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3604e289-a4b2-4016-b7c7-ada6a7dea716	SH1	\N	SH1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
357c3c02-450c-492b-8601-3764952a0009	AEDIB|NET	\N	AEDIB|NET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2e8bba19-9978-4f1c-a2ce-b3a6077b706d	AEDMOS	\N	AEDMOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
787be3fa-b4cb-4a5d-9248-900bb48d9882	AEDNA	\N	AEDNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4f1a64e4-3096-4381-920e-b05a7b619e3c	AEDNET	\N	AEDNET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2264aa3e-0fc9-4cbb-a4b3-2a25b1eaccda	AEGART	\N	AEGART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bb8fcc0d-bc9d-4d59-af70-578d4190a37c	AEGILWHEAT	\N	AEGILWHEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
82eeecc3-8611-44fc-88fd-1aff850a40c7	AEGIS	\N	AEGIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6df3c3fc-6a26-4bdc-a52d-16f2e0e48a5f	AEGLE	\N	AEGLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
00b0638f-61ec-4fb1-84a2-2458010ea798	AEGOS	\N	AEGOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8ccb846d-74ec-4031-8c54-fe8204591d94	AEKSP	\N	AEKSP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aebd5f13-2119-4f65-b1aa-4feff390b2a3	AEMMPN	\N	AEMMPN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
81bb1336-4317-45d8-9b0c-69a56b987c67	AEMS-IdFit	\N	AEMS-IdFit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce8dfa89-0ba5-41ef-8b6a-2b852666d860	AENEAS	\N	AENEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8cb2cf56-c39b-4fa9-8673-69226050f863	AEOLIX	\N	AEOLIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9b94a810-6c84-4bf8-9812-2eaff25d3752	Aeolus	\N	Aeolus		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58d8ad6b-40cf-43e7-84f7-527900bc8f05	AEOLUS	\N	AEOLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e9fc911-2621-4502-822d-ea9c6fa28da4	AEOLUS4FUTURE	\N	AEOLUS4FUTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1030fb9d-2116-467e-9aee-537aa0c8090e	AEOM	\N	AEOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
21bb6963-7954-437f-9d56-977600ee1a0c	AEON	\N	AEON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e6ac3aeb-734f-4149-922b-6d134dcc1201	AEONS	\N	AEONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c08aefcb-57c4-4565-ada8-8e679313a945	AERA - Pro	\N	AERA - Pro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
414fe456-38d3-4563-b06f-8bc402cd8ebd	AERAS	\N	AERAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa27cc30-4355-4b57-b654-9f767791343a	AERFOR	\N	AERFOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39bfcf54-168b-49c6-91a4-e2853b3df473	Aerial BCP	\N	Aerial BCP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7b99a6da-6a0e-477e-a306-eb0e84164ede	AERIAL-CORE	\N	AERIAL-CORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5d6fe61c-99cd-4861-9b97-7feced1e4b3b	Aerial Insights	\N	Aerial Insights		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
723abc8f-1c03-4f76-afca-35941d7d7422	AERIALIST	\N	AERIALIST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
834ed7ca-34e3-430a-bfab-c6ff492e8ecf	aEro	\N	aEro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
77e09707-ff94-436a-b1bf-de977cfc8fed	AERO	\N	AERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
002f54c3-ea4b-4dfe-b2bf-03ad1e1289da	AEROAFRICA-EU	\N	AEROAFRICA-EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
89b1b780-5fda-46ae-b3d9-561c36ac1a53	AeroArch	\N	AeroArch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce381e3f-7c01-4ab9-bb95-2ed286ec1802	AEROARMS	\N	AEROARMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
74a96cb9-c38c-46a7-8f65-083f47c29261	AEROBEAM	\N	AEROBEAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc147e0a-3236-42fc-ad5f-9102be2d8017	AEROBI	\N	AEROBI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d72a1bde-1f6a-4c27-b0bf-4324c4c8553d	AEROBIC	\N	AEROBIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
845147eb-273c-4f35-87c3-1c512fd22fe5	Aerobits	\N	Aerobits		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b2f7fc6f-2571-49c2-ac4e-ff08bee52992	AEROCAT	\N	AEROCAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d9d8b86-36e0-441e-afe2-6e237a83c33a	AEROCEPTOR	\N	AEROCEPTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
04062846-37cb-4b4d-a361-5ad100edb0f0	AEROCHINA2	\N	AEROCHINA2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2c39bfd-dd15-4cc6-a9c4-65b7b13da0ca	AEROCOINS	\N	AEROCOINS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
38432d0a-502c-4d60-a35f-5accaee79b1d	AEROCWE	\N	AEROCWE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0efb8be3-0d81-4d7f-af32-4cae1f7d7825	AERODAYS2011	\N	AERODAYS2011		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
76a941fd-1e43-4a0b-a49c-d8b3305f00a9	AerodaysUK2015	\N	AerodaysUK2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
70f92145-9236-4317-83f3-a2e88a9b5115	AERODESIGN	\N	AERODESIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0a084113-e794-4881-8848-65bc8556736a	AEROFAST	\N	AEROFAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47d2df95-b4a1-44df-a548-c7cb7e35cfcb	AEROFLEX	\N	AEROFLEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8ebb4953-7194-4aa9-934a-e8d894bfd8ce	AEROGLASS	\N	AEROGLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
87fa0a00-641d-446a-b84b-dab4c7643a65	AEROGUST	\N	AEROGUST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
48081a7e-f4a8-4c99-85e7-b913cb405f68	AEROL-HP	\N	AEROL-HP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7766eab0-4087-42eb-b918-a0a06a8c6058	AEROMAP	\N	AEROMAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d000ea71-4d0c-4241-96bb-dc2547b0685f	AEROMIC	\N	AEROMIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
93312042-3720-4c20-abfc-6ae427abcaa4	AEROMO2	\N	AEROMO2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f45d950e-55f5-48e7-95bb-422fea14cfe4	AEROMUCO	\N	AEROMUCO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f0a27bd-f8a3-4ffd-b976-e5f3966cf467	Aeropaft	\N	Aeropaft		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
acbfe6ea-0f9e-481d-8062-8caf5ee13519	AEROPATH	\N	AEROPATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d83021b7-9e78-4171-b84b-a20864716530	AEROPCM	\N	AEROPCM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bb4e7065-2529-4c56-866c-9eb422779d8c	AeroPlan	\N	AeroPlan		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
09f12fe5-f5a0-44b7-a7a4-44a28f02505b	AEROPORTAL	\N	AEROPORTAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a632fdd2-43ea-4ca9-ab99-5de52e7c16e1	AeroPul	\N	AeroPul		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3667d890-fc6e-4fca-a2c7-87e92fff4120	AEROPZT	\N	AEROPZT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0f048bf6-69d9-43da-8355-c785bb789acc	AeroSim	\N	AeroSim		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f345223d-7b07-4adf-910f-7d5e8ec5b383	AEROSIMULAT	\N	AEROSIMULAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d12f671f-1175-4d3a-9994-c2965c2db26c	Aerosint	\N	Aerosint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c4f6e4ce-a5e3-491b-8fb9-22e959fa1be2	AEROSOL	\N	AEROSOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0f732ab6-42d7-4729-a7d8-ea55a6a52e48	AeroSolfd	\N	AeroSolfd		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39f566fd-fde1-4f0e-9dc8-4952769cbc43	AEROSPACEPHYS	\N	AEROSPACEPHYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
850a4542-3ca4-415c-a07f-7995ed9c56af	AeroSurf	\N	AeroSurf		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ace5c7b9-cd4e-4e37-b991-8fed162cddb8	AEROTHERMOPROP	\N	AEROTHERMOPROP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c70aec32-ec21-4fcf-aba0-76b2c7c1bab2	AERO-TRAIN	\N	AERO-TRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec9398d5-65b5-4360-945e-e039b5f82ee7	AEROTRAIN	\N	AEROTRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed04cc7d-226f-4fb0-aaaa-886132f9f29f	AEROTRANET 2	\N	AEROTRANET 2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2859efb4-569a-4e20-9dbd-fdbae7d6a23f	AeRoTwin	\N	AeRoTwin		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52108880-7d3c-4365-b407-b831b5f2bd96	AERO-UA	\N	AERO-UA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5280a2fd-4974-4b00-af99-75ba0a836406	AERO-UKRAINE	\N	AERO-UKRAINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1844d9cf-a238-4e4d-86e3-7f46414c7463	Aerowash II	\N	Aerowash II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b9d9b62a-2742-4097-a0d4-db6bb788a3aa	AEROWORKS	\N	AEROWORKS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f476aa4f-8539-4428-b030-008ab14d5dbd	AerSUS	\N	AerSUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
668839d5-4980-46c5-a65d-b2bf5032e2dd	AERTECVTI	\N	AERTECVTI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b711c8b-08a1-4916-b92c-f5c0d3b15410	ÆRTOS	\N	ÆRTOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1cd89f23-7375-4e0f-8620-f15eb3df17f7	AestApp	\N	AestApp		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8f4a453c-0c69-4099-942d-2a5557b920e3	AESTHETIC INNOVATION	\N	AESTHETIC INNOVATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b147b505-c976-4f98-af75-3c690b454fe8	AETHER	\N	AETHER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3527dcd4-e511-4315-929d-d83823bfb10f	AETIONOMY	\N	AETIONOMY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b630cc7-30e7-4159-8b22-0460c733ab8e	AETSOM	\N	AETSOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cc810ec4-a61c-4d64-baae-042f121c8ade	AEVIOM	\N	AEVIOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29be9550-793c-4cf9-8e7c-5e1ca5598477	AF16	\N	AF16		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86ac16d4-ac07-478c-8d49-c0deedc70285	AFactory	\N	AFactory		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
32a24025-286e-46cc-89cc-8b975cd759ad	AF and MSOGR	\N	AF and MSOGR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
953608eb-922f-4686-a002-f48dad1d85fb	AF AND MSOGR	\N	AF AND MSOGR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a54c66de-e37d-4d39-a768-5ffd5b0c873f	AFarCloud	\N	AFarCloud		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9db3cdcc-0510-4372-b285-6857f125face	AFC4Hydro	\N	AFC4Hydro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
272e875f-f460-4c6a-ad65-d7e7522d54b5	AFC4TR	\N	AFC4TR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1be332d3-e69e-4725-b465-b5f67274bda7	AFCIN	\N	AFCIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c0277845-d113-4a41-a1cd-2ea43d3b5713	AFC-TEFL-HLC	\N	AFC-TEFL-HLC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e6e1ef0-17dd-47ff-8e63-68c1682cd9ab	AF-Cyber	\N	AF-Cyber		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c59a7704-aca9-4b73-86fb-7e9981470628	AFD	\N	AFD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37453ba5-6800-43ea-9faf-fbfebdbb22ae	AFDAR	\N	AFDAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3e9ec1f-7623-44c2-9ee6-84296e101603	AfDevLives	\N	AfDevLives		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e22eb519-ee08-419c-9e18-79ff00e299e0	AFDMATS	\N	AFDMATS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe22732b-fa7c-4312-ab45-bb1f177f8c44	AFEG	\N	AFEG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b4c2330-c82e-4f78-9ee1-56108dc96350	AFEL	\N	AFEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d4969f5-0ae8-481a-9f29-17298d7b86a6	AffecTech	\N	AffecTech		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
54e583ed-85dc-4fd4-b681-9e8b701b9b95	AFFECT-EU	\N	AFFECT-EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96e70b7e-7e9f-4acb-82e6-77c19dad7726	Affects	\N	Affects		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7538c695-687f-4e88-9bd0-aa3eddc918f9	AFFECTS	\N	AFFECTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9fec1095-d9e8-40d6-9bae-0f419ae3a47d	AFFINITY	\N	AFFINITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
756bdaae-2ec0-4cf1-8a4b-121723a7246e	AFFINITYPROTEOME	\N	AFFINITYPROTEOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e831443d-37cf-455b-9105-26d6a498eff0	AFFINOMICS	\N	AFFINOMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b67d5d14-bb35-49a4-b739-579b6190971d	AFFIRM	\N	AFFIRM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31ba445e-dcde-4bfc-92ca-394d5486dabf	AFFIRMATIVE	\N	AFFIRMATIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
62543b47-8899-47a9-aab4-b0782cc03927	AFFIRMO	\N	AFFIRMO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0722250f-5e18-4b1b-93ac-7385f16fc8ca	AFFMA	\N	AFFMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0b72b44a-62e3-4814-84d6-03b85ee88753	Affordable5G	\N	Affordable5G		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e06a0ce6-d183-4f0e-bd73-e79f5c2d33aa	AffordBoneS	\N	AffordBoneS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52bf4adf-17d6-433d-a162-e15047446a82	AFFORDS-HIGHER	\N	AFFORDS-HIGHER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88ed0d48-f7ad-4d56-89a5-cee5f3aba759	AFHELO	\N	AFHELO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
91a43bb6-6901-4e8e-9e80-25c943027098	AFIBROTIC	\N	AFIBROTIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d78978eb-0f35-40d9-970f-15b032685a9b	AFib-TrainNet	\N	AFib-TrainNet		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
77337267-0703-48fa-9573-ebfac4894bd8	AFINET	\N	AFINET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe522c85-ec43-40ad-af12-431fd19fb7ef	AF in Human Myocytes	\N	AF in Human Myocytes		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52bc8b09-69ee-4165-92ae-f6b8dd5837e5	AFIRMATIVE	\N	AFIRMATIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5140a2c9-6225-4dd6-8d5b-a138efb5d5a2	AFISYS	\N	AFISYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30f2a735-c978-407a-8368-51e084c31bd9	AFLOG	\N	AFLOG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5b439259-719b-45eb-8ed7-7c9c3675f99a	AFLONEXT	\N	AFLONEXT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e58edf09-5a84-4a3d-9785-6e23fff49d9a	AFloWTest	\N	AFloWTest		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b0ac65c7-ffd1-42e5-b86a-f6e3e1b3a184	AFMIDMOA	\N	AFMIDMOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f5b7d1d3-0749-486c-9045-d9343cc4687a	AFNAP	\N	AFNAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8ac6f208-046b-41a5-b8d0-38d48235e0c2	A-FOD	\N	A-FOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dee9da6f-7487-4a18-bf66-29f2eebb1f13	AFOOT	\N	AFOOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d8392b8-3dc9-48f3-bb60-0fcd1dea4b23	A-FOOTPRINT	\N	A-FOOTPRINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
65974e3f-4c4e-4519-aa38-2632211983b3	AFORE	\N	AFORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
944c2b6b-5bab-4543-8237-1f3a8aa665d2	AFOREST	\N	AFOREST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c6709b77-a341-4195-9023-0472fbf33889	AFPMeT	\N	AFPMeT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9aba4ab-d478-4694-9b23-74f9d5a17b3a	AFRAB	\N	AFRAB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8512a2f0-5190-4ce9-80f9-007abd13a8cc	AGAGAP	\N	AGAGAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7950dfe9-b1d7-4acb-9e6d-b6599e7a4c8e	AFREELAMIDE	\N	AFREELAMIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9868df30-0506-432d-ae43-a49c65bfed24	AFRESH	\N	AFRESH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d4c0620-8442-4484-a003-410eb10c01ba	AFREXTRACT	\N	AFREXTRACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ca7034b9-c5dd-473e-83fc-f10f79be3308	AfriAlliance	\N	AfriAlliance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf72949c-edcc-43ee-8a10-721c46f13648	AFRICA BUILD	\N	AFRICA BUILD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cba4a24-1159-4fc3-84a4-1939ea272ff4	AFRICA-GHG	\N	AFRICA-GHG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0b14099-48e9-465f-9e5c-e2c7d8b0bc0d	AfricanBioServices	\N	AfricanBioServices		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d9887120-80a5-4322-aba4-2835141a8b60	AfriCAN Climate	\N	AfriCAN Climate		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7526f62e-b0ff-4225-b03f-af5c8ead3041	AfricanMigrantWomen	\N	AfricanMigrantWomen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
74f7686b-232a-4dd4-8b57-9abe01b7bb6e	AFRICANMIGRANTWOMEN	\N	AFRICANMIGRANTWOMEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78f2e9e6-3591-4bb7-9b82-0c96e5a1413e	SH2	\N	SH2		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f403486c-8f44-4bd9-9e26-1768375c1a7a	AfricanNeo	\N	AfricanNeo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b999c329-3832-4b0d-a97b-0f0c6d5e9f65	AFRICAN TRAVELLERS	\N	AFRICAN TRAVELLERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
071100c3-ccd4-4ef4-bc19-ad70715e283e	AfricanWomen	\N	AfricanWomen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
021375ea-7f0c-4021-84e1-d1bfc4842012	AfriCoLeish	\N	AfriCoLeish		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6f1d054e-9563-4fe1-b072-4840304dc88c	AfriConEU	\N	AfriConEU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
db43044e-070b-436a-a9c3-9702fb3179ab	AfriCultuReS	\N	AfriCultuReS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9bd3f0d1-e1b9-49ad-a570-8a5245989336	AFRIGOS	\N	AFRIGOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d8c2c02d-8e36-4cee-8fc6-21e2d8c637ea	AFRISCREENWORLDS	\N	AFRISCREENWORLDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37b5660d-bd00-4d1f-b15a-c39dcf0b9bd0	AFRI-SKYFOR	\N	AFRI-SKYFOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
459fc485-a681-4d31-a19c-09f8fa0af86c	AFRIUNI	\N	AFRIUNI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8f8da3d5-3465-4fc6-9072-0051a26840d4	AFRIVAL	\N	AFRIVAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9e9049c9-8ecb-427a-add1-272e8d759890	AfriVeg	\N	AfriVeg		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bc03356c-ada8-4f9f-bd8f-9a117db23eb6	A-FRO	\N	A-FRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d4420dd-0257-4bdb-96a4-eb61bebdc0a0	AFROBRIDGE	\N	AFROBRIDGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fda0f96e-822b-43e3-9684-e28a56be2fc7	AFRODITE	\N	AFRODITE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d5b9a94e-88ec-4fb8-879b-5ea67fd91689	AFROEUROPOLITANS	\N	AFROEUROPOLITANS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
79a28ef8-1941-4066-9578-07282d6de5ab	AFROMAISON	\N	AFROMAISON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a8cb78d7-25c9-41f0-b1fe-7d13216dead2	AFR-PD	\N	AFR-PD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9be7769c-f0da-47be-9ebe-8a4f44d3bdaa	AFR-POSTDOC	\N	AFR-POSTDOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
27c478d0-df37-4433-b38e-482c7840ae6a	AFSIAL	\N	AFSIAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e01d4f2d-f358-4b20-9505-ddf644a66743	AFSID	\N	AFSID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8de1e113-0ce1-4cf4-bbe8-dda4fa0fd231	AFSJ-AGENCIES	\N	AFSJ-AGENCIES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c4ad1144-50df-4ade-a6ee-6f1e057c0f7f	AFSPAN	\N	AFSPAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1cb4e17e-02e6-4cf6-9566-2291c58a330b	AFSPPEOAS	\N	AFSPPEOAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ffec32c0-3991-4fec-aec6-f432b0b5dbb7	AFTAT	\N	AFTAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a865e4ce-0945-44af-8636-83aa38704084	AFTER	\N	AFTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4f77d8a1-d4ec-404a-8c17-591f4f4bd371	AFTERBIOCHEM	\N	AFTERBIOCHEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
094d3fae-c3b7-48b7-93c4-eb62edc6b554	AFTERLIFE	\N	AFTERLIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae24bebe-75c1-4cd1-9745-ab43fcdd7e3e	Aftermath	\N	Aftermath		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58ac0c9a-b44b-4cea-8fd8-6fb5fb149993	AFTERTHEGOLDRUSH	\N	AFTERTHEGOLDRUSH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6ed11fea-c421-475c-b4ac-6671ce755d10	AfterTheIce	\N	AfterTheIce		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5cc08b95-f2d7-4b9c-b2a6-86a99308bdae	AgainstResistance	\N	AgainstResistance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3d759937-8a75-453b-9b40-e29ad090d15b	AGALT	\N	AGALT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d25782d6-1d75-45d7-8cfd-425085a31b43	AGAME	\N	AGAME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b864d507-ed33-4839-9910-c8eca43df132	AGAPAC	\N	AGAPAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fbf4e7d7-cf58-46cd-9304-645aa022ccb6	AGAPE	\N	AGAPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4f301a34-a1df-4186-83af-5c158bd51ef6	AGATE	\N	AGATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
947d6b8c-1b8b-45d9-8aa9-cddee80bc093	AGATHA	\N	AGATHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
87524374-7a6b-4012-adbf-898283d78a94	AGATHOCLES	\N	AGATHOCLES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
70f32229-6341-4654-93dc-60763ae10e57	AGATM	\N	AGATM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a484c75c-da05-42c2-b572-e22bfe9a5451	Age Asymmetry	\N	Age Asymmetry		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
84d43787-7886-4f42-9568-8648850f4af6	AgeCogCity	\N	AgeCogCity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5cf4be25-b293-4365-8b4c-324d122d7d3b	AgeConsolidate	\N	AgeConsolidate		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b007d2f5-c68d-4ed7-bdab-bf8057e1f9ec	AGEDBRAINSYSBIO	\N	AGEDBRAINSYSBIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a5eb625-ed2b-459f-98ca-d58b5f5dd652	AgedLGBT	\N	AgedLGBT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9d8ee35d-0272-4ec3-840b-1cf7d2fd2d8b	AGE-FRIENDLY	\N	AGE-FRIENDLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e38c7b5-3a61-41d0-9e6f-ce81717105e7	AGEING AND RS	\N	AGEING AND RS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0d232f67-169e-400d-a156-235ffa5792ca	AgeingatWork	\N	AgeingatWork		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0940e83a-cfcb-4669-914b-8e7653d4fec8	Ageing Network	\N	Ageing Network		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0c9b4083-2dbf-4df9-bbd8-1671515997f5	AGEING PLASTICITY	\N	AGEING PLASTICITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6f0c6c2f-bf16-40c7-973e-dd1558275f46	AgeingSexualConflict	\N	AgeingSexualConflict		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fff731f1-a75c-42a8-8295-85f57a76c96b	AGEING SKELETON	\N	AGEING SKELETON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29de9934-8727-460f-82f5-0a500a1cdaef	AgeingStemCellFate	\N	AgeingStemCellFate		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3da55b2e-329b-4d98-bfcc-ba2d5292eeed	AgeingTimeUse	\N	AgeingTimeUse		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
70f7f2b1-fe7c-41d7-a7c8-d99eba9ec9b8	Ageing with elegans	\N	Ageing with elegans		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
02a5dc55-ac58-4c70-86ad-cc827204f96c	AGEISM	\N	AGEISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa8569e0-d4a2-407a-88aa-f4cb44a38ff7	AGELESS	\N	AGELESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
897ad316-860f-4c47-99b4-d7cdcb41d2be	AGELYSPARK	\N	AGELYSPARK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
775e38c7-c9e7-4715-8108-1ce94428a7cd	AGEMEC	\N	AGEMEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d4b9c1d5-9215-438b-962b-e79ce9b47723	AGE-MEMORY	\N	AGE-MEMORY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9e8f68ba-a75b-486f-aad2-fdcb4c0cb1be	AGEMERA	\N	AGEMERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
846e3974-7a9e-46c6-a532-e332361c35af	agen	\N	agen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
774a27bf-a7fd-4f2e-b8f5-6708daa16fe9	AGenDA	\N	AGenDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4e350d92-b0ef-4e5d-87f9-89f796d5e693	AGENSI	\N	AGENSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2feb8636-9e7d-4ae8-99db-c17d1cadd4d7	AGenT	\N	AGenT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7cd92994-73c7-44bd-a04d-d1b1c2f902a1	AGENT	\N	AGENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0fe8293b-2cc9-4d46-a1ca-39eea0e82e2a	AGENTA	\N	AGENTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c1e87731-ddc6-4d5d-b491-ed08a569c6d6	AGEnTh	\N	AGEnTh		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b6998f08-1e17-40ad-9942-abe3a13dd481	AgentSeal	\N	AgentSeal		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
27b62a83-8839-450c-95f2-685625903f62	AGENTSEGET	\N	AGENTSEGET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d855a97e-d59b-449e-9eb3-a2807937ecf9	AgePhagy	\N	AgePhagy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dfee11ca-54b4-4035-9433-66ffee166622	AGePOP	\N	AGePOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8157b3a2-8b6b-491f-af92-93493f662b43	AGERISK	\N	AGERISK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ab7d8662-6c11-4fb0-bb36-3179d7e1b944	AGERPIX	\N	AGERPIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
67d83ed0-8604-411b-90f8-0e44bafd4be5	AGESPACE	\N	AGESPACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
13d7357a-2be6-40b0-99e5-babbbe4da7a9	AGEWELL	\N	AGEWELL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
013c8d67-811e-4fff-b8ef-301c3f721115	AGEYE	\N	AGEYE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6e361210-87da-4549-9860-8823a3e42f9f	AGF	\N	AGF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8e4dcdc7-ce0f-408e-a736-980e1f7dbf78	AGFOODTRADE	\N	AGFOODTRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
14cb9a1b-2175-4ba1-9a57-567388070cb6	AGFORISE	\N	AGFORISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba92ab1c-92c5-40de-bccc-5e800dddbb26	AGFORWARD	\N	AGFORWARD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f7b1e560-8043-4904-ba73-cb5eb4699cea	AG-GF	\N	AG-GF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
250bff82-9e80-4dac-9fe3-e25e9dbdd3cd	Agglomerates	\N	Agglomerates		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ac1574b9-c3b6-498d-b4c5-fe6eca86c608	AGGLONANOCOAT	\N	AGGLONANOCOAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9957301d-6060-4499-ae3f-f5ef9d31c24f	AggregAT3	\N	AggregAT3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
494e8b89-216c-43be-ad6f-4d2ac808e2d6	AggregatingProteome	\N	AggregatingProteome		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1b256d5-a371-4cdd-9b6e-3725cb5cdebe	AGGREGATION	\N	AGGREGATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
28b7a117-2858-44f5-b5cb-c9996a14fd69	AggregationKinetics	\N	AggregationKinetics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
36b3a84c-69e2-4440-8d31-6b891d36c45b	Aggregation selection	\N	Aggregation selection		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b61ca04a-b457-4246-a74f-c64c2bc681cd	AGGRESSOTYPE	\N	AGGRESSOTYPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1bdde6fe-a6bd-4aa5-b141-56dec44d77f5	AGG-REST-WEB	\N	AGG-REST-WEB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9246d59-ba1e-4249-b8fe-05946f116d44	AGILE	\N	AGILE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80f48fd5-c96b-4852-af84-f2066ab0bac6	AGILE 4.0	\N	AGILE 4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5f67b5b1-5941-45a9-a36b-57d062ce17fc	AGILEFLIGHT	\N	AGILEFLIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56355d4b-bb31-475c-bbea-110c749a71b6	AGILE-KWS	\N	AGILE-KWS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9dd9be59-c3b5-4dcd-ac76-2fb52763af91	AGILENET	\N	AGILENET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
52f4857c-a744-4e91-9264-911a1c66668f	agINFRA	\N	agINFRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f50d173-63c9-400a-8b65-f568f69fac04	AGINFRA PLUS	\N	AGINFRA PLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3d490a63-a8dc-48cb-8302-e177ad2ccf2e	AGING_HORMONE	\N	AGING_HORMONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6a74bfad-bf65-4dfc-8193-11ab6a8a3d42	AGING MATTERS	\N	AGING MATTERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
862d87b4-8ebf-4154-9f3c-446371ce20d2	AGINGSEXDIFF	\N	AGINGSEXDIFF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f84a9fb-f439-45bb-9e38-e5896c0c9213	Aging stem cells	\N	Aging stem cells		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e94b76eb-2fa7-4c73-a184-dcf33ffd20cd	AgingTimer	\N	AgingTimer		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
858eb24c-c4be-4baa-8945-42682e0893f5	AGINSURANCE	\N	AGINSURANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc50b9b1-5e6c-4bad-8005-150cffb6550a	AGITATORCBM	\N	AGITATORCBM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a9a0ce7-937e-4fa2-b286-3bcda69b41ad	AGLARIS	\N	AGLARIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2d54e64-f8a5-4240-a871-f94d062037b9	AGLYC	\N	AGLYC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0e6cf51a-032f-4ec3-842d-e7fa06cd7f76	AGMS	\N	AGMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f7d8aad0-b12f-48df-916c-c88a702fe91f	AGNES	\N	AGNES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c10c471-f04e-4274-b2fc-8178df36b480	AGN feedback	\N	AGN feedback		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e5ed73d-cc07-4af9-a394-af46725088b3	AGNOSTIC	\N	AGNOSTIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c06e236a-c343-4670-b5c1-b40495d485d4	AGNPROBES	\N	AGNPROBES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e3def2c1-a0ee-4cf6-b8cc-ed9bc3dc1d55	AgoIM	\N	AgoIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
41a64a5a-6b2a-4bef-8e0d-848025b86fdd	AGORA	\N	AGORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa2fd6ac-8847-4652-adf7-abab8cc540ca	AGOras	\N	AGOras		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
53e1bbe6-2063-4f4a-be33-477e88025bf1	AGORAs	\N	AGORAs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e243165c-ca76-4d7f-a4d4-f6c8e3c96cfe	AgPro4CSA	\N	AgPro4CSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2f5d2efd-0934-4bd6-b8e8-91a553553286	AGRAL	\N	AGRAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
08ce8365-db78-4604-a20a-f420e683d9da	AGREE	\N	AGREE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a5c19ad3-2893-4933-b176-f232e18efbf5	AGREENSKILLS	\N	AGREENSKILLS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78c45d73-885d-4e95-9849-f65522ef4875	AGREENSKILLSPLUS	\N	AGREENSKILLSPLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60500d17-b767-4f27-a270-a08e19b4064d	AgRefine	\N	AgRefine		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
530906af-ec15-45ae-b4a8-d81e3820f94d	AGRELITA	\N	AGRELITA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56d9a9f9-487d-42d0-b33e-6549ed9e2bb2	AgriBIT	\N	AgriBIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f9e905b-6c28-40bd-bbd8-e4745027d5d8	AGRICAB	\N	AGRICAB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
740480b4-8e14-4bc8-9d29-641f73e1e6af	AGRICADOPT	\N	AGRICADOPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ecf62769-026e-4c29-bf94-0b9dfd4bc828	AGRICAM	\N	AGRICAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3d7518e5-2200-451b-bcaf-4d14279cea5b	AgriCapture	\N	AgriCapture		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a56c630d-b3ad-4b3b-be17-06565a30de1d	AgriChemWhey	\N	AgriChemWhey		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c6b8542-2392-412a-8c08-aa7c967c77c1	AGRICISTRADE	\N	AGRICISTRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b4903b29-a522-4e3f-b0a7-f0429e626ccb	AGRIC-LASERUAV	\N	AGRIC-LASERUAV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6c96f485-0afd-44d9-832a-d3ba5dd8dad3	AgriCloud	\N	AgriCloud		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
99b5fe59-e6dc-4c54-9288-320878280ba3	AgriCloud P2	\N	AgriCloud P2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3b7e967-52bf-401b-b750-8538f18d69d2	Agricolus DSS	\N	Agricolus DSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6d50f7cf-250c-4eae-80c9-cd215d7621f7	AGRICON	\N	AGRICON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
70697d70-8176-4ffc-bf96-0cf69072755a	AGRICORE	\N	AGRICORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
05b9e142-0657-4dd3-b274-41d7cfc82006	AgricUrb	\N	AgricUrb		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9064d1c2-41c3-4bdf-b000-ac6e13521d71	AGRICYGEN	\N	AGRICYGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9b5fbae4-27a9-41a2-98ac-350a9ff33b5d	AGRIDEASCOURSE.TRADE	\N	AGRIDEASCOURSE.TRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31c66720-24b8-4fad-aaee-a9c637e51f63	AgriDemo-F2F	\N	AgriDemo-F2F		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2d6a741-4a94-4936-8dfc-4a4093f7b031	AGRI-DRONE	\N	AGRI-DRONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce0740ef-06fa-40a8-b83a-54ba4315923e	AGRI-ECO SERVICES	\N	AGRI-ECO SERVICES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
907fb9b9-8f9c-44dc-b67d-3779a948f3fa	AgriFoodBoost	\N	AgriFoodBoost		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
383955fd-f710-4ae6-9889-50d6ed49c4d3	AGRIFOODRESULTS	\N	AGRIFOODRESULTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47380c71-5d0d-46cb-9a69-12630034667e	AGRIFORVALOR	\N	AGRIFORVALOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cee3eaf4-c01a-4045-a9bd-c63d091182d8	AgriLink	\N	AgriLink		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe5b0bef-f618-45c3-b38f-c02fd9515128	AgriMax	\N	AgriMax		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6ad514c-856c-4a65-89b1-927c9d917194	AGRIMKT	\N	AGRIMKT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
becae6d7-b873-4064-ae13-cd370e7c75b7	AGRINA	\N	AGRINA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3ae5f2b-1bc8-44c4-b327-7269dbee0b31	AGRINUTS	\N	AGRINUTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c92575c1-6dc5-4e52-9400-c268196f852a	AGRIPOLICY	\N	AGRIPOLICY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c0930c1d-07da-4fdc-bb28-08fcd1a63484	AGRIREFORM	\N	AGRIREFORM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
54f2422c-0a65-477f-8f19-7ac71705efda	AGRISAFE	\N	AGRISAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
335ee13c-7424-4b30-af1f-a038c829f72f	AGRISCENTS	\N	AGRISCENTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c421a185-7c57-4505-b0c2-32791bf7e99f	AGRISCIMONT	\N	AGRISCIMONT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa74cf0c-19d6-40b0-bfbe-059977b3356b	AGRISENSACT	\N	AGRISENSACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4c03ca45-15e3-427c-8247-53a996a920ee	AGRISPIN	\N	AGRISPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7cedb7b6-e930-4984-9430-9243026aa17f	AGRIWESTMED	\N	AGRIWESTMED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e06ee069-06de-4025-8e83-8cbd5d1058be	AGRIXCHANGE	\N	AGRIXCHANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
09cbdd1a-8d22-41d3-b07e-ac8484e0d36b	Agro2Circular	\N	Agro2Circular		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
085b2612-d84a-4d18-b987-b77c730dac9a	AGRO-AMF-AOX	\N	AGRO-AMF-AOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c4836193-2e41-4caa-9371-c3313c9f7d9d	AGROBIOFILM	\N	AGROBIOFILM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
848433f7-25d5-4cb8-8476-35056846f4f6	AgroBioHeat	\N	AgroBioHeat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39b2fd1b-ba71-43e9-ae70-254a80c7f207	agROBOfood	\N	agROBOfood		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2ceaefc8-452b-4419-b761-fed5eea5d845	agroBRIDGES	\N	agroBRIDGES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a0c4c1da-9271-48c3-819f-25b92ecfd06b	AGROCLINICAL	\N	AGROCLINICAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f093cfd-535b-4966-8aae-eda84c3b7b07	AGROCOS	\N	AGROCOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60dd1149-4728-4869-a569-c2501c3d00bb	agroCYAN ECO	\N	agroCYAN ECO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96e37a78-7a0b-4c52-a1d4-5d7a6cd05373	AgroCycle	\N	AgroCycle		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1cb9e611-e30d-4fda-8574-bcb7001a23b3	AgroFossilFree	\N	AgroFossilFree		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0feab953-7bdd-464c-8074-4a99b891b1c0	Agro Highway	\N	Agro Highway		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9214817-e15f-40a5-9151-6c2b203524a0	AGROinLOG	\N	AGROinLOG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a88e6a2-c793-466e-a72a-0c8fa7339933	AGROMIX	\N	AGROMIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc97fdf3-b4dd-4d35-8be7-aed261d47e03	AgroPellet	\N	AgroPellet		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8f116cdd-bd88-481d-9709-926f9bcafa7c	AgroPestAlert	\N	AgroPestAlert		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d5d2d5bb-a44a-4ca7-a501-7613eb9f277e	AgroPHYS	\N	AgroPHYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
afd79f52-860e-46e1-b1f4-cca2c8112167	Agroptima FM	\N	Agroptima FM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ed0789a-83d1-45ed-b47b-79df3eea0f4e	AgroRadar	\N	AgroRadar		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d9574b44-939f-4be5-9f9a-e0a51033c082	AGROSENSE	\N	AGROSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b6e66ca-eced-41ec-8247-5ded6be19a16	AgroShelf	\N	AgroShelf		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a113590b-e215-4e2e-a8f6-9194b9140431	AgroStore	\N	AgroStore		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85b83a2b-4fd0-4761-a529-7903da802fdd	AgrowFab	\N	AgrowFab		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
49d6903a-4448-41e8-bc79-07a4e41e1cd6	AGRUMIG	\N	AGRUMIG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d11f84d7-0e91-4cf8-bb51-8b8053579dad	AGS	\N	AGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec1b9c24-cfeb-49fc-813c-8d7f40f78364	AGTECH	\N	AGTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b4b3dc3f-3ff2-435e-9224-dacd8d38e90b	AguaSociaL	\N	AguaSociaL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b369d3c5-bdd9-4eba-ab90-a110701a1b1b	ahead	\N	ahead		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a90a4418-9dd4-4658-9ee9-399e132724dd	AhEAD	\N	AhEAD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
57441768-dea2-403c-9ade-ed04cbd69429	AHEAD	\N	AHEAD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4561c752-9726-49cf-a716-59f3ae195a2d	AHEAD2020	\N	AHEAD2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
73e827b6-c59e-43af-a8f9-99cf5410713c	AHEAD III	\N	AHEAD III		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a912b91e-bd77-4c0a-b092-8465900dcb32	A-HERO	\N	A-HERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c53c6e9-8a21-4d34-a7ec-dd0e60ac694a	AH-GCOLSYM	\N	AH-GCOLSYM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
23e80b50-9948-4e2a-baff-1963defe8492	AHH-OMICS	\N	AHH-OMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
09d7c051-d3ce-46e4-860e-472d5139493c	AHICA	\N	AHICA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5a6fa7a8-6153-48c2-adcd-b16504ad471f	AHPACS	\N	AHPACS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
db8c70e9-be3e-4768-988e-129602aed615	AHRIMMUNITY	\N	AHRIMMUNITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0ead8b83-3ac1-43c3-82f8-ca9856b5bab1	AHUMSCIENCENET	\N	AHUMSCIENCENET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
89f2fd56-0743-43d8-b2c5-57c0285b83bd	AI2AM	\N	AI2AM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e6668bfe-b2c3-4417-a5d1-2f32cca1cd82	AI-2 Prodrugs	\N	AI-2 Prodrugs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2c90143b-9bcc-4dc4-b2af-78c6d2ee8fb1	AI4Cities	\N	AI4Cities		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
55f3af21-e3fe-4c17-b650-02405dd35a4f	AI4Copernicus	\N	AI4Copernicus		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b5e3238-8745-4500-bbd7-11b649b3cb4c	AI4CSM	\N	AI4CSM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a309ca74-7c5b-4e7d-a7f5-29c80848d2e1	AI4DI	\N	AI4DI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c9717e8f-fb1b-40d8-ab83-fbb877c303e3	AI4Dignity	\N	AI4Dignity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0e6b2f42-a799-4a83-831f-c154b0138d5e	AI4EMS	\N	AI4EMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ba53872-1a17-45be-8578-09853a23cb1d	AI4EU	\N	AI4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7232c550-b953-4888-afa6-d4aa6bc4dfe1	AI4HEALTHSEC	\N	AI4HEALTHSEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b63c9e9-9172-4729-86f2-fac9c788a947	AI4LABOUR	\N	AI4LABOUR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e727e1cf-129a-4aef-a298-dde795683917	AI4Media	\N	AI4Media		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b2c9f6c7-2e1f-4676-b6b4-399665f0d07e	AI4PublicPolicy	\N	AI4PublicPolicy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4ffc5a06-8986-43a2-b521-06bc2d5bc2c5	AI4REASON	\N	AI4REASON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
afaf43a7-98f4-42a6-88b5-aee258f02ea7	AI4SmartCities	\N	AI4SmartCities		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8606470e-c9cb-461c-9594-bfbb38db34d4	AI4theSciences	\N	AI4theSciences		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
39cd63c2-d3c8-469e-b297-0622d27c6cbb	AI-ARC	\N	AI-ARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d895cf1a-dcb0-47aa-90df-b0211bdc49d7	AIAS	\N	AIAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
682c0e2b-95f0-4dc1-9053-be2b6a7e1261	AIAS-COFUND II	\N	AIAS-COFUND II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e5b7e8e1-b25d-437e-add4-e7ae7beb0e65	AIASGA	\N	AIASGA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2819f4e5-1fb5-4a7a-ba50-9e7111759c0d	AIatEDGE	\N	AIatEDGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b55c9116-aa3f-4f04-8780-cc5cb68fa2f8	AIC24	\N	AIC24		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
65d93969-e51a-4ee4-9f5b-319a43a981a9	AICCELERATE	\N	AICCELERATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eab9dbee-d3ef-47fd-bf4e-51e48ff316b8	AICE	\N	AICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b296ecb5-263d-4e3f-94cf-5763b4d26587	AICHAIN	\N	AICHAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0ffccd5b-c573-4b40-a3ed-017aca69b03c	AI-CU	\N	AI-CU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
466e3b28-3029-436b-ab71-46076fbb942c	AI-CUBE	\N	AI-CUBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
189c6337-f9e3-4a72-94e2-e5ce461e1776	aiD	\N	aiD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
411a81d5-f6e9-41a9-aee8-d5de0781537a	AID	\N	AID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6e025591-de62-44d9-8858-1e91f66bdcb5	AIDA	\N	AIDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
531441af-24b2-45be-bb41-6dd81c63f3e1	AÏDA	\N	AÏDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cf48ecff-9d1f-48ae-98a5-2f4961acb450	AIDA-2020	\N	AIDA-2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8d206d77-3346-4626-bc97-833fc4b21000	AIDAinnova	\N	AIDAinnova		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b4b8a43-986d-4581-a4ac-e4ed30c592f5	AID AND BEYOND	\N	AID AND BEYOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6519bd2c-4981-4a58-a23b-27abf26fe06c	AIDD	\N	AIDD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2e75c2cf-86b5-48fa-88be-6275e0d7ee21	AIDE	\N	AIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
75496c18-f909-4aee-87cf-19dc27183352	AIDEAS	\N	AIDEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0ae37043-0887-4eb0-8e0f-865467d34a04	AI-DEMON	\N	AI-DEMON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7fdd6632-a68a-4422-8df3-3a4270b7a828	AIDING THE NEGLECTED	\N	AIDING THE NEGLECTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed6daab7-5464-472c-a640-196f7e474d76	AIDINMENA	\N	AIDINMENA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
02d57c2e-5e4a-42f0-8883-b9b25b85a9c8	AIDOaRt	\N	AIDOaRt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20a782e9-6c17-4963-b3e7-a940bf8c112a	AIDPATH	\N	AIDPATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0e67cc30-97b4-4129-9fcd-d0d95387c9db	AID Recruitment	\N	AID Recruitment		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c5632629-d4ff-401c-9c1c-d5a558bced7b	AIDS AND MIRNAS	\N	AIDS AND MIRNAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b19fff76-06dd-4d0c-a47a-fcf7abce5abf	aidsocpro	\N	aidsocpro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d158e4cd-e279-4a1d-9ab2-23978f760e1e	AIDSRIGHTS	\N	AIDSRIGHTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
09f47b98-d2bb-4c82-8f86-11d9bfe889d3	AIDSsilences	\N	AIDSsilences		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ccad3217-e902-4700-b1c3-cfed7550042e	AIDViC	\N	AIDViC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
59fb41b4-c504-4dcc-b28e-ec50e725a91a	AIE-RTP-PLED	\N	AIE-RTP-PLED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
65555e99-f7c6-4b1b-9768-bb6f0e311bd5	AI-FIE	\N	AI-FIE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ab716cd2-f43d-42f5-8193-396472aa5810	AI for a faster web	\N	AI for a faster web		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
12e2bacc-28da-457b-876e-cf927783c077	AiforCancerDX	\N	AiforCancerDX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
01b314c2-2e68-4d0d-a847-2f032e5ebba2	AIFORS	\N	AIFORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c58e807-8b33-4afb-993c-0b24686e7d5a	AIRCOAT	\N	AIRCOAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0b6d7fca-6f9c-44ac-a4bb-9a60da84a242	AIforUTracking	\N	AIforUTracking		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
40891fe4-c180-4998-9495-5de13804d22d	AI-Inspect	\N	AI-Inspect		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eab5f1b3-c43a-4bb1-ad28-cb515f5367d2	AILAS	\N	AILAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ea816ef7-f0d0-4863-84c7-747ca4b77967	AIM	\N	AIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6d26c11-bfb0-4fee-82ac-5dd1ebafbe95	AIM²	\N	AIM²		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad524ec9-d7be-4603-a5fd-056badf903be	AIM2 INFLAMMASOME	\N	AIM2 INFLAMMASOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
82600085-e4c2-4a7c-a2f4-2dd556bd0c82	AIM4NP	\N	AIM4NP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba315bd9-4c50-47b0-81b6-c21e50759ac2	AIMACS	\N	AIMACS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa523a46-9037-45e2-b547-96566a0559ee	AIM_COACH	\N	AIM_COACH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
89d3499a-2c87-46aa-830d-416154282e14	AIME	\N	AIME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
df83f5de-0665-4c60-be72-8aba77bb88cf	AIMed	\N	AIMed		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a873ebc6-5a4d-4ddc-ac96-acd96b5716ff	AiMeRe	\N	AiMeRe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7391dcb4-6d65-48f0-bdc7-16db90d22a31	AI-METHOD	\N	AI-METHOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
24d3c5db-a97f-42ec-a952-47591eaa751b	AIM-HI	\N	AIM-HI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d67d807a-06f7-41b5-8634-ddb467273592	AIM-HIV	\N	AIM-HIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2f17b9bd-45fc-4ee1-b2ca-27116b074aee	AI-MICADIS	\N	AI-MICADIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1050b3cb-e22f-4735-a45a-275490efae4a	AIM.imaging.CKD	\N	AIM.imaging.CKD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
612e90e6-d783-460b-9496-b7a0d38aeaa8	AI-Mind	\N	AI-Mind		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
646e1909-23c5-48e0-ba9d-92caa133e20e	AimingT6SS	\N	AimingT6SS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ac6cf765-0496-4edf-83f2-49a04be859da	AIMMS STAR-PLUS	\N	AIMMS STAR-PLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0c21cb06-aea1-4eb7-9b8f-1388071ce6ba	AIMS	\N	AIMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
18cea26f-0988-4e0e-b9fb-00674a6acbef	AIMS-2-TRIALS	\N	AIMS-2-TRIALS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
91130ec1-9c91-4efd-9312-b5395884efd8	AINARA	\N	AINARA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
583a6aa5-d9e4-4b6f-9184-cecd48878452	AINIGMA	\N	AINIGMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
78c39267-1061-48e8-901e-cb576d24c524	AIOSAT	\N	AIOSAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d44f2101-a021-448f-b776-f476e2cbd6f8	AIP1918	\N	AIP1918		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b76440b-2685-425d-a766-f8433af0baf7	AIPACA	\N	AIPACA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30e460a6-edaf-40e5-8ee9-7094f7f8afcf	AI-PATH	\N	AI-PATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bca092f9-abe8-4bb1-95e3-a547ad093a24	AiPBAND	\N	AiPBAND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0cbfe5ba-cb29-4233-9729-4906d76e4520	AIPGENE	\N	AIPGENE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8fde85c4-f984-4083-ac9e-6b076112b441	AIPlan4EU	\N	AIPlan4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
570660c7-cb27-4b96-bf29-d701bc3beddc	AIPM	\N	AIPM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
18450fe6-da8e-4999-8ff5-dd57364655ca	AI-PREVENT	\N	AI-PREVENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a3ace66a-90ba-47b9-ac22-32777671c905	AI-PRISM	\N	AI-PRISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1c5261d-071a-4d63-9f79-d450c1d11ff6	AI-PROFICIENT	\N	AI-PROFICIENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
341721fc-54bb-43db-94ad-e4febd9fdfdc	AIR3D	\N	AIR3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e20b2e1-098d-4205-b431-1a07149d4b16	AIRBEAM	\N	AIRBEAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3fe2196-5df2-41aa-82ab-54b185bd9e10	AirBorne	\N	AirBorne		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a998e2d-669a-4762-b6be-052a0d52f39c	AirBrush	\N	AirBrush		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8353839b-9355-4d18-b082-6bb3347f4067	AIRCARRUS	\N	AIRCARRUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a8398289-7005-47c3-9901-600068c92227	AIRCRAFT DECON.	\N	AIRCRAFT DECON.		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6ac228a-7411-4b88-89e3-2c6646753cda	AIRCRAFTFIRE	\N	AIRCRAFTFIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
875e38bd-617f-4f52-82af-571c1f9d6901	AIRCRANE	\N	AIRCRANE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3e808391-392d-4556-9002-243dc9d16381	AIRDNA	\N	AIRDNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
277ae763-e753-4d67-8a52-24bf1850547a	AIRE	\N	AIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
969aac8a-8614-437e-ae22-c25edfff5c46	AI REGIO	\N	AI REGIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9b9a9a9b-a4dd-49a4-9336-67d9947cce65	AIRE-TOP2A	\N	AIRE-TOP2A		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
97c3fb1a-15d0-47d3-8658-237daf0043aa	AirEx	\N	AirEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
584780db-b816-41e5-8e6d-395940a90ab3	AIRFIELD MONITOR	\N	AIRFIELD MONITOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c96f8060-ad5f-4800-b447-5e4015da44d5	AIRFORS	\N	AIRFORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a326742a-a3db-43f6-a086-8d5ff4384796	AIRGAL	\N	AIRGAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8d87169b-dcfa-4b23-a322-2978fc827c10	AIRGENEX-food	\N	AIRGENEX-food		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9de65fce-70e3-4488-a119-ca883f16ed78	AIRIMGO	\N	AIRIMGO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
49da33bb-0e99-467d-9a3c-ba6550ed78de	AirKit	\N	AirKit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a1e2a2b-17b7-4381-9f24-7384a589d97a	AIRLINES	\N	AIRLINES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e4460a77-c134-4d5f-aba3-91603701ddb6	Airline Team NCM	\N	Airline Team NCM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ef69d8b5-200e-4b28-80b5-89c87ed3615a	Airline Team xStream	\N	Airline Team xStream		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ebb1437a-b022-4906-a98d-9f3e1a1e7ee8	AIRLITE	\N	AIRLITE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
514c5ae3-00b9-48fd-ae49-53cfc1e4b9b0	AIRLOG	\N	AIRLOG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ebda1db3-ee0d-4254-8c72-d3655426be72	AIRLOOM	\N	AIRLOOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96b63ef0-6796-4bc5-9d4f-b7ec525378ed	AIRM	\N	AIRM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
262b66f0-afc5-4d1d-aa05-3fffbf104d2b	AIRMED	\N	AIRMED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8759d9f0-0461-4cd3-b9f7-bc897f1fafe9	Airmee	\N	Airmee		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ac4d5c55-7350-44ad-af17-967b7107049b	AIRMES	\N	AIRMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f89a6576-bdbc-431b-8f07-1c1d4a6ab6ca	AIRMINWATSFG	\N	AIRMINWATSFG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5adcc98a-8a4c-4374-8979-0e0ba90d55f3	AIRMONTECH	\N	AIRMONTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bb47ba4-ab31-4aea-9a54-3f5469a7d83c	AiRMOUR	\N	AiRMOUR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ed34683a-b5a9-4fb9-8df4-7bf4c37ba5cb	AIR-NB	\N	AIR-NB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f1c4e67-5461-4035-a576-f2e48cc6ad8f	AIRobots	\N	AIRobots		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7349c31e-54bb-4976-bb09-b625849fb231	AIROPICO	\N	AIROPICO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
604d9f4a-1563-43b1-8583-39e76cdd4450	AIRPASS	\N	AIRPASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2bdb4436-21c3-419a-98ad-10352cf90bcf	AIRPATH	\N	AIRPATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cfec62e8-6c11-4342-8664-d97af8a4a163	AirPlatform	\N	AirPlatform		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8e8717e8-4586-4fcd-bcec-75107b562721	Airport IQ	\N	Airport IQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f8a1c332-ef8f-42a1-a50e-090c0ef05965	AIRPOXY	\N	AIRPOXY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8aae4db8-f1c6-4091-8139-bfc5dd91700a	AirPROM	\N	AirPROM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
77dd7ea8-19c4-4e47-b71e-ee9bd5fac58a	AIRPURE	\N	AIRPURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
68dfbc00-ce11-4ca3-8a12-fdbdb52f0513	AirQast	\N	AirQast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
36d8d6b4-6cd2-4ddf-91e1-a40d5622d6ab	AIRS	\N	AIRS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d3a49bc-2b03-4e68-b21c-0331dd70d8cf	AIRSCAN	\N	AIRSCAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a51dcd6a-dcc4-4d6f-807d-719606c6adfb	AIRSEA	\N	AIRSEA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c6090fa8-7d73-40f4-8a91-f82a7af0fde5	AIR-SEAL	\N	AIR-SEAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1605d934-a480-4ebd-bcff-2947d89a8ff7	AIRSEAL	\N	AIRSEAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5a386200-eb4d-4071-b7f2-df4fd5db2453	AirSens	\N	AirSens		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
298af3a5-fe06-419b-8bd3-61ab65a6ab9f	AIRSHADE	\N	AIRSHADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6b39bf9-daf3-4898-986e-59843cb016a9	AIRSHIP	\N	AIRSHIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f5268bd6-c28c-4b2a-8c63-c38a5da3815e	AIRSKIN	\N	AIRSKIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
727d2ee0-811f-4d0a-94a0-fe6e2cd0bff5	AiRT	\N	AiRT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
91557f74-c658-4606-95b6-7658429238c9	AIRTN	\N	AIRTN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b342aeb-2c82-48f5-83fc-20bd171fc368	AIRTN-NEXTGEN	\N	AIRTN-NEXTGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0afa711b-86ff-4968-86fb-a9a7011694ee	AIRUP	\N	AIRUP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
05db72d3-7c54-4377-a802-dd09f1bb99b5	AirWatt	\N	AirWatt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86e10e3a-9b80-428d-8019-9a4fccf5f558	AIRWAVES	\N	AIRWAVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42cd0283-3f13-427b-9412-dfa394885666	AIRWISE	\N	AIRWISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be112aa5-a5ed-4b01-984a-b37676533dbe	AIRX	\N	AIRX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
15756146-a6a0-4d1a-8450-649dfb39a1d6	AISA	\N	AISA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a36f1366-92eb-46d8-b961-6c0a0426200c	AISAT	\N	AISAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
80c0f3aa-d616-424f-b984-0063c3b6281c	AIS-CaP	\N	AIS-CaP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
09e2c16e-6853-4c2c-834a-8099f14f6d22	AIS-DC	\N	AIS-DC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dd924623-d06c-468c-9162-7c55d5882bbd	AISENS	\N	AISENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7f13b666-02e3-4047-b408-24152d956bc3	AISENSE	\N	AISENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0a3a6f7f-014d-4ba8-8c4a-307ec7c91762	AISHA II	\N	AISHA II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
491c8680-6db7-4ec4-8b7b-b2c3fd9cda40	aiSim	\N	aiSim		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7deaff86-fa8e-4237-833e-3155b3d88aab	AISJ	\N	AISJ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56aeb569-5db8-463c-8b66-752d3da6e2f7	AISLES	\N	AISLES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7bab1a8-8814-4d84-9431-4360558e29e5	AISMA	\N	AISMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
14c8f873-6f63-4a0f-bc8a-1c8e6bf37224	ALEF	\N	ALEF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dd0f4bf6-a1fb-4123-909e-0acfbb954db1	AI-SPRINT	\N	AI-SPRINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5352b98c-c884-4afd-b777-49350e3a9cfc	AISS4SME	\N	AISS4SME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8dd31dab-b44e-4e51-b1ab-a6ee5d225c18	AISTREAM	\N	AISTREAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
069ef1de-4530-412c-b271-c60640be1856	AITEP	\N	AITEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e061ef47-ad0b-4f42-8dad-f7e69a921247	AI-TRAIN	\N	AI-TRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7e32951-894c-4cad-a6af-166806170b29	AI-TWILIGHT	\N	AI-TWILIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4bd7bbd3-6d20-4948-a9fc-d2bc3bde9964	AIVA	\N	AIVA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aa30a46c-f33d-4caf-bff9-2c3e431242ae	aiVision	\N	aiVision		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
21864857-d6f5-4db2-ba5a-1bdf414f74c3	AIx	\N	AIx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bfa9612-9ce2-4a4b-8582-89deb62881b8	AJ86RH5GYM	\N	AJ86RH5GYM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd5c303d-1601-4fae-8246-d95ac090df3b	AJAPP	\N	AJAPP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
416f4c47-af76-4c19-8b0a-9d61852701a0	AKMI	\N	AKMI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42b7d967-eb4b-4d65-b3f7-f4d3101d5c81	Akselos Integra	\N	Akselos Integra		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f10316a3-2965-4c48-b97b-67994f5c2832	AL4BIOCH	\N	AL4BIOCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
56779240-2ef1-48fc-890e-eef5f2403a57	ALABGM08	\N	ALABGM08		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c70d9028-554e-459f-8e46-2cf2f278d50a	ALABO	\N	ALABO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0e8ab21e-1ab0-4730-aede-6eb8cb7c3371	ALACS	\N	ALACS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
da44773b-3c7a-4b59-a8b0-5238de08e711	ALADDIN	\N	ALADDIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96d837c8-e5cf-439f-920f-763d0a61e419	Aladin	\N	Aladin		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ee0760d-4f07-4ee5-b007-d4cf93c406ff	ALADS-DS	\N	ALADS-DS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c15aad7e-078b-465a-9f19-92fb0cc26d48	ALADVS	\N	ALADVS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cde38b64-2214-4395-a6b6-e0e90fdf0e53	Aladyn System Ph1	\N	Aladyn System Ph1		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e870a5f0-3f7e-481d-9e8b-69ceb3f79e52	ALAMEDA	\N	ALAMEDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26097a3b-0bc1-4346-9f0e-2ee4ec0f5712	ALAMSA	\N	ALAMSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d8433da-442d-4c77-9839-1d34cf1eb172	ALARM	\N	ALARM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d5a33aa3-c058-49a4-895f-e1f296ca6149	ALARP	\N	ALARP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5217d94f-d420-42bd-a66e-b566cc474e38	ALARTE	\N	ALARTE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3814c93e-5467-4671-970e-e0ac31532271	ALAS	\N	ALAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d6366aee-c699-427e-a136-a4d6527810cc	ALASCA	\N	ALASCA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
17e08b7d-b8e1-4180-aec4-910aec789d6a	ALATA	\N	ALATA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0a73d855-f32d-4c4c-b764-f133286391ad	ALAV	\N	ALAV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31ac5ef7-c471-412f-be44-dbc72208111f	Albanian diaspora	\N	Albanian diaspora		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
755d5466-b2d5-4574-b901-4cf9a901bb25	AlbaSolar	\N	AlbaSolar		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d235537-dc00-439e-bce1-db1b32b20491	ALBASPECIALISATION	\N	ALBASPECIALISATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
442281f2-a96f-4971-a142-f042b596bb6f	ALEHOOP	\N	ALEHOOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31e887be-2d93-4b63-8955-aa4947a6aec7	ALBATROSS	\N	ALBATROSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
db0fe48c-f46d-4195-923e-fbfd77cc335d	ALBICAN	\N	ALBICAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7c88529f-5a6e-4a25-9050-2b3f1fe8ce4f	ALBIMEH	\N	ALBIMEH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
992d898b-2cd5-4359-9640-fa9c612f8a2c	ALBINO	\N	ALBINO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3bc88af-cf0d-43c3-8917-4a6410f360e1	ALBORA	\N	ALBORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e37e0518-5310-4f6d-9f27-93144744611e	ALBTUSMED II	\N	ALBTUSMED II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
690bda14-05b5-468d-ad44-64790242cc7d	ALBUGON	\N	ALBUGON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dea8cac4-f249-4048-92a0-3cc28277d659	ALC	\N	ALC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a200972-f031-45cf-8c0c-32996c6ff53b	ALCAMS	\N	ALCAMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fdd4bfc8-a6c7-46db-99ec-02e226598e0d	AlCat	\N	AlCat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
50c59afe-9a55-4f57-9064-39348ca62355	ALCH	\N	ALCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b3a8a69a-c4aa-41e1-a3da-fc4e04720c66	AlchemEast	\N	AlchemEast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fffaf1e1-1834-4f4d-9c29-3d01a0a76b90	ALCHEMVIENNA	\N	ALCHEMVIENNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a7d0a7bb-bbcc-4257-b38e-3dae6d8b9190	AlchemyML	\N	AlchemyML		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3334c879-f8f1-4d23-bc24-28db014ebb96	AlCHIMIE	\N	AlCHIMIE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8385e3b8-22c7-4631-a7cf-5f860227ec97	ALCLASS	\N	ALCLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9bfff235-0b72-44af-bdee-1f45d596cc2b	ALCO2-FUNC	\N	ALCO2-FUNC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a806ebc-a184-4ecb-8ba4-a813c9a85d58	ALCO2HOL	\N	ALCO2HOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b53a13f-df66-4364-ae4b-c64ff7d943c2	ALCO-ADO	\N	ALCO-ADO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ddb5ac6-efec-4703-9de6-b53e7975f8e0	ALCO_CAMK	\N	ALCO_CAMK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
967b5daf-c88b-418e-a568-55205ea9fa72	ALCOHOLLIFECOURSE	\N	ALCOHOLLIFECOURSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2d3a494-5318-4017-9e5c-563f6a57a5fc	ALCUE-KBBE	\N	ALCUE-KBBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e3824361-5adc-4177-8908-0a8e3b250e62	ALCUE NET	\N	ALCUE NET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e36b7650-cabd-48fa-9bc0-15f85eee8f2e	ALD4PV	\N	ALD4PV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
69f0fea8-20cb-4866-a038-c7f4b4c873bc	ALDing	\N	ALDing		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
85ffcb1d-6b91-4a88-8e58-44d129d24570	ALDof 2DTMDs	\N	ALDof 2DTMDs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6e645808-a361-462c-940c-de969192595c	ALDREN	\N	ALDREN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
897ba306-34a6-44f6-b823-90d7c476bade	ALDrone	\N	ALDrone		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b4e873b0-312d-433f-a1e4-3662b7b56d30	ALD-SPUTTERING-OXIDE	\N	ALD-SPUTTERING-OXIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
48db369a-3ee5-46d0-b822-318baf486b78	ALEA	\N	ALEA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f83849a9-65c8-495d-8481-91e55970ac73	A-LEAF	\N	A-LEAF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c3eeea29-af48-48ca-9114-7359f3f12a4e	ALEAR	\N	ALEAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a2e6212-2d33-4b3d-81c0-72b09f66a30c	ALEC	\N	ALEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1bb9f21-8ff2-4d7a-ba1c-3fe2de2df5f8	ALECS	\N	ALECS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6f17e1b8-4605-4a95-8dca-6659ae1ca283	ALELION	\N	ALELION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
be18dccd-a7d1-41ac-a22c-1452020d2e49	ALEM	\N	ALEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
369b9480-1875-4527-928f-3e9c439d97d0	ALEPH	\N	ALEPH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c93ea40b-ab92-4506-84ed-3b97874ffedb	ALErT	\N	ALErT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e11ef3e5-0576-4fa2-ab91-8b4316a0bc6b	ALERT	\N	ALERT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7e53ed0-829c-471d-83f6-5d12d8a26890	ALERT AND FOCUSED	\N	ALERT AND FOCUSED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
181b27ad-2092-4f38-afd5-c810716eee0c	AL-ES.NET	\N	AL-ES.NET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f8e9a775-40b4-43aa-b4e8-c4e1019d3383	ALEX	\N	ALEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
44317dc1-4b2a-4bbf-8630-a89746553a26	ALEXANDER	\N	ALEXANDER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d486f55b-46be-4268-aaf7-5a4d5441630f	Alexander Krauss	\N	Alexander Krauss		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
553095fc-af2f-4930-ae47-50b4814ab262	ALEXANDRIA	\N	ALEXANDRIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
864139aa-9be9-46a8-a48a-c93aefa100a2	ALFA-BIRD	\N	ALFA-BIRD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a1352e17-53cb-4e9a-9189-f1ed13585e61	ALFALFAEVOLUTION	\N	ALFALFAEVOLUTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
168cb9a2-4bfd-4f19-b959-a467a7605c53	ALFAMA	\N	ALFAMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
87df3842-aad5-4d7b-b991-2939597af5a9	ALFAwetlands	\N	ALFAwetlands		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
11a418a1-972c-40cf-957e-f602712ff306	ALFF	\N	ALFF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1af54168-dbaf-42f9-9650-70616dcdbb31	AlFHoNSo	\N	AlFHoNSo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22fea71a-ae61-417b-9bbc-e987d0c463dc	ALFOAM	\N	ALFOAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
043f456b-b1cd-43ac-acc4-7d1c72f3282e	AlForAMA	\N	AlForAMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d61d5383-3a08-4c83-895f-ace875ecc23f	ALFRED	\N	ALFRED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2027b6bc-6cb2-42b1-8020-22ec00bb8080	ALGABOOSTER	\N	ALGABOOSTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
092720e6-aa5b-42ee-b6eb-38cc1b8e50d4	ALGADISK	\N	ALGADISK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d4cc9f6-b95f-4487-b777-01473caddd5d	ALGAE4A-B	\N	ALGAE4A-B		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ecb39357-14f7-4017-9e5a-70b2dc535d99	Algae4IBD	\N	Algae4IBD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bfab9bab-1628-4343-aeaa-ec595fe033ec	AlgaeCeuticals	\N	AlgaeCeuticals		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a94e8b87-61d7-4fbf-a8ad-fe07dfd32cde	ALGAECOM	\N	ALGAECOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1f88716a-6574-41f1-b6ef-ae8f5234b249	AlgaeFLOAT	\N	AlgaeFLOAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9c580125-ec87-4a1b-9f9d-bb8bd52c6f3f	ALGAEMAX	\N	ALGAEMAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
036c22d6-141d-498b-9544-c0c4b6f7c84b	ALGAENET	\N	ALGAENET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b4d65ec-47fa-4c06-888c-e8e745be73a9	ALGAEOILSYNTH	\N	ALGAEOILSYNTH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae25307e-dca5-4eca-bc8d-0e47754e558d	ALGAEPRINT	\N	ALGAEPRINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5c3f7d70-c39d-4ef7-a83f-695ddaa77ce9	AlgaHealth	\N	AlgaHealth		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6eeecd21-8dc7-43aa-85ec-a70c235d9db5	ALGALVANISE	\N	ALGALVANISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9d038b26-ada8-4f1b-a50b-121f2da6f6bb	ALGAMATER	\N	ALGAMATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
25ea75d7-85f9-408c-8e37-b1600d286c8e	ALGAME	\N	ALGAME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
57364d99-54da-4170-bd16-95202ff85881	algaPLUS	\N	algaPLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f9e90c5c-808b-4327-93d3-ce4fc0e8cc20	ALGATEC	\N	ALGATEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d3a6cfe7-2216-4b45-91e6-6e7ab637d6e7	A-LIFE	\N	A-LIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
05512b41-661c-4c0a-9f1b-18c7a2b74de8	ALGATEC II	\N	ALGATEC II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2e30bdb2-528a-42a8-966a-42277273bc2e	ALGBACT	\N	ALGBACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa7a9c23-9741-4a98-b4cc-378a6b7c7b6c	AlgCoustics	\N	AlgCoustics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
20f7423c-9356-42e4-a7cc-2c5b9023d297	AlgDates	\N	AlgDates		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
478d20c5-8005-4c86-bc35-985ab9b21d28	ALGeSMo	\N	ALGeSMo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ec7668cb-ca23-4332-af3b-035c4b958ef3	ALGETOX	\N	ALGETOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0bba8f2d-5d19-486a-8f4a-3afa469091c3	ALGFUEL	\N	ALGFUEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
91683a1c-867f-4d1a-92d1-e20b6a3df951	ALGGENOMES	\N	ALGGENOMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58b27e23-efda-46ea-babe-56cbeb8e3b90	ALGILE	\N	ALGILE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6930e35c-bf0f-4bc4-9e29-709667d3f5ff	ALGLASS	\N	ALGLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1232e3f0-7a1a-4529-8b28-f49402703b07	ALGOA	\N	ALGOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7cbacc6-7026-4a3b-b324-9f7ed8e9a794	ALGOCERT	\N	ALGOCERT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
823f4b04-a094-48e7-9355-8d5bdc72d658	ALGOCom	\N	ALGOCom		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3338451d-6889-4c8f-baf6-0f8344210e2a	AlgoFinance	\N	AlgoFinance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
424206bc-a260-4fdb-a7ba-4391d782d4d7	Algo-Grid	\N	Algo-Grid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b7727708-b39d-4800-bd34-0ffd63c040cb	AlgoHex	\N	AlgoHex		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a8cee1e-0156-493e-842f-3f0bd4768c08	AlgoQIP	\N	AlgoQIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f244c3f2-f46a-46fc-8af5-2eb6f5312d2d	ALGORITM	\N	ALGORITM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f1895b1a-a310-40e2-8fd8-a01020c7d0cc	AlgoRNN	\N	AlgoRNN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2366b572-2334-4df3-87de-1d8f2a6581f0	ALGOSOC	\N	ALGOSOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e408308d-0197-4b3e-a563-3d732f6edf78	ALGOVIS	\N	ALGOVIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b246e23c-af51-43bf-bf70-862d2d64657f	AlgSignSen	\N	AlgSignSen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0427a40f-2c97-471f-8294-dae79a76eea4	ALGSTRONGCRYPTO	\N	ALGSTRONGCRYPTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eb1fbf6e-1b54-4d63-9143-a1675bbc3607	AlgTateGro	\N	AlgTateGro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29d91a5e-236c-4910-8d44-f5caf0438eb2	ALGWAS-BIOR	\N	ALGWAS-BIOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
06360e26-2fa0-47d5-ac0a-e8e5ee61df83	ALH	\N	ALH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
587aed7d-5853-4351-95e4-7def82e88a65	ALHIS	\N	ALHIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3208deb-e64d-4ff7-83f2-25ec1647a540	ALHOME	\N	ALHOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae75ab97-01f2-47d3-88f4-81570d3ceab9	ALHSOLAR	\N	ALHSOLAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
26ef4399-6387-4d51-a1ae-50c9ccf58edc	ALHTOUR	\N	ALHTOUR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42fd85c4-558e-43d4-91e5-53906a0a2486	ALIADA	\N	ALIADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5d78ad33-f3cb-4edf-8a35-652c8ea81c49	ALIAS	\N	ALIAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ca683a93-f403-4517-b9ac-31745831c84f	A.L.I.B.I.	\N	A.L.I.B.I.		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e52afb7c-af02-4314-81f1-5655ad5e5f79	ALICANTE	\N	ALICANTE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b040d357-3bc9-487b-b42e-f2e0100b5689	ALICE	\N	ALICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4a47f09a-eef9-4819-97f0-2efab84a802b	ALICE RAP	\N	ALICE RAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
96bd9eaf-a20f-4bd5-8360-44bfd6bedf42	ALICIA	\N	ALICIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2b33183d-5811-4508-b480-c7b0fa3171c8	ALiEN	\N	ALiEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf25a29a-d204-49be-86b2-a8bc4fd6bdca	ALIEN	\N	ALIEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b974fa04-93c2-4f1a-8ae5-073d7f824202	ALIENC	\N	ALIENC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a48f97cc-2ddc-408e-9963-1c8fff0face6	ALIENFISH&CLIMCHANGE	\N	ALIENFISH&CLIMCHANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bfbd48b2-8c56-428d-a436-89127f33cbfa	ALIENIMPACTS	\N	ALIENIMPACTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9263e75e-0525-4e38-9542-a0d2a0be6ac3	ALIENinSoil	\N	ALIENinSoil		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f50282f-f2f5-41eb-a3a1-b05cb361cab2	Alien Species	\N	Alien Species		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
617ae202-9686-444c-9e7c-efaf01388399	ALifeInSOFCs	\N	ALifeInSOFCs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b7050e9f-f580-432a-ad9d-2814a30e78ab	ALIGHT	\N	ALIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5079ac0d-d36d-4d95-ba16-d616e9a70d8c	A light on vision	\N	A light on vision		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d936074-596e-4ae6-ad5b-a38e62cd5587	ALIGN	\N	ALIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c0b4d106-7490-4682-a798-158491294b12	ALIGNED	\N	ALIGNED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4e052539-ff40-4dac-b653-64047b763d42	Aligned e2e	\N	Aligned e2e		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
744ead6f-0ef9-4485-8087-0863bff30454	ALIGNER	\N	ALIGNER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bbc10e21-80d0-491a-afdf-49200225417b	ALIGNING MINDS	\N	ALIGNING MINDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c190e3ab-337a-47cb-a1a7-2103c108bcac	AL-IN-WON	\N	AL-IN-WON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e7c25050-d872-4f52-af87-fb353d1458d9	ALION	\N	ALION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8c9fa84c-c8c0-4aee-b1bf-00eaf5a201d8	ALIPS	\N	ALIPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5e70a047-61d7-4b23-bed7-bf447c5484b4	ALIS	\N	ALIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8afb7fe3-2dc4-4192-89d2-34c153811ab1	ALISA	\N	ALISA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9aeaf595-5d92-4818-9e9d-442ada0b0dc6	ALISE	\N	ALISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6e2e3e28-1454-45d4-ba9f-3acd1763020b	A-LITHIA	\N	A-LITHIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
afd7afd9-b1e7-41e5-93c5-4a3c15287605	ALIVE	\N	ALIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d641e06e-9ece-4c21-9f24-9ec6a0d83250	ALIVEAfrica	\N	ALIVEAfrica		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
494eef37-fb70-417f-bb9e-a7180edd49a9	ALIVER	\N	ALIVER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3dd34bc-e01e-4b84-b0d5-f8b01f27bad4	ALIZ-E	\N	ALIZ-E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
05d75ba2-8ccd-42f7-9714-93dc834fffee	ALK7	\N	ALK7		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b217c980-51f9-4143-a657-9217858e5928	ALKAGE	\N	ALKAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f679726e-ebf0-4b15-93e0-1f38468f7cbf	ALKAMMONIA	\N	ALKAMMONIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
53599cc7-7b5c-45b2-98e2-df7dd49cd573	ALKATRAS	\N	ALKATRAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37f368ca-753d-4ffb-a38e-d68d94d91082	ALLODD	\N	ALLODD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7fb6c9ed-37a3-405f-9c0a-8c96046aa0f2	AlkenesToAminoAcids	\N	AlkenesToAminoAcids		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
aef8fc98-2d59-4130-9062-1c1b920ea4bc	ALKENoNE	\N	ALKENoNE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f6bc46ab-8049-490f-802f-8a9d97b50c82	AlkFood	\N	AlkFood		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a317e058-93ec-4185-a544-9e96a56e2c0a	ALKVAX	\N	ALKVAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e557eb1a-2965-4da7-abfb-17db7adbfa1f	ALL	\N	ALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
79a8b18c-5c07-4fd1-b128-3791ef56fa54	All4Green	\N	All4Green		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f5e799ff-e788-4d49-b477-08483c90ad8d	ALL4REST	\N	ALL4REST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
87daedfe-8479-43a4-a7d0-db3c008f4ee3	ALL4RESTgo2MARKET	\N	ALL4RESTgo2MARKET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
14f14fea-4fa3-4613-a636-6712021efc49	All-Atlantic2021	\N	All-Atlantic2021		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29093358-3cab-44ab-8aa7-cd0aec25dd5b	ALLBIO	\N	ALLBIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
432bdf59-9582-4b02-a145-38379aa80cb8	AlleeMod	\N	AlleeMod		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
690fe404-7aff-40f1-ae0a-a3879a48281b	ALLEGRA	\N	ALLEGRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
af8fae9d-4a9f-494c-91db-8dad9d1f9b1e	ALLEGRO	\N	ALLEGRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1c3e6973-458c-46e0-b463-0e3b46f073c6	ALLELECHOKER	\N	ALLELECHOKER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d0cb93c5-a22c-4b8f-b8ef-4b06c96517da	Allelic Regulation	\N	Allelic Regulation		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
032100b9-7dd1-4734-9d1a-93a18231c100	AllergenDetect	\N	AllergenDetect		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d8d3eb6-4422-403b-9df4-d809a3a96027	ALLERGENE	\N	ALLERGENE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a2466f0-9550-4c9b-932d-9d4f4480d665	ALLERGUT	\N	ALLERGUT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
abaec00c-5a28-47be-952e-a73cabcf26f2	AllergyBLOCK	\N	AllergyBLOCK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc195796-dec0-4ac3-9b5b-f2f4c3c996bd	AllergyExplorer	\N	AllergyExplorer		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ad3cb9a7-46de-4aa4-aeba-cface61fdfb9	AllergyVAX	\N	AllergyVAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
472d4dcf-e369-4e61-ba74-9eb2d573590f	AllerScreening	\N	AllerScreening		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ae705192-6db8-46a6-856a-23dacd2674ad	ALLFUN	\N	ALLFUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c78c640e-82c7-4b01-ae3e-f2989cb92e2e	ALL-GAS	\N	ALL-GAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ba41d29c-56ef-4e4b-83df-222558d1b050	ALLIANCE	\N	ALLIANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e80ad762-bcc7-4043-9c6d-2a9e6faafeb2	Alliance4Life	\N	Alliance4Life		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cdbd7c07-15c0-4caa-a0dd-d15db854cad0	ALLINTERACT	\N	ALLINTERACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1b29e83f-4924-4ad5-9eb9-72994faa7cdc	ALL-IN Zero	\N	ALL-IN Zero		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ffdfe160-07e6-4afa-b91a-a660fe5262da	ALLNIGHTS	\N	ALLNIGHTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
00f84599-b0fa-4978-9ad5-accd1548f74c	ALLOCHRONY	\N	ALLOCHRONY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8d570c24-fd4a-48b0-82dc-99e03a582b2b	Alloem	\N	Alloem		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f498f40a-5f47-4d2f-a665-8bb4683d57bf	AlloGPCR	\N	AlloGPCR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e63f0cc4-88e5-4e12-bd97-f6315622420e	ALLOPLASM	\N	ALLOPLASM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3097e972-0716-40f0-b9cc-b5e9fccd3a3b	AllOptHIPP	\N	AllOptHIPP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ca9165b1-42e0-42a3-a8ac-62c556ec3623	ALLOPTICS	\N	ALLOPTICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ccf28cf-496d-4689-8cda-dd928214239f	ALLOSERGON	\N	ALLOSERGON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f4b64311-69a2-4296-9c61-e3c1960dce57	Allosteric-CRISPR	\N	Allosteric-CRISPR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0874aea0-6a9e-413c-bbdb-bd03daa81061	Allo-THYTECH	\N	Allo-THYTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
216c72c5-e913-46f5-af55-3f787be00933	Allow	\N	Allow		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe89945e-4c71-49e7-b02b-4747d07be96a	ALLOWE	\N	ALLOWE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9ad44d25-aabd-4556-bc18-bb8d4a30b5b4	ALLOW Ensembles	\N	ALLOW Ensembles		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7490d99c-4430-4161-bcb6-976f7375e191	ALLOXIDEPV	\N	ALLOXIDEPV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c05a57ac-ba73-4d2a-8050-bbfce5fbfcdc	AllOxITD	\N	AllOxITD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1fd8876c-14c7-4af5-b881-4f68e81c9458	ALLQUANTUM	\N	ALLQUANTUM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e4e6da3f-491d-4786-ad3a-bace11c75592	ALL-Ready	\N	ALL-Ready		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb25076f-f006-47e9-a7ef-1e91a95f07ac	ALLRUN	\N	ALLRUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8edbd24-5aa0-4bdf-aa40-25d004717c06	ALLScale	\N	ALLScale		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
29dd9a24-2895-41cd-87d8-198c6a46aad0	ALL-SMART-PIGS	\N	ALL-SMART-PIGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fd06ed3e-591d-411e-9952-cf1701aa1d35	AllSteel-SRetrofit	\N	AllSteel-SRetrofit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
19cdd4d1-4088-4dab-88d7-ddcfa06b7d22	Allthings.bioPRO	\N	Allthings.bioPRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cadafa94-cf91-4f2f-95c1-ccec698abee5	ALL-TIMES	\N	ALL-TIMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
90f971b4-a296-43e4-aeea-2174a0025ab8	AllYours	\N	AllYours		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
184c989e-9263-4829-8c47-de69ae6cad3a	ALM	\N	ALM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a19a6307-281d-46a3-808d-2ff1913aa667	ALMA	\N	ALMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
90fdd697-7cd3-4307-964a-2945c8e8d081	AlmaCrypt	\N	AlmaCrypt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2ced20bb-03dd-4f46-b6ee-f7aea868bfcf	ALMAGIC	\N	ALMAGIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c73ad3a1-7980-4470-877c-6af613f0778d	ALMA-MATER	\N	ALMA-MATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
64a3e507-25dc-410a-b40f-365a179f140f	ALMANAC	\N	ALMANAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b25fe956-1425-4984-9acb-f77978a1f5cd	ALMARVI	\N	ALMARVI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d083aa22-e00d-4c15-9139-516d4f9ea263	Almazara 4.0	\N	Almazara 4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
03b1ab72-5056-45f6-9569-ad68ff40d259	Al-medicare	\N	Al-medicare		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
934ac87c-b016-491d-85c0-d2d85036e930	ALMOND	\N	ALMOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5a7fcb09-f7d0-42a2-b589-662aae1cc6ca	ALMP	\N	ALMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8bcec70-4f61-4e6c-b9bd-60443eb8f4c2	ALMP_ECON	\N	ALMP_ECON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
db6cf878-3e09-4ecf-89c9-b968caa35ae0	AL-NANOFUNC	\N	AL-NANOFUNC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a8db017-d298-4b55-8863-586a78891fad	ALOA	\N	ALOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ae1a8b4-4db7-4bde-86cf-c9f8ca755912	ALOEco	\N	ALOEco		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cfa6b3fd-6b0a-40bd-8455-1c951ea19311	ALOE-DIVERSITY	\N	ALOE-DIVERSITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
196d1dbd-26d2-4c4a-b9a5-abd39323a498	ALOGLADIS	\N	ALOGLADIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c6c108f2-265d-46f7-905d-572ec3387d21	ALOHA	\N	ALOHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0be0d922-23d1-4f87-9fab-2a89669d4c33	ALOHA TORINO-SYDNEY	\N	ALOHA TORINO-SYDNEY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
007db9d9-8d2b-4287-bcdd-8b509720aa6c	ALONE	\N	ALONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
68d88c28-2979-4dac-8f51-206d0cda548b	ALONOCO	\N	ALONOCO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
40583f1b-fa18-4574-995e-35e5603eb176	ALORS	\N	ALORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c7f4efd3-225b-4f7f-a2c7-48a532041369	ALPaCA	\N	ALPaCA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e9b9433-9372-4614-984b-7543cf8bd95c	AMU	\N	AMU		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d240f352-8985-4129-8ef7-a12f2172fa47	Barcelonabeta Brain Research Center	\N	Barcelonabeta Brain Research Center		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4f702c56-884a-4e62-96e7-9338168243c2	Barcelona Digital Centre Tecnològic	\N	Barcelona Digital Centre Tecnològic		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
74f59d64-38b2-4065-b493-991b9a943e11	Barcelona Graduate School of Economics	\N	Barcelona Graduate School of Economics		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0ee9f4e9-4e0c-4dbb-95c7-307a3784793a	Barcelona Institute of Science and Technology	\N	Barcelona Institute of Science and Technology		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0371bddf-9b21-412f-abf7-356faaf92d3c	Barcelona Media	\N	Barcelona Media		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
facc3f93-98e7-4985-b0da-2f2367c3390c	Fundació guifi.net	\N	Fundació guifi.net		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
90e3dadc-dc19-4308-84e4-d7d90fdec45f	Barcelona Supercomputing Center - CNS	\N	Barcelona Supercomputing Center - CNS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5ab6a228-9cf8-4297-9247-26078df94f19	Càmara Arrossera del Montsià	\N	Càmara Arrossera del Montsià		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
681af06f-3396-4f95-b73e-af7d4047f961	Cambra de Comerç de Barcelona	\N	Cambra de Comerç de Barcelona		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
60aefa80-0fc7-4943-ae1d-7ebacc8b1151	CELLS - ALBA	\N	CELLS - ALBA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7d70ec57-0c7d-45cb-930c-c7462907f443	Centre CIM	\N	Centre CIM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
eeb2e223-e247-4d78-a7e7-94e48dd4fece	Centre de Recerca en Agrigenòmica	\N	Centre de Recerca en Agrigenòmica		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
17ef2bc4-703c-4d7c-8d8b-e1fc361b1441	Hospital de la Santa Creu i Sant Pau	\N	Hospital de la Santa Creu i Sant Pau		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
93ad56dd-7c58-4615-b715-8b363eacd10a	Centre de Recerca en Economia i Desenvolupament Agroalimentari	\N	Centre de Recerca en Economia i Desenvolupament Agroalimentari		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4b3d634b-8c0d-4c0f-bf52-91caf2a41216	Centre d'Estudis Demogràfics	\N	Centre d'Estudis Demogràfics		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f6301b75-d13e-4eb0-96f2-bab577f850eb	Centre d'Innovació del Transport	\N	Centre d'Innovació del Transport		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d748e0b0-6df3-4889-be45-5dafeafbdc45	Centre d'Innovació i Tecnologia de la UPC	\N	Centre d'Innovació i Tecnologia de la UPC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
34560223-355c-4bcd-a854-dbb4b36c5dbc	CNRS	\N	CNRS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8734a21b-c434-449c-a57e-1b20cf0d2593	CTM Centre Tecnològic	\N	CTM Centre Tecnològic		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5b5496b3-dedb-43b5-9899-630f809c7149	EC Lyon	\N	EC Lyon		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cf05fe5f-347c-4931-8994-14ef4ade2b14	ECP	\N	ECP		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b633291e-ae72-471c-983f-5da1138facc6	EFEO	\N	EFEO		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fe4136f8-4384-4a41-a919-cb06df499f51	EHESS	\N	EHESS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c6780acc-7a68-4aa0-a1c9-282a5e874838	ENC	\N	ENC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5edf2368-9c18-4a02-9fb6-03bcbf7c980b	ENPC	\N	ENPC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
671d425b-ed3b-4326-abfb-57a847d8a926	Ensad	\N	Ensad		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9e3a6c1a-aeaf-4a6c-be7d-e278b757ec36	ENS Chimie de Paris	\N	ENS Chimie de Paris		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b20599a4-167a-4adc-ba39-a41dc371aa52	ENS de Cachan	\N	ENS de Cachan		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f4962aeb-5cb0-44b7-9f75-87f6db653854	ENS Paris	\N	ENS Paris		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4799ac59-ec92-44b9-a1e2-eb9956975651	EPHE	\N	EPHE		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9e7f248e-c69f-4271-bb00-7d5d1c0b65f1	ESPCI	\N	ESPCI		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8eb643d9-d445-4d47-901f-21950d9c1269	Fundació Barcelona Mobile World Capital 	\N	Fundació Barcelona Mobile World Capital 		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
83b078fb-66c9-4fa9-a427-b932fe1fbb37	Interarts	\N	Interarts		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e25ccf34-7793-4d35-a9f0-be1ed465245f	Fundació Clínic per a la Recerca Biomèdica	\N	Fundació Clínic per a la Recerca Biomèdica		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e23667e9-c622-467a-b401-1264376f5c40	CP-TP	\N	CP-TP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8b32354d-8771-4a5c-9f6b-1c954b222811	Fundació I2CAT	\N	Fundació I2CAT		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fc5bc8f4-8dcf-44d7-bf12-5f1768dcf6a4	Fundació La Caixa	\N	Fundació La Caixa		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42c9f0b0-5a8e-4df2-bb9a-6d9634f1f5b0	Fundació Pau Costa	\N	Fundació Pau Costa		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
34e7f27f-f6ad-4881-97b9-a7cea825ad30	Fundació Salut i Envelliment	\N	Fundació Salut i Envelliment		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
01fc2af1-8f44-4bd3-8273-17014170c8c8	Hospital Clínic	\N	Hospital Clínic		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ff8b12d-c12b-41da-980e-c728b7a77714	IDIAP Jordi Gol	\N	IDIAP Jordi Gol		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0393028d-6598-4b66-a3da-29beec1b41e4	IEP de Paris	\N	IEP de Paris		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e280003b-2c52-4599-ad76-558b12dc70c2	INPT	\N	INPT		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f3ffd8c9-02cf-4e8b-b925-16372a6fb8c8	INSA Lyon	\N	INSA Lyon		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7aaf34f8-19d9-4d55-8a5b-89a858a07647	Institut Barcelona d'Estudis Internacionals	\N	Institut Barcelona d'Estudis Internacionals		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1406f38d-5ee7-46b6-bcd9-f206cc51d965	Institut Català de Paleoecologia Humana i Evolució Social	\N	Institut Català de Paleoecologia Humana i Evolució Social		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
07aa0e9e-f1dd-4638-8439-74a95de21e10	Institut Català de Recerca de l'Aigua	\N	Institut Català de Recerca de l'Aigua		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
273076ed-2d76-4057-9b21-1b975d4e6ae7	Institut Català d'Investigació Química	\N	Institut Català d'Investigació Química		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ff8e1552-7b5c-494b-93c0-4dfd287c1eda	Institut de Recerca Biomèdica de Lleida	\N	Institut de Recerca Biomèdica de Lleida		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c90cac6c-123e-4f4b-94cc-30df40442100	Institut de Recerca de l'Energia de Catalunya	\N	Institut de Recerca de l'Energia de Catalunya		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
700ec4f1-348f-4126-874c-77dd473d5bab	UTBM	\N	UTBM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e40c8f6f-8ed5-4a18-89b2-392fef11d8ff	Institut de Recerca de l'Hospital de la Santa Creu i Sant Pau	\N	Institut de Recerca de l'Hospital de la Santa Creu i Sant Pau		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a85b481-63f9-4b6e-ad4c-45088af4abd3	Institut de Salut Global de Barcelona	\N	Institut de Salut Global de Barcelona		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e208faf8-38d4-44ce-91e5-9b064df16f91	Institut d'Estudis Espacials de Catalunya	\N	Institut d'Estudis Espacials de Catalunya		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b0834b58-1a5a-43d5-bdbf-23d3f5fef1c3	Institut d'Investigació Oncològica Vall d'Hebron	\N	Institut d'Investigació Oncològica Vall d'Hebron		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ea45055e-abbd-4bc9-a66b-77aa30b660c7	Institut Guttmann	\N	Institut Guttmann		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6db4f9a7-e7c9-46b7-a0b1-6c1ee2338eec	KimGlobal	\N	KimGlobal		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4309cadc-2a11-4eb9-8286-dcbee33d22fd	Leitat - Technological Center	\N	Leitat - Technological Center		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2949bf46-45cd-4611-9528-1b63fccae8c8	Mines ParisTech	\N	Mines ParisTech		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
14fb2509-e513-466d-95d7-51d7d74fae0f	Parc Agrari del Baix Llobregat	\N	Parc Agrari del Baix Llobregat		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3ddfdb18-93b1-49b3-b842-82685f3b5271	Parc de Recerca UAB	\N	Parc de Recerca UAB		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e9cefaf-e076-414b-8659-08aebba12ef7	Parc de Salut Mar	\N	Parc de Salut Mar		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
30cc545e-b2e1-4869-b48f-681953be5b25	Paris-Dauphine	\N	Paris-Dauphine		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
842b9158-c797-4e6c-89b6-42004a4f7e89	PRES ParisTech	\N	PRES ParisTech		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
363fb615-74fb-4753-9810-74d102d2015c	PSL	\N	PSL		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf903b5b-fb48-4e43-809f-23872b63a458	UBM	\N	UBM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4fdbb45c-9384-4821-8722-418e50a54156	UBO	\N	UBO		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ef5ec364-d963-4936-b5e4-195925370851	UBP	\N	UBP		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
37f9c7f0-5dc0-4c2c-8280-ee006bad69dd	UBS	\N	UBS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
55b15a34-6b71-4335-86da-e79796e1ecd5	UCA	\N	UCA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9878482d-56be-43ff-8113-d34460364e90	UdA	\N	UdA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1c6394b-e0e8-4a17-b889-4ff9ac94eb66	UDL	\N	UDL		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1adecf1-435e-4a6f-8d7f-b4ba1119f6b5	UFC	\N	UFC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5da1a5c8-9329-46bb-935e-2935cce00f50	UGA	\N	UGA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b9f1867e-9496-40f4-b228-fbc4b70e57c6	UHA	\N	UHA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2413884f-0de9-4f36-9000-d43b2d932c6e	ULCO	\N	ULCO		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f7a1c46a-8b85-4bce-93af-a6661e7d2172	UNÎMES	\N	UNÎMES		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a3089c2c-3c32-4388-8f56-833d566b4881	Universitat Politècnica de Catalunya	\N	Universitat Politècnica de Catalunya		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e343f899-1da0-4f32-ab78-e2b397637440	UPE	\N	UPE		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d2cd58a0-b7fa-4454-a4eb-926ea521a0c1	UPEC	\N	UPEC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
efcdb727-55f7-413b-8c45-31769b45f75d	UPEM	\N	UPEM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1aed44b9-6bf4-4944-abc3-e1a22ab92a62	UPJV	\N	UPJV		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
771c5f8a-7079-44e4-b7d7-3b4f29e2f3c6	UPMC	\N	UPMC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bbc9c416-3667-47e6-bc41-0b12b74ce6b8	UPPA	\N	UPPA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4bc52ffc-66ec-4a80-ace2-c3b31342edb0	UPV	\N	UPV		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
175b52db-4d36-4cf2-99ff-768876966da5	URCA	\N	URCA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
06bfbd65-1098-4056-9491-a0d7fb22016a	USTV	\N	USTV		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b625cc2-82bc-4cac-b82c-c8755bf070cd	UTC	\N	UTC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b80349fd-b53d-4ee4-ab02-d0bf8ea2828e	UTT	\N	UTT		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
66789096-f794-4725-845c-5813fa0acde3	X	\N	X		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
611a48a3-8523-4c10-b7ef-4cc1274ba2a0	Beneficiary	\N	Beneficiary		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
867b6926-7cbf-43ad-b68c-88234cb9dbf0	Coordinator	\N	Coordinator		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
614eeee5-0bd8-4b2d-8c36-0e3b168ee7e9	CP-SICA-INFSO	\N	CP-SICA-INFSO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e8a0b1cb-d1e8-494a-b759-1c923b848710	Host institution	\N	Host institution		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1068431c-79d4-4506-8302-ea5da3f4b4ad	Participant	\N	Participant		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8d294ad6-6f91-447c-9015-b68a67f6e03b	International partner	\N	International partner		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3395eb5f-2c66-4234-b28b-36c18607d285	Third party	\N	Third party		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b8036e22-01b4-4e88-8ace-83306c34d1dc	Partner	\N	Partner		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b1cfaaea-c609-4892-b17f-019c39dfa17e	169	\N	169		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0b1ecf99-a920-4e5b-bd5e-62bfe32c3f8f	ACM	\N	ACM		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
dc35fc75-3dee-42eb-acfa-fc85e8e23640	ACT	\N	ACT		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce5fea8c-25fc-4521-aecf-f194ee919fa5	AM-SSA	\N	AM-SSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1a599218-d4b4-4eb2-b2c8-44585acf13b0	ART169	\N	ART169		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1958b758-290c-418e-b762-27443f21200c	BBI-CSA	\N	BBI-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2f8032ff-b6ff-472d-a866-9de5cf957161	BBI-IA-DEMO	\N	BBI-IA-DEMO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8bc6f8b0-9e77-480b-a7a1-e1f4986c674e	BBI-IA-FLAG	\N	BBI-IA-FLAG		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e255ce9a-67ed-4e37-b209-97e37bd736bc	BBI-RIA	\N	BBI-RIA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9fa5c0d8-61fd-467c-b830-7751ceaaf36d	BPN	\N	BPN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
907808ea-3720-4f73-be6d-a1c397100237	BSG-CSO	\N	BSG-CSO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f84fb241-bdbe-4ce4-a03b-ed5742497e17	BSG-SME	\N	BSG-SME		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
58f03b61-6be5-49b0-90cc-9d1bf90ea781	BSG-SME-AG	\N	BSG-SME-AG		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2aaab844-e50f-44f3-a315-5da6ad158307	BUR	\N	BUR		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f5d7a27d-318c-408f-8a71-75608a786a3a	CA	\N	CA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c66f686b-5c13-44d8-a175-4562bc6661b2	CAREER	\N	CAREER		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f6ee44ce-2c23-435f-b6ae-2f03613c740d	CIP-EIP-EI-PMRP	\N	CIP-EIP-EI-PMRP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
751b2bc7-29c2-44fb-8b6f-0b423a694d18	CIP-EIP-EI-TN	\N	CIP-EIP-EI-TN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5967c9dd-3ec7-40cb-93e3-7eedfe877f36	CIP-EIP-EI-TNS	\N	CIP-EIP-EI-TNS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
294258f9-cd95-4277-be56-ab07bd1ca3af	CIP-EIP-SPA	\N	CIP-EIP-SPA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
5749cc31-923b-4c69-b6eb-1c8b9aea4a59	CIP-EIP-TN-EI	\N	CIP-EIP-TN-EI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
22f82471-79df-4e87-b304-547cbedd202f	CIP-EIP-TN-PIE	\N	CIP-EIP-TN-PIE		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
31d2f45b-2c67-4723-bf31-a2342b659dce	CIP-ICT-PSP-BPN	\N	CIP-ICT-PSP-BPN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
035ea178-3281-461b-a973-bc98269c6a49	CIP-ICT-PSP-PA	\N	CIP-ICT-PSP-PA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
cb0cc483-5604-4b0f-b47e-b509ed60a974	CIP-ICT-PSP-PB	\N	CIP-ICT-PSP-PB		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6d2ec614-b153-4307-80f8-dadbe2a09d35	CIP-ICT-PSP-TN	\N	CIP-ICT-PSP-TN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
367ab7ff-d82f-4987-9a5f-d110598796cf	CIP-ICT-PSP-TN(EC)	\N	CIP-ICT-PSP-TN(EC)		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b054057f-1b73-4506-9347-7fb7335f295b	CIP-IEE-MRP	\N	CIP-IEE-MRP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2cb7bb62-ee53-4f5f-9e67-d15ca911944e	CIP-IEE-Promo-A	\N	CIP-IEE-Promo-A		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8a421986-4cf0-4aad-aa1d-22204081e59c	CIP-IEE-PROMO-BWI	\N	CIP-IEE-PROMO-BWI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e1421281-8a83-4be1-8cbf-8b9523145f7c	Albania	\N	Albania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
848bbfd5-b604-4179-829d-ca64993c7147	CIP-IEE-Promo-P	\N	CIP-IEE-Promo-P		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
64a6c25a-5c65-48c9-9903-0965aaa8c04b	CLR	\N	CLR		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88daeb45-8b38-4f07-afcf-e653a412b783	CNC	\N	CNC		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
00fff3ce-1af3-494e-a952-d9837bae97de	CND	\N	CND		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c8530a16-314c-4263-b732-d16bd83f6b54	CNI	\N	CNI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
36564e79-ee24-4703-a39a-aa2bb0b496b3	CNI-SSA	\N	CNI-SSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ac2f6ea8-e45d-42cf-8349-ba462b9d1a48	COFUND-EJP	\N	COFUND-EJP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
6f44b8bd-ebd3-4ccc-b1ae-932655bd9e2b	COFUND-PCP	\N	COFUND-PCP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7e1645de-38e3-4441-8e21-78ffd8dd7fab	COFUND-PPI	\N	COFUND-PPI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
44848319-4fd5-438a-95a1-058754324348	Collective	\N	Collective		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
647b03f8-e929-49e9-adad-d28b5ed26ea4	CON	\N	CON		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9b0c0346-2377-4b8e-8e6a-82be9a33e053	Cooperative	\N	Cooperative		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
611c94dc-f929-4290-bdbd-60b09acb23c0	CP	\N	CP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
86dfc5fc-64b4-401a-8a5f-728f488e3122	CP-CS	\N	CP-CS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
149293aa-b668-465c-aefa-83746651efde	CP-CSA	\N	CP-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
750a7aae-15bb-4054-9ab5-edc91d2c0b8f	CPCSA	\N	CPCSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f7a509f-c8b9-4e93-b907-c2a73636745e	CP-CSA-Infra	\N	CP-CSA-Infra		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
697ef470-fc9c-4a06-a06f-314a15582ff1	CP-CSA-INFRA	\N	CP-CSA-INFRA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
590d6856-38e9-4861-8297-ac2167c297f3	CP-CSA-Infra-IP	\N	CP-CSA-Infra-IP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b70af402-0bf1-48f8-bdd7-da0c21c5bd95	CP-CSA-Infra-PP	\N	CP-CSA-Infra-PP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0a14eeb4-9aef-4b48-8629-88a62af6c27a	CP-CSA-PCP	\N	CP-CSA-PCP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
41423d5f-67ff-4200-bba7-98a7f126be9c	CP-FP	\N	CP-FP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b10289e5-c0dc-4ae9-a02e-b99929f75a11	CP-FP-INFSO	\N	CP-FP-INFSO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e3b9f728-62d6-4085-ab4d-c22a2092077f	CP-FP-INFSO-FET	\N	CP-FP-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
e2e0fe5d-9f92-484f-beaf-1dc347c9ea44	CP-FP-SICA	\N	CP-FP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb7878b8-cffc-4add-b024-abafa0847039	CP-FP-TP	\N	CP-FP-TP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c95e048f-0d1c-4148-a293-5a59b1a0a7a2	CP-FP-TP-SICA	\N	CP-FP-TP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce39cc22-7b07-4614-b27c-1734b825fafc	CP-IP	\N	CP-IP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fb6b58a7-d8c3-4918-b3eb-78317dbabb16	CP-IP-INFSO-FET	\N	CP-IP-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
c64b4c98-6e2f-42a2-8034-bd5783b7f805	CP-IP-SICA	\N	CP-IP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1ec574b8-b7c7-4f5a-a274-18f297bef8a8	CP-IP-TP	\N	CP-IP-TP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
500facba-769a-4d9e-afd3-cd3d4b4f051e	CP-SI	\N	CP-SI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88041b22-901e-433d-91bd-2524f1939659	CP-SICA	\N	CP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0e924ef9-1588-4428-80a3-97cc2d837816	CP-SoU	\N	CP-SoU		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
42db8a64-123a-4fba-9469-c8bc78b6a0da	CRAFT	\N	CRAFT		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9bff05a1-76d0-4798-9ab7-81c52e06eec2	CRS	\N	CRS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
47527392-7ec6-4960-b151-de4e1e50e596	CS2-CSA	\N	CS2-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
8aeca8d5-98a0-4b1a-9c2a-af5c31f51ee8	CS2-IA	\N	CS2-IA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0f7f1ed0-c02d-4fdf-b373-a8ce636b2541	CS2-RIA	\N	CS2-RIA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d1ef44ba-e481-43c4-97e2-84c44219cc6d	CSA	\N	CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
70872f50-35e0-4416-b6aa-cf05e4d87a38	CSA-C	\N	CSA-C		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
f6030473-d46d-40c9-a582-4cfac2c2ec21	CSA-CA	\N	CSA-CA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
69bb6aca-6253-4e14-bde2-92d3a4fd53a8	CSA-CA-INFSO-FET	\N	CSA-CA-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
fa4f3443-2f37-49e8-bbb3-139e5e87108a	CSA-E	\N	CSA-E		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2db5ce78-31a3-4d5a-8dcd-f9668b370166	CSA-ERANET	\N	CSA-ERANET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
0bdf1921-7cda-44de-9860-755c0b932c69	CSA-ERA-Plus	\N	CSA-ERA-Plus		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a982a578-b9df-4453-96fd-5377dc46abbd	CSA-ERA-PLUS	\N	CSA-ERA-PLUS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
b573db86-9803-412b-9545-c606b8f4b50c	CSA-LS	\N	CSA-LS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
983f91f3-71b0-4092-8f6c-f060b051935b	CSA-LSP	\N	CSA-LSP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
9f309dfd-ed2f-4d24-95a2-510f9d650596	CSA-S	\N	CSA-S		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d8815fd-da51-4b78-8523-739d0752d6be	CSA-SA	\N	CSA-SA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
88dd9fff-4bf1-43ae-9f71-611c72281093	CSA-SA-INFSO-FET	\N	CSA-SA-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1304dc9e-24e8-4a3e-a4de-4c0481af0ac0	CSA-SA(POC)	\N	CSA-SA(POC)		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
899ac997-dda1-4534-ad65-f26105ab6425	CSC	\N	CSC		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
4d4ce6d9-1e1d-4ab2-bd33-1c45191817f0	DEF	\N	DEF		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
d3056f7e-7a05-4335-b265-8c4cabb3d667	DEM	\N	DEM		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
af648d33-5120-4a75-8506-c7593a50c2f4	DEP	\N	DEP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2197e15b-0350-4337-9ed5-4d50b6b10731	DS	\N	DS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3b3bef52-a9b9-4da2-909b-5e55a8368d59	DS-SSA	\N	DS-SSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3691a5fc-312f-4dbe-a02b-36f564cdb5dc	EAD	\N	EAD		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
1d5f22c9-8184-4561-b42c-fe2f8a2f76df	EAT	\N	EAT		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
ce28fa76-d7d1-425d-89e7-ef34ceab0c3a	EAW	\N	EAW		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a6f77bed-1942-4e01-9a9b-f7c11d9cc66a	ECSEL-CSA	\N	ECSEL-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
a6722d77-d3a6-4b03-bfe0-e52f1a6dc0c0	ECSEL-IA	\N	ECSEL-IA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
01c33a75-167c-4a06-9e7e-949712290bf7	ECSEL-RIA	\N	ECSEL-RIA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
3f84f3b9-27dd-4d5a-a399-53e3d46be05c	EIF	\N	EIF		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
7c8df5e2-01ce-4ac4-8825-1ecd6fe8f8fb	ERA-NET-Cofund	\N	ERA-NET-Cofund		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
2d51a3b8-d5c3-4396-9084-16552879d195	ERC-ADG	\N	ERC-ADG		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-09-28 12:40:38.53709+00	2026-09-28 12:40:38.53709+00
bf7366df-8924-44a5-8c95-33f780ab954f	participant	\N	participant	项目成员角色：参与方（project_members.member_role 实际枚举）	member_role	project_members	cordis_temporary	text	Active	2026-09-29 12:21:03.7453+00	2026-09-29 12:21:03.7453+00
949cd51d-3a8d-4a01-b15a-564b9ea470d0	Benin	\N	Benin		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5aa5c3b5-6d05-41d7-83cc-acb11d61af07	SH3	\N	SH3		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f30868d0-46e8-4faa-b99d-b298ae1a18f4	coordinator	\N	coordinator	项目成员角色：协调方（project_members.member_role 实际枚举）	member_role	project_members	cordis_temporary	text	Active	2026-09-29 12:21:03.7453+00	2026-09-29 12:21:03.7453+00
5ca39d98-e51a-4d7c-a090-69d32722d55a	thirdParty	\N	thirdParty	项目成员角色：第三方（project_members.member_role 实际枚举）	member_role	project_members	cordis_temporary	text	Active	2026-09-29 12:21:03.7453+00	2026-09-29 12:21:03.7453+00
984b401e-1b3a-45d7-b1e0-4340396072ff	partner	\N	partner	项目成员角色：伙伴（project_members.member_role 实际枚举）	member_role	project_members	cordis_temporary	text	Active	2026-09-29 12:21:03.7453+00	2026-09-29 12:21:03.7453+00
e5f8e884-0c56-4aff-b760-e63d3d495f0f	internationalPartner	\N	internationalPartner	项目成员角色：国际伙伴（project_members.member_role 实际枚举）	member_role	project_members	cordis_temporary	text	Active	2026-09-29 12:21:03.7453+00	2026-09-29 12:21:03.7453+00
660a984f-1990-4819-a2d9-deb4c861d7ab	FETOPEN-1-2014	\N	FETOPEN-1-2014	资助主题代码（project_topics.topic 实测值）	topic	project_topics	cordis_temporary	text	Active	2026-10-29 04:37:54.899184+00	2026-10-29 04:37:54.899184+00
2c5362bd-d467-4f7d-97e7-a3f460b5ddff	SH4	\N	SH4		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8ae3d4f5-a780-4f7c-a100-6de3ead44803	Burkina Faso	\N	Burkina Faso		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
067bad2b-70a1-48d9-831e-8aee184613f8	FETOPEN-RIA-2014-2015	\N	FETOPEN-RIA-2014-2015	资助主题代码（project_topics.topic 实测值）	topic	project_topics	cordis_temporary	text	Active	2026-10-29 04:37:54.899184+00	2026-10-29 04:37:54.899184+00
3228ce57-6cb3-45d6-abaf-ac187cfffd52	Afghanistan	\N	Afghanistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
33b22a3b-f27e-4083-b34b-77e4f81b4a51	Åland Islands	\N	Åland Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00ad1f1f-6987-41f3-bfeb-9f560338a835	Algeria	\N	Algeria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fa60cde6-49ca-4bd5-9eab-f6a9bc476dd5	American Samoa	\N	American Samoa		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce396848-8deb-4aa4-b431-71b3d3bfdbe4	Andorra	\N	Andorra		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4878227c-c0fc-4adf-910c-0ebdd67958a1	Angola	\N	Angola		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ac1842a7-f83e-4664-93d9-b2930d7a0196	Anguilla	\N	Anguilla		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f4ac9885-a618-4a32-a94e-7bac09db0910	Antarctica	\N	Antarctica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
60737601-fad4-473f-bf0b-d436dcd0caf0	Antigua and Barbuda	\N	Antigua and Barbuda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cf90045d-8af2-4627-9dc9-e14e446bd7f5	Argentina	\N	Argentina		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
50c468b1-58d2-431e-88fe-0dbf6196a6a8	Armenia	\N	Armenia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82352c11-49be-4fef-a334-9b83fff88128	Aruba	\N	Aruba		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d44ae67e-228b-417b-a88d-4b21ec3bfb9a	Australia	\N	Australia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90007c4f-e9f3-471c-beaa-11b4a258eba2	Austria	\N	Austria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d196e20-d440-4b73-8366-bfdd42e96117	Azerbaijan	\N	Azerbaijan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
254e3f94-edb6-4e0b-a3a0-2eac0215ffaf	Bahamas	\N	Bahamas		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9efc37fa-8c13-4a69-92df-0732d11de22a	Bahrain	\N	Bahrain		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
97a55b4d-9ca8-430a-8236-88b932874a38	Bangladesh	\N	Bangladesh		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8fc52d08-1de5-4627-81e4-f55670470b9b	Barbados	\N	Barbados		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
48878d10-47b1-4089-9fdf-30c87702af7f	Belarus	\N	Belarus		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ce23ed4-ff0a-482a-a56a-9c8ba757edd0	Belgium	\N	Belgium		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1411baa4-99ae-4bf8-8634-b847cc4bc895	Belize	\N	Belize		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b9e2b88a-6419-418b-8f59-a81ab018c1bc	Bermuda	\N	Bermuda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
62501d8f-e335-417a-ae5f-977bd6df426d	BES islands	\N	BES islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21264efd-d519-4ef9-ad28-dee69161be91	Bhutan	\N	Bhutan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6e5a7e74-2851-4e9d-9f27-4de64d42a9c7	Bolivia	\N	Bolivia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e77d7f9b-4cc2-4dc4-963c-6d557ef2996d	Bosnia and Herzegovina	\N	Bosnia and Herzegovina		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d009b39-09d8-417b-bcb2-47ba483339ab	SH5	\N	SH5		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92f8a65e-d248-4bbb-ac0b-98f22fc56540	Botswana	\N	Botswana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6d88bef-a654-439c-b440-bd17d7e9205f	Bouvet Island	\N	Bouvet Island		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
74e7b709-cc08-4b59-86e5-e9aa853243dc	Brazil	\N	Brazil		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce717ca2-17f1-43fb-91c5-986a619cdcf9	British Indian Ocean Territory	\N	British Indian Ocean Territory		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ba6bda39-8757-41d1-be09-143fb6e5f608	British Virgin Islands	\N	British Virgin Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
38b95e2b-098c-44da-b8cf-76dc3089513d	Brunei	\N	Brunei		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98453c34-709a-4c59-844c-1d18598d9bb9	Bulgaria	\N	Bulgaria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b77cb593-30e7-4dd4-ad35-249cc9dca21b	Burundi	\N	Burundi		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d38dfb15-6df2-47ed-96cf-49c9eed14201	Cambodia	\N	Cambodia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2eef445d-30de-4f1d-b3b5-26dfcb212c62	Cameroon	\N	Cameroon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
173e3b3d-2608-4dc1-87f7-ea320b587d33	Canada	\N	Canada		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c5c5021d-86bf-4240-9a72-628c5d43165b	Cape Verde	\N	Cape Verde		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
842bf597-811a-4924-965e-d83778696fa9	Cayman Islands	\N	Cayman Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ff01122b-59c5-4665-a43c-bc300e81c114	Central African Republic	\N	Central African Republic		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77bb36e2-1321-4c52-b6c9-af62a6d05b5f	Chad	\N	Chad		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6fcfde81-4fcd-4946-bad5-0258fdda04d5	Chile	\N	Chile		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d24593b-dce6-41b2-b205-5d7401fe2518	China	\N	China		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56572110-5379-4736-9893-64850cf3e1ac	Christmas Island	\N	Christmas Island		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e75fbbcd-ab2d-46f6-856d-e5ab6a89b229	Cocos (Keeling) Islands	\N	Cocos (Keeling) Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1fecc724-1819-4046-9561-ffb4534d9b0b	Colombia	\N	Colombia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05b118cd-71b8-4d3b-a5b7-df03f9889ab8	Comoros	\N	Comoros		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bddccc3d-0867-4c16-9fa1-5366b16dce14	Cook Islands	\N	Cook Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
410a6ff9-ef33-4d30-a5b2-bb51eabfabfb	Costa Rica	\N	Costa Rica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
83b55c34-02e4-4b0a-ac4e-ff7b799825e6	Croatia	\N	Croatia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
97c4a7f4-e419-4294-8249-6433282625a9	Cuba	\N	Cuba		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7dbf33e2-ac69-4893-83e7-8d152a8df105	Curaçao	\N	Curaçao		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
18a902a8-b1ba-4a44-8819-8164cf830f42	Cyprus	\N	Cyprus		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2376a45d-6b8c-4dde-9dcd-3a2165a88dae	Czech Republic	\N	Czech Republic		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e66c27b2-c059-486a-b4f9-5b4aa84dbc53	Denmark	\N	Denmark		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0cd5c60d-866d-4e88-93b1-50d87e585669	SH6	\N	SH6		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c95dfee6-c7b4-4e8e-b3cf-62727f307e11	Djibouti	\N	Djibouti		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
751642bf-e865-4293-9ffb-def974e87067	Dominica	\N	Dominica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
927eda76-8872-4c7e-bdcb-797ced9b4cda	Dominican Republic	\N	Dominican Republic		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c88c1075-c244-48e1-92ac-c888f108015d	DR Congo	\N	DR Congo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
95ea513a-ca69-4252-8de7-a8fb262e3ed9	Ecuador	\N	Ecuador		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a229ee25-ab17-4a8b-825b-15e97cbf73c2	Egypt	\N	Egypt		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f35ac4fe-1d2c-40a6-9398-e4830c740e7f	El Salvador	\N	El Salvador		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
403a210f-a4f3-4811-af9a-1de9ef9536ec	Equatorial Guinea	\N	Equatorial Guinea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c345738b-bb40-4b10-85b3-ef44b98e7250	Eritrea	\N	Eritrea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c348724-e5d9-4586-ab9a-bee795ebbe7c	Estonia	\N	Estonia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6bf1afd6-cd81-48f4-b0f2-677bcd7c216a	Ethiopia	\N	Ethiopia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2699af17-a8ac-4f40-b78b-a51dd2668bed	Falkland Islands	\N	Falkland Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e156533a-5d38-4867-ad89-29a4f5ba6061	Faroe Islands	\N	Faroe Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6cf6ede-b4fd-4654-a1bc-2964937eb5e8	Fiji	\N	Fiji		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cbbc80a3-0b06-496e-b745-1bb6ed1c703e	Finland	\N	Finland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f0800e4e-5777-4705-9244-aaa094d39172	France	\N	France		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0da0b30c-a347-4b9c-b6f6-6cb7e5835a10	French Guiana	\N	French Guiana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78b8aa8c-5143-434a-bd2e-d35054b93622	French Polynesia	\N	French Polynesia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b759bdc-c037-4a34-9974-1ebec264f3a1	French Southern and Antarctic Lands	\N	French Southern and Antarctic Lands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
24e499a2-304a-410c-9476-37fddfa28529	Gabon	\N	Gabon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b05db39d-fd04-4f97-90e7-1be282fd5005	Gambia	\N	Gambia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
70088b9c-c38f-4e04-828a-245927fb22c2	Georgia	\N	Georgia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
27633507-8838-48b5-a5a8-261adce60c77	Germany	\N	Germany		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1349a35-910d-4f70-8e27-44b568236468	Ghana	\N	Ghana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dcc4096c-a2ca-4aa8-8b88-2022933d916a	Gibraltar	\N	Gibraltar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ff055cca-91b6-42f6-bbf9-1ce1e9804118	Greece	\N	Greece		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1e7f9f95-3b8f-408e-ae0d-77ae71d17d43	Greenland	\N	Greenland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f7928be6-ce56-4874-acc9-772e5405da2a	Grenada	\N	Grenada		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ee0697bb-9a10-4976-a529-64d8f9ea0f72	Guadeloupe	\N	Guadeloupe		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
60fc22c8-ac74-4c0e-b7e4-d9edb3d51133	Guam	\N	Guam		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b22bff9-2b38-48d8-9041-fb6016cb3534	Guatemala	\N	Guatemala		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e0906061-1713-44af-b496-7b41059ef3a7	Guernsey	\N	Guernsey		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b0a2652-c83b-401c-8ca2-c5b2e3cd9009	Guinea	\N	Guinea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9d9d1531-3760-4af3-aac7-9ff799679a67	Guinea-Bissau	\N	Guinea-Bissau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f5f90301-af64-4271-99db-2a146fb828f5	Guyana	\N	Guyana		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c031b42-0834-496d-aae3-b4501a58f5bc	Haiti	\N	Haiti		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9ca3589-9fba-421c-995e-2dbf8007990a	Heard Island and McDonald Islands	\N	Heard Island and McDonald Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
70dded9a-455a-4415-807e-8cc5f11a3035	Honduras	\N	Honduras		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54ebf7c8-15c4-439c-a647-b780231985ee	Hong Kong	\N	Hong Kong		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
43a70f65-ad58-4e82-9220-a014ed7d8da5	Hungary	\N	Hungary		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6fe35886-9e84-4fb3-88da-cea7ca287431	Iceland	\N	Iceland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2f3dc0b5-7a23-40e8-8690-fa0299dff5f3	India	\N	India		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e580b17c-18a5-4b1b-9eb2-175db1368bfc	Indonesia	\N	Indonesia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8592b2dd-d536-449e-8218-3f833953255e	Iran	\N	Iran		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1ffc46c-eecb-4c9b-9747-987c61bab5c2	Iraq	\N	Iraq		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
192b3847-8991-42db-8f45-4290ba8cd5f6	Ireland	\N	Ireland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f7bb6dcf-6c1e-4e15-9c05-065036d2337e	Isle of Man	\N	Isle of Man		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b29063c6-d567-495f-a083-6e600e4ec855	Israel	\N	Israel		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
57d868dd-a832-49e1-9e6a-faf02fa35f75	Italy	\N	Italy		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1689d00-945e-4cac-8f92-00e03aa3832e	Ivory Coast	\N	Ivory Coast		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5445a4f9-f375-47c3-8321-0ae64c543551	Jamaica	\N	Jamaica		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a8c96b46-1f02-4860-a305-e1f2a5c2d7f2	Japan	\N	Japan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
28cef827-6019-4be8-a85c-c1616868c5b7	Jersey	\N	Jersey		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c8fcd7e-b4b7-485c-b80d-8b209bc35a7b	Jordan	\N	Jordan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a4d2e9ea-1099-4236-a397-de6836949d38	Kazakhstan	\N	Kazakhstan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0a8451f2-d9ad-4440-b611-f38396998cd7	Kenya	\N	Kenya		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd887aae-6b3a-49b3-b121-e74dea18368b	Kiribati	\N	Kiribati		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d1f7f3f9-6b95-475d-ad2f-c26894e9ed86	Kosovo	\N	Kosovo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05d6181f-b08b-4d89-8b7b-b36e708b3470	Kuwait	\N	Kuwait		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c38469b2-6046-4f7f-a810-309e70e4639b	Kyrgyzstan	\N	Kyrgyzstan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6526e390-7fa1-4736-b3ea-27c4bc5c2fc2	Laos	\N	Laos		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd1505a3-026d-41af-9389-89b65becf268	Latvia	\N	Latvia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
41a724b4-e8af-4860-8389-1b4e19b4f9f8	Lebanon	\N	Lebanon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6ad4cb8-0fa6-4f37-afca-711f61a44c1a	Lesotho	\N	Lesotho		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0857ac32-6161-46fd-9694-c1f3b3fe14a7	Liberia	\N	Liberia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
14e508d6-9613-4268-bdd7-8805368ab855	Libya	\N	Libya		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2790dad8-ad83-4d81-9b0d-2624a9ae88b0	Liechtenstein	\N	Liechtenstein		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86837053-7f50-4be6-b22c-04216f5960e4	Lithuania	\N	Lithuania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f32b6046-e6ef-493b-b02a-5143df2c87af	Luxembourg	\N	Luxembourg		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d42ea38b-0d08-4367-9317-fae5dea89ca8	Macau	\N	Macau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d709b78-283a-4c53-a5d1-06704f1a1986	Macedonia	\N	Macedonia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
43e02f2b-af86-46d0-a31d-d2847534a7bb	Madagascar	\N	Madagascar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8798d6fe-9a25-4392-9f47-5f9000115dfc	Malawi	\N	Malawi		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bda982ee-918f-4081-93c2-675022d8f955	Malaysia	\N	Malaysia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7fb4830f-9ddd-425b-99da-32d9b3728119	Maldives	\N	Maldives		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ada4dd5c-2865-44c7-b8d5-8a6997024ce7	Mali	\N	Mali		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3cc11a37-b853-4bae-b593-5aa73bc2a4e5	Malta	\N	Malta		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0849de9c-715a-40d8-b0e2-6083f1d140f8	Marshall Islands	\N	Marshall Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b69624b-a065-4241-aae7-e59f58c3550e	Martinique	\N	Martinique		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6fd4246-1b44-4fc0-8e11-df04f120cba5	Mauritania	\N	Mauritania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9baab5d7-feef-43a9-9123-77793a04b229	Mauritius	\N	Mauritius		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6180b5b-12ee-4198-88ef-16212757878d	Mayotte	\N	Mayotte		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
458422c4-d1c9-4a36-a4fb-db8b060fa49e	Mexico	\N	Mexico		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eb1d1689-4423-4881-974f-6c075897489a	Micronesia	\N	Micronesia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d335154-879c-4757-9fd5-92c9ae5bc8ba	Moldova	\N	Moldova		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
767b4325-ff35-4fad-b432-25104fe739ef	Monaco	\N	Monaco		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
16266dfd-cbcd-4b99-80cb-909d40692b0b	Mongolia	\N	Mongolia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82575461-bfc5-4d0f-b2bd-90e34673d8bf	Montenegro	\N	Montenegro		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
59fb2d50-9bc1-426f-b6f7-247005ed1560	Montserrat	\N	Montserrat		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82760fb4-2504-4903-a3e2-0f9cb3491ddb	Morocco	\N	Morocco		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
60944a6e-9b66-4294-9c32-ba078b993876	Mozambique	\N	Mozambique		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
14ff12a7-de4a-457b-880e-3f9ac6e999f8	Myanmar	\N	Myanmar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
96850b8d-fa7f-444c-9fe9-4b71ff089e33	Namibia	\N	Namibia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d76947ca-6211-4648-98b8-71329329bcbb	Nauru	\N	Nauru		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
558184b6-d4b5-4048-9987-2fb5d9917478	Nepal	\N	Nepal		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f65443bc-9994-48c3-82b9-8e070f350f8e	Netherlands	\N	Netherlands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1bfc63ce-4290-4e3b-a19d-7206bd2d26ad	Netherlands Antilles	\N	Netherlands Antilles		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
356302a9-2f39-417a-8085-79b40180874d	New Caledonia	\N	New Caledonia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5898ab31-f5eb-466b-9c73-c9f4a8ec3cfc	New Zealand	\N	New Zealand		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c453fecd-c766-45b4-8a12-353c62485146	Nicaragua	\N	Nicaragua		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
778ebfb7-5071-4487-9afe-d0e598b92f10	Niger	\N	Niger		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e8bc1d86-af86-405e-a69a-f6b2e726c646	Nigeria	\N	Nigeria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f160d6ec-5335-4d91-8e61-16cec82cadf4	Niue	\N	Niue		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f86d865b-fbad-44f6-9d01-dd135a147181	Norfolk Island	\N	Norfolk Island		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1591fc20-5534-47cd-b9d9-5a305157c7c9	Northern Mariana Islands	\N	Northern Mariana Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b908d70f-c3a2-49ef-97a4-43a809f83173	North Korea	\N	North Korea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5055f705-c8ee-4f4a-b1b5-bc9aa2c772eb	Norway	\N	Norway		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3c55c1f-7d2e-4562-b339-ccc184ea424a	Oman	\N	Oman		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e4d12d43-460c-4adf-904a-647ae0a448ba	Pakistan	\N	Pakistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e50f0f67-c327-4bed-9c4f-a2dbbca3d98d	Palau	\N	Palau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8771efc7-85db-498d-a3a8-9485fb02af96	Palestine	\N	Palestine		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9b58b5b-8a23-44c6-9be8-b64dd49b9610	Panama	\N	Panama		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f71f9e2-d0ca-4ba9-a5d6-bbec71f989fd	Papua New Guinea	\N	Papua New Guinea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
11befbbe-7ff1-47cc-aa01-21846c68a3c6	Paraguay	\N	Paraguay		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12f9b214-7c70-47c2-96f8-5f539c4b0005	Peru	\N	Peru		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ed4eb500-24ed-41a0-b08d-ee1ec4187221	Philippines	\N	Philippines		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
23a1ea4b-b32b-42ba-b79e-143519c2e39c	Pitcairn Islands	\N	Pitcairn Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
360dc74f-881b-47fa-812c-462911cbc096	Poland	\N	Poland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0ccc1baa-3cbd-4b74-977c-250e7c54e187	Portugal	\N	Portugal		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6d24eaaf-7eba-41c9-8a27-193f6e68fe55	Puerto Rico	\N	Puerto Rico		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2cacbe4d-7708-4b76-8add-b8118483250e	Qatar	\N	Qatar		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
549f5a50-bbd0-4642-ac6c-b092e82ec928	Republic of the Congo	\N	Republic of the Congo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05496922-8758-4243-938d-13a02578f9c5	Réunion	\N	Réunion		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c149b957-3479-4ba6-ba89-d918a8ef265c	Romania	\N	Romania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7639eb86-183b-4123-aa54-16eb2e92f715	Russia	\N	Russia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d9a931c-5b06-4a57-845f-70920f65ad4e	Rwanda	\N	Rwanda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
87247b45-2bcf-43ce-a538-a76c2f8043df	Saint Barthélemy	\N	Saint Barthélemy		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a753b672-e9f7-42c2-a290-84ef816481e2	Saint Kitts and Nevis	\N	Saint Kitts and Nevis		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c00f78c-ff99-4009-922b-1b395341504a	Saint Lucia	\N	Saint Lucia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86e2efa3-d5e8-4928-8ea1-a1c30ecf2243	Saint Martin	\N	Saint Martin		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
990d3807-7410-4f98-a5f8-5a94ca1db03f	Saint Pierre and Miquelon	\N	Saint Pierre and Miquelon		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a0baafe0-605c-45da-9510-0370ace52ecb	Saint Vincent and the Grenadines	\N	Saint Vincent and the Grenadines		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3016ef36-8042-47e4-9fb5-cc811ad69218	Samoa	\N	Samoa		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f4f7c94b-7794-41f1-9ea5-ef2297c7d3ed	San Marino	\N	San Marino		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e531f8f4-c5a0-4bc1-86a9-6c77453c6a50	São Tomé and Príncipe	\N	São Tomé and Príncipe		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
717b968d-1621-4009-a35d-0cc52aea8c8e	Saudi Arabia	\N	Saudi Arabia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a2418914-f6e5-45fc-bad3-58970360ce3e	Senegal	\N	Senegal		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2a96081e-ae2a-4443-a2e7-d8cf13d299fb	Serbia	\N	Serbia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3c939846-a16a-4b00-8fa6-afbdb6c83528	Seychelles	\N	Seychelles		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cce9fe0e-9b7c-4b59-8ce3-21fc922c6bbe	Ukraine	\N	Ukraine		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
10d32cd6-32e8-45cb-8390-fa1979dfa700	Sierra Leone	\N	Sierra Leone		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73ff98e5-653f-4bed-a1f9-520c61c366a6	Singapore	\N	Singapore		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f44077bf-e6b9-4b4c-88a0-138d1f48f848	Sint Maarten	\N	Sint Maarten		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
91989f3e-c06d-40a0-ba8d-11da3a7177c0	Slovakia	\N	Slovakia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13d5da24-11d9-4058-98de-8ca5396de62e	Slovenia	\N	Slovenia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eb47bf60-2840-43a0-bf72-2c3494c95dba	Solomon Islands	\N	Solomon Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
93b29294-8933-45b4-b8de-31fc49e745c5	Somalia	\N	Somalia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4370916f-27e5-43b9-b5c9-a832d3dd212e	South Africa	\N	South Africa		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aebba94a-7fe8-4f10-b165-34ce2f2a4e5d	South Georgia	\N	South Georgia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a76f1401-6fe3-4d80-9821-fc54918d9049	South Korea	\N	South Korea		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ee2a0d2e-2192-4665-9ef0-33f65b1240fe	ACCI	\N	ACCI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6d31b4e-20cd-4cf8-a921-bd19eee0a269	South Sudan	\N	South Sudan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
053488c5-de73-49e7-942c-e00d113a6c50	Spain	\N	Spain		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98a50753-4e4c-4173-8bd5-ecd3b6512c6e	Sri Lanka	\N	Sri Lanka		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eb1f74cb-0c28-4ca6-84fe-d039e67753ae	Sudan	\N	Sudan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51bfefc0-aa90-4401-90d7-f1b7f3260d40	Suriname	\N	Suriname		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4599c76d-1bfe-4aa6-8c88-c76756bf0c41	Svalbard and Jan Mayen	\N	Svalbard and Jan Mayen		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3327f903-8fc0-4a73-81d5-0d5d2908dff4	Swaziland	\N	Swaziland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ed7ab0aa-43c2-4910-8f7c-33e89051f62e	Sweden	\N	Sweden		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cd9ea908-32ed-4014-adb4-b928e7408723	Switzerland	\N	Switzerland		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f22b6791-01ed-4506-8dcd-8b719635546c	Syria	\N	Syria		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df382611-f812-4eba-94c0-eafb47b2e4e2	Taiwan	\N	Taiwan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b297c022-0cf1-49aa-9b67-d805eea65dc3	Tajikistan	\N	Tajikistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
676a0b62-9101-4477-9679-62dc0d97f887	Tanzania	\N	Tanzania		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b10bd07-7ec5-4c0c-b32e-9591901c5999	Thailand	\N	Thailand		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e2d95594-a084-4b19-a9c1-d53389abb25e	Timor-Leste	\N	Timor-Leste		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3117436e-fe37-470b-bfd9-f70fe0d29202	Togo	\N	Togo		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b03b6ee6-9a7f-4714-98a9-0d496b5dca0c	Tokelau	\N	Tokelau		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6b8955e-dfc2-4c40-a681-d4e79b648a26	Tonga	\N	Tonga		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8aae388-363f-40a4-920c-60f70079b803	Trinidad and Tobago	\N	Trinidad and Tobago		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c9101ba-ada9-4eea-b44f-752ca702f7d7	Tunisia	\N	Tunisia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c0df42b-2392-461d-b4b2-8a2cfd035572	Turkey	\N	Turkey		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d142ea81-b91f-401f-b1c1-3acaf75b010b	Turkmenistan	\N	Turkmenistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f88f190f-8bfb-49af-81c9-ee3f5a34b7e7	Turks and Caicos Islands	\N	Turks and Caicos Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f67954de-4c18-4f48-803d-7c17dcd8c98b	Tuvalu	\N	Tuvalu		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ea515f66-04ea-4f42-80f3-36658e9e369c	Uganda	\N	Uganda		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8e7d458-0944-4fa5-acce-4cb7aaa7e900	United Arab Emirates	\N	United Arab Emirates		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9a63406c-a74f-468a-b49e-1fc9eb545ac7	United Kingdom	\N	United Kingdom		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
158733fe-2621-4548-a687-07a90032a8fc	United States	\N	United States		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
692cfd7c-6797-452f-8e3f-e2364726d0a4	United States Minor Outlying Islands	\N	United States Minor Outlying Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
20e95b2d-18a7-430c-a55b-66487d90162b	United States Virgin Islands	\N	United States Virgin Islands		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e7816d01-f433-4a9c-9715-7834208440aa	Uruguay	\N	Uruguay		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3b79f775-0076-43fe-9492-315a1b253aaa	Uzbekistan	\N	Uzbekistan		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e86c18eb-fefb-4544-9f05-f9f33253a510	Vanuatu	\N	Vanuatu		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
23917e73-7b2f-4f40-90fc-dad68273dfba	Vatican City	\N	Vatican City		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1fbee02f-bb4b-43ae-8c41-798d0de1cd91	Venezuela	\N	Venezuela		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2aa98e8d-1b04-4293-8313-286c3503f7d7	Vietnam	\N	Vietnam		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5d30447-89b0-49a1-ac69-0d52edc16edc	Wallis and Futuna	\N	Wallis and Futuna		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d1cd3b83-a2bf-4efd-a065-8064d568bdb2	Western Sahara	\N	Western Sahara		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c278c065-7842-48ad-bc2e-e0380e3a035b	Yemen	\N	Yemen		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b68b876-3041-4305-b893-8a2073f2854d	Yugoslavia	\N	Yugoslavia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f96cb3f8-3dfc-41ae-9dde-db40e7f35436	Zambia	\N	Zambia		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df8d9162-df11-4c47-9d0d-2a1f89625045	Zimbabwe	\N	Zimbabwe		country_name	countries	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f66be104-5936-41f0-82d6-2585538c06d3	ID1	\N	ID1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e2968b4-7b27-466d-b877-b245d712a88c	LS1	\N	LS1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3cf169c-f243-4bf2-b50c-8d664e1ce116	LS2	\N	LS2		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9acdbef9-63ca-4ace-b504-badfcf6c2d26	LS3	\N	LS3		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e784d2ba-84d3-444d-98d1-a482ce1b19da	LS4	\N	LS4		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
49e3bbac-f55f-4933-8d60-2ececd66967c	LS5	\N	LS5		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a286f415-03a0-4a3e-b15e-1765980a3120	LS6	\N	LS6		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13685631-add0-4beb-8b27-6d193ace7901	LS7	\N	LS7		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
24f73c2f-0d4d-47b2-ac0c-98633e6e6a43	LS8	\N	LS8		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e9bb452-237e-414d-910b-7c8075b59519	LS9	\N	LS9		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e55b97b4-9986-4751-b65c-912c89a4d1e9	PE1	\N	PE1		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
316b6eee-046a-40a8-be3f-3414320a938e	PE10	\N	PE10		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d8ba145e-12f7-4d18-abcc-3e9ab2c086e2	PE2	\N	PE2		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d893531-f93a-4c20-8574-d1ca3801f0a5	PE3	\N	PE3		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5de601f-d221-4d7d-b30b-ab93af700ab1	PE4	\N	PE4		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce1d4272-0e54-4fbd-bfed-76a4ced6a7ef	PE5	\N	PE5		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ac9bfb8-2466-45ff-a7b0-b3cc81a58bff	PE6	\N	PE6		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92dfe840-c359-4e69-9316-686035d45380	PE7	\N	PE7		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
24d2d1d9-8714-4770-bda9-a9554d37f190	PE8	\N	PE8		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
52c523ba-4898-4014-810b-de7cd4157cf3	PE9	\N	PE9		code	erc_panels	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4694605b-41d7-4ad3-8d38-c67f83bf6997	€ROSNZ	\N	€ROSNZ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0cc98010-afe8-4d45-975d-0e57b3193f5b	03K	\N	03K		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68e2edf6-b4c3-42da-b410-108a410d7c41	0DISCRIMINATION	\N	0DISCRIMINATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5898dc80-a31f-46ee-a2ec-f7b0b01dd0f5	0E-BUILDINGS	\N	0E-BUILDINGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
27e27292-9c14-4a81-9029-69d384424604	0MSPIN	\N	0MSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
097e64fa-8681-4d8e-b5f2-5ea83090a395	10000 DIGITS	\N	10000 DIGITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b4efda5e-db62-4511-9225-1c5b16cc350a	1000kmPLUS	\N	1000kmPLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
819584a0-6825-42b5-b6ed-1d51924e15bc	100 Archaic Genomes	\N	100 Archaic Genomes		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2fddb76e-2933-4c99-ad57-b3baa4de4d71	112CO2	\N	112CO2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c5877350-e596-4f5b-9d95-9fc61c61453d	123STABLE	\N	123STABLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7c87af04-bf44-4418-a72e-d77fbf91ed1e	14_3_3	\N	14_3_3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
893281e6-b7ec-4588-b82a-71f21f45fee4	14-3-3Stabs	\N	14-3-3Stabs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
706f2103-9957-4d36-a14f-2d7ddbb5ec2a	14Constraint	\N	14Constraint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67fc3b9e-d2a9-414e-855a-8e61f1ef91b7	15CBOOKTRADE	\N	15CBOOKTRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
62fa8351-e8c8-43e5-a6ba-ccd1dd6fed71	16gAirTest	\N	16gAirTest		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
85d7230f-60c3-4c38-ab15-2ba5b71e7306	16gAirTest-Phase2	\N	16gAirTest-Phase2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ae26aa6-1271-44b2-8188-9678ffa68f75	1960s Bombay Cinema	\N	1960s Bombay Cinema		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1842583-e963-4171-84d4-438b6aaed51d	19TH-CENTURY_EUCLID	\N	19TH-CENTURY_EUCLID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6cc47324-900c-4aa4-9226-2fd698ec623d	1CELL-MICROPROBE	\N	1CELL-MICROPROBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3ded36e0-dfc9-4620-9238-ff9ab27de817	1DDIPOLARGAS	\N	1DDIPOLARGAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c17a12a1-4b74-4aec-93f2-5e0475d17579	1D-Engine	\N	1D-Engine		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9382977b-3beb-4d1b-ba22-235c0506bd0d	1DH2OP	\N	1DH2OP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0de07352-cdd3-492a-a5f1-9882afbdca0a	1D-Neon	\N	1D-Neon		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b30eaf1d-9d42-482a-bc10-9d644c3626bb	1DSOLVE	\N	1DSOLVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dda06750-27f4-462e-9b84-fcea3a369522	1MoleculeNearPlasmon	\N	1MoleculeNearPlasmon		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e60b8d86-26e2-4ef0-83e8-b1be089041c8	1st-principles-discs	\N	1st-principles-discs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0ba98cd1-23c3-41f9-933e-dd251c7722b0	1stProposal	\N	1stProposal		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d0fb8844-c1a2-486e-864b-5a2954eece54	1-SWARM	\N	1-SWARM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2aff3340-1a9d-444c-9639-7f0326d2a6df	1-SWITCH	\N	1-SWITCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
440de30f-561f-4f90-a78c-0b33c307b773	agen	\N	agen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
79d32a66-12bc-490a-9af8-d3091f9e2ac7	1toStopVax	\N	1toStopVax		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4583b852-fab7-4cb7-a498-680006c9aec0	2007UWM	\N	2007UWM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7fc4f3a1-c497-4953-b23b-c919d7704306	200SMEchallenge	\N	200SMEchallenge		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eac7a672-6cd8-467d-a448-b92f3be67d7b	20-20 3D Media	\N	20-20 3D Media		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54714718-54d5-4114-80f9-eb0e12ea9f7c	2020 INTERFACE	\N	2020 INTERFACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
06613db2-2276-49d2-8aca-cd1ad8432e23	2021 GRIP	\N	2021 GRIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6e52ac88-ec88-4376-ba26-20871e709073	2050AP	\N	2050AP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cc4deb39-b24a-4c7e-b693-0f9fcf723af3	20PLµS	\N	20PLµS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0bdc38e9-3604-441d-97d0-8d7ac5a7615d	2D-LOTTO	\N	2D-LOTTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56b175f2-29b4-4f3b-97f4-ac751708c52f	20SComplexity	\N	20SComplexity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b4030059-ac27-44c4-87ac-3b45c5fc1138	20SInhibitor	\N	20SInhibitor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7745f5a7-f21e-4a27-9c22-bae07f230669	21Alpha	\N	21Alpha		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40415a99-fa2d-4c1c-9c86-80b3161f9df5	2-3-AUT	\N	2-3-AUT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d9ba30ab-5e5a-43ee-b119-6d7651803561	2-3SST2016	\N	2-3SST2016		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2f2b1a4b-2d64-4d9d-88f6-2f3e583b60bb	2-3SST2018-20	\N	2-3SST2018-20		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c38a4d4-39ea-4e93-8fd9-195ce9a542fb	24G	\N	24G		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c436ddc0-2315-458d-99d9-f9ea858bdef8	26S PROTEASOME	\N	26S PROTEASOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76728072-ccd8-416d-95ae-c1f32ab2258a	28 June 1914	\N	28 June 1914		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07359033-206c-4f78-a0ca-b6bee34fb5d7	2-BE-SAFE	\N	2-BE-SAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7abcb13c-34f4-4e0a-9819-22d2e59a7694	2BFUNTEX	\N	2BFUNTEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6eb299b-207d-4458-88a7-e5120585d9d7	2B-ROBUST	\N	2B-ROBUST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0bbcecc3-ad2a-4a8a-8668-8f894281f45a	2CE MECP2	\N	2CE MECP2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
261fc099-09fb-405a-a106-dfc403cf7218	2D-4-CO2	\N	2D-4-CO2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6b06e66-575f-43ce-8751-6b6a2ff79457	2D4D	\N	2D4D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5a9e10e-ddeb-4f7a-958b-eee314554bd9	2D4QT	\N	2D4QT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0208e2b4-61b9-4589-90ed-f4266c15d78d	2D-CHEM	\N	2D-CHEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fafa391f-00ab-42ef-aa36-94ca0b4cd4cf	2DCHEX	\N	2DCHEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
792f2341-3a68-4fff-815b-19253c44c7a8	2D-COF-WS	\N	2D-COF-WS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd9d384c-32ac-4f2d-9acf-235c9ad271bf	2DDip	\N	2DDip		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fc009b96-f8d1-40c6-bdec-586908cb23bc	2DECIDE	\N	2DECIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40babd03-229b-4a9e-8658-2445722a04b0	2D-EG-FET	\N	2D-EG-FET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7500f7da-e59f-4603-b99a-e6ad9279ec15	2D-EMI	\N	2D-EMI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4e30c6f6-98c8-4e3f-aa46-70c2d864cc74	2D-EPL	\N	2D-EPL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f06672d-d2a2-4ee3-8b56-1d6183b54e42	2D-HETERO	\N	2D-HETERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ea0a45ef-0a72-4928-a3b1-101b2c336f6f	2D Hetero-architecture	\N	2D Hetero-architecture		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9b4520f-423c-4156-ab47-557d8a07b106	2D-HETEROSTRUCTURES	\N	2D-HETEROSTRUCTURES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a72b717b-55ec-40bb-8be5-7d46437955ee	2DHIBSA	\N	2DHIBSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a74c6f19-e8ba-4dcf-be74-2fb3affeb284	2D-Ink	\N	2D-Ink		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3b93e317-caba-433c-a932-6a1135a8ab37	2D-INK	\N	2D-INK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7f2f4ec5-3765-42bc-bc24-2c2807549f99	2DInterFOX	\N	2DInterFOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ae9704d-0fd8-4f41-a054-d78959cadff9	2DIR SPECTROMETER	\N	2DIR SPECTROMETER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9cf4e508-0ae1-42df-8876-d28d476cb118	2D-Liquid	\N	2D-Liquid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b844a747-41b1-49c8-bf74-4dfa69d7f16e	2DMAGICS	\N	2DMAGICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fc837d4c-a676-42b0-a4d5-048b3b51960c	2DMAGSPIN	\N	2DMAGSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d9f60b14-9d4c-4bf0-92d6-a1bf06ba302a	2DMAP	\N	2DMAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f443f2e-dd33-477c-9ac1-b7593c62d2cf	2DMAT4ENERGY	\N	2DMAT4ENERGY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b95c7689-711f-4687-b692-499dad17721b	2DMATER	\N	2DMATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8c38dd20-69c0-41fd-a62f-ab4a5b5f3929	2D-MES	\N	2D-MES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c423e91f-dd91-44b1-8d34-49d7aa1e5521	2DNano	\N	2DNano		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9bf186e-bdf4-4d68-8339-7c345fee8e97	2DNANOCAPS	\N	2DNANOCAPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5caf62f-184a-405f-8bb7-d17bdbc5de2e	2D-NANOLATTICES	\N	2D-NANOLATTICES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b6ae3a68-2e28-40a4-b34a-294e6e075183	2DNANOPTICA	\N	2DNANOPTICA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7007b65b-8a13-4442-9198-36c9a5c7a5dc	2DNanoSpec	\N	2DNanoSpec		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7eea6b1-9cb1-4088-bd46-9549aecfdd8b	2D_PHOT	\N	2D_PHOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7238d64a-d504-4a32-97c5-eca75ef717ba	2D-PnictoChem	\N	2D-PnictoChem		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
62d7952e-5d1a-40f5-8d81-00a66db5a530	2DQOptics	\N	2DQOptics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2a52acf5-c855-41a5-bcad-4385f522b184	2DQP	\N	2DQP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5799863b-f9ba-44c1-9fd9-22be80f571be	2D-QuEST	\N	2D-QuEST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
561bbf6e-85a0-45be-a7fd-8d6898e36eee	2DSi	\N	2DSi		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6617fa93-7e8b-4321-b762-47ec482c7a82	2D-SIPC	\N	2D-SIPC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b73960dc-3af0-47d3-9bb0-0638ff07f150	2D-SMARTiES	\N	2D-SMARTiES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2f716e76-341c-4fcb-b35f-664a330934bf	2DSPIN	\N	2DSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd1dd97b-2014-490e-a2bd-14de4ac6cea1	2DSTOP	\N	2DSTOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
79adf45b-b8ae-4b86-9144-ac5c39ae9e83	2D–SYNETRA	\N	2D–SYNETRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8735b9e1-1a91-4541-a414-f0b0ec1dfa12	2DTHERMS	\N	2DTHERMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7df5fb4a-de9d-4880-addc-bffe6c9b9b0f	2DTMCH2	\N	2DTMCH2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0667c8e4-93ed-45d1-b603-b1761bc9abd0	2D-TOPSENSE	\N	2D-TOPSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4511c6d2-f9fb-4b3b-ada4-4b10c6e86d12	2DTriCat4Energy	\N	2DTriCat4Energy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
43bde567-a442-4e19-b292-83b30b81dee6	2DTWISTMDs	\N	2DTWISTMDs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d891bff0-1ce8-4fe0-b791-d8003f3d72c2	2D-USD	\N	2D-USD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6031b5a-dde7-4340-9bcb-f342b2dc8062	2DValley	\N	2DValley		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5ada5de4-7f90-448f-8e0f-6792ea64393f	2DvdWHs	\N	2DvdWHs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42e23e4b-0166-4170-b2c6-2c80cf78af46	2Exciting	\N	2Exciting		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04761a5a-c00f-43c3-869a-2b6df314e5e7	2F4BIODYN	\N	2F4BIODYN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
88235946-8d2b-4338-92b1-50fab0c0d983	3D-ADAPT	\N	3D-ADAPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
831b7a0e-e654-4583-8891-253ea81a8a3d	3ants	\N	3ants		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6357d7ce-5b93-4558-ba7a-752b3fbfe216	2for1-SingletFission	\N	2for1-SingletFission		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
15c27893-cbd4-4310-8709-dbfdf1298040	2G BIOPIC	\N	2G BIOPIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
577214df-0d10-4a74-a3cd-793bf7e94488	2G-CSAFE	\N	2G-CSAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9115a0a2-0a4d-4064-82d1-bc13494956e1	2GENRETURN	\N	2GENRETURN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68b090a6-64a0-4406-b0bc-afe49553c14c	2-HIT	\N	2-HIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd751257-4c80-411d-8822-c5e177a51b75	2-IMMERSE	\N	2-IMMERSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dae35fa2-e64a-4961-9ddb-af852a0bfc89	2ISECAP	\N	2ISECAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1273f31-6eed-48ae-97f0-3f1e02bd3acd	2LIVEr	\N	2LIVEr		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e2337c31-0f24-4dd6-809e-7c638def5a5e	2LOOPACCURACY4LHC	\N	2LOOPACCURACY4LHC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d2f73159-f8b9-43db-aa59-67557bd608e5	2MODEACHIP	\N	2MODEACHIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9949354f-23c1-402d-80bf-b4549dcd59d9	2MODELS	\N	2MODELS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eaec3589-c9e9-479c-8c6b-90b5d736a394	2MOVE2	\N	2MOVE2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34212144-ce11-4879-9a1a-5d184e93b9fb	2MoveMate4Melanoma	\N	2MoveMate4Melanoma		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
645877ea-06a5-432b-b2a3-065f1fe8d63f	2-NanoSi	\N	2-NanoSi		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b12808ff-3895-4a98-acd2-9e9aaecc6dd3	2ND-CHANCE	\N	2ND-CHANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a3f7efd-b8f3-4ec5-b3ce-23e64dd3ccc1	2NDVEGOIL	\N	2NDVEGOIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eab61c79-ca19-4b81-a88b-fa6357685af1	2NIGHT-2GETHER	\N	2NIGHT-2GETHER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb5efe27-6353-4a0a-a970-17a9bb69d2a7	2O2ACTIVATION	\N	2O2ACTIVATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aa6ba564-5015-40c2-955d-0995dffdd4c6	2PARMA	\N	2PARMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d2d33ed9-ae0e-4b9b-8094-78e1bfc43d05	2PM	\N	2PM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c249f233-24d3-46ec-9a5d-6587767859d9	2PM T cell Imaging	\N	2PM T cell Imaging		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67388999-33e9-4eeb-9570-02f2a9dc89b4	2SEXES_1GENOME	\N	2SEXES_1GENOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
127bc436-534a-4f29-a23d-e9f503beaf03	2shRNA	\N	2shRNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b29e4b76-7ce1-4f58-9695-f6d56adebde8	2SST2015	\N	2SST2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bc2e775a-7bc7-4c19-92fb-2c6363c73e88	2STEPPARKIN	\N	2STEPPARKIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f7a3e73e-c281-44e4-abe1-4ba7402be49e	2STOP_TBE	\N	2STOP_TBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e0a69d6e-a9bc-49f2-85e9-4ea3e5d082a4	2WAYS	\N	2WAYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07b2a81f-f2c9-4559-b5f6-cec6fae607c1	2WIDE_SENSE	\N	2WIDE_SENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fed33ee0-88a4-49c6-b53d-0ec07e254f38	31P_SPECTRA_3T	\N	31P_SPECTRA_3T		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e524491e-21b8-4de0-b3ef-e59f57fdbcff	321	\N	321		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98a0c631-d3fe-4e11-b769-469be7ff5eb9	321526	\N	321526		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
618e15b4-6448-4f62-bd59-97503645b57d	321NOW	\N	321NOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04cc9892-a0d4-4990-9166-8153215e9029	3-5-FIRST	\N	3-5-FIRST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f84da173-59d2-4dd8-808d-9e9c1fc93003	3Bee Hive-Tech	\N	3Bee Hive-Tech		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90a389d6-e260-40e8-b9c0-8954ea2ec119	3beLiEVe	\N	3beLiEVe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
95624082-4784-4695-ae66-2fc1f4768f45	3CBIOTECH	\N	3CBIOTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1528d4cd-57ae-47ab-8564-8fee61df631e	3Ccar	\N	3Ccar		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21793251-e3d9-494b-84c2-7190cc708376	3C-SiC Si	\N	3C-SiC Si		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
003dd6e7-05b6-45e2-89fe-8a4791c496d8	3D	\N	3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1a6637f-ba20-4616-b4f9-8732ce606dd9	3D2DPrint	\N	3D2DPrint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf7d054c-491a-435f-9955-1da3176f0247	3D3CSI	\N	3D3CSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7bd1552-11ec-41af-b2f3-92339fcad034	3D4YOU	\N	3D4YOU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9111736-69cc-4e62-8e9a-f731a6c650c3	ACLACL	\N	ACLACL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f7a31ed-3fd8-46ae-a026-81660083abad	3DAddChip	\N	3DAddChip		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f09109e-1368-435a-bca4-ede0e3b99b8f	3DALIGN	\N	3DALIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aacf5874-fd1b-44e7-b04c-d219b443a2a3	3DAM	\N	3DAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3bae2591-6df8-4342-90d7-b360790e2024	3D-AM-TERA	\N	3D-AM-TERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
280a2ddd-b3a2-4f63-a7f1-3f9a4ef3e33e	3D-APP	\N	3D-APP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89afd26f-6398-424a-9415-dd772af8b385	3DBAG	\N	3DBAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
25248084-3f09-4040-b224-a3055d82a59d	3DBattery	\N	3DBattery		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dfa422fa-aa59-40d5-adb6-f087ad3e604e	3DBIOLUNG	\N	3DBIOLUNG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
02ef0474-8c38-4ec6-b793-24c5b7c1b431	3D-BioMat	\N	3D-BioMat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1131bf80-8fb9-4c8a-a236-00c404badb57	3D BIOMIMETICS	\N	3D BIOMIMETICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cb9d88be-ce68-49b1-a930-e8398d971989	3DBonding	\N	3DBonding		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b51916c4-e561-43d5-a596-4b366bf3b3e7	3DBrainStrom	\N	3DBrainStrom		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8d0ba9a-fc7f-4478-876a-1f40db9de9e7	3DBREASTCANCER	\N	3DBREASTCANCER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67fca81d-34e3-48c3-88be-98bd27b11001	3DCanPredict	\N	3DCanPredict		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f75d1167-5f92-486c-a332-66cf568d0407	3D-CAP	\N	3D-CAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d04dbd29-e00b-4830-9f0f-7d0fa02ebc86	3-D Cardioid	\N	3-D Cardioid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f3343582-5078-4b55-a335-36002ff38917	3DCC	\N	3DCC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8382cf4a-bae5-4ed1-b09a-343cefb8f769	3DCELLART	\N	3DCELLART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6171b776-277a-4a29-a0d0-f8f309aef905	3DCellPhase-	\N	3DCellPhase-		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
85e5bdce-2c91-4573-a1ba-7387dc28e234	3D Cer-Met	\N	3D Cer-Met		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c8397cbc-68bd-41b9-9b48-a80bac582a41	3Dcis	\N	3Dcis		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c5c1c33-bb92-47d5-9d5f-b343e022f1db	3D-COFORM	\N	3D-COFORM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b49c6e8-48f0-4cbb-a829-7d7e677aefc6	3D-COMPETE	\N	3D-COMPETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21a63ae0-fc25-4e81-af9f-121febe8a416	3DCOMPLETE	\N	3DCOMPLETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21455666-a66c-459f-846a-c8bd82b78cad	3DConfigurator	\N	3DConfigurator		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
924f0476-9fc2-4480-8f16-9c41da1685b6	3DCONTACT	\N	3DCONTACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7740d6ed-173f-45c1-be9b-da3507a12f52	3Dconvert	\N	3Dconvert		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55226146-2294-48ae-9f9d-8fcdcb62b81c	3D-COUNT	\N	3D-COUNT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1530277e-9027-47dc-bc85-8b21fdeb3b5f	A2C2	\N	A2C2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a2bc01f6-36e3-4855-9283-ea1bcd2ac55f	3D-DERMAL	\N	3D-DERMAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8ea2bd5-213b-42ea-abc4-dbb78488a03c	3D-E	\N	3D-E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f24b6d9a-cbc0-406d-bb0d-4625449b1116	3DEpi	\N	3DEpi		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42f5bc54-f5e8-4b2c-97ab-079eb873cec3	3DEPLAN	\N	3DEPLAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f11fa695-b47d-4c01-b629-29c33717434c	3D-FABRIC	\N	3D-FABRIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8702be75-58ad-4486-9323-a91bdade9efd	3D-FIREFLUC	\N	3D-FIREFLUC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
de610c47-8f11-4b4d-aab7-6f69e9c6c990	3DFIRELAB	\N	3DFIRELAB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
38c88f95-4b0f-4d64-932e-6fb72848117b	3DFlameGT	\N	3DFlameGT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8fb255b7-7d17-4bad-b49f-a948f2e59bae	3D-FM	\N	3D-FM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd8c288d-4ebb-4d3e-8a25-c69f5dd8913f	3D-FNPWriting	\N	3D-FNPWriting		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
756e53f3-3dc8-4a55-92a2-6a6f5a783ad8	3D-FOGROD	\N	3D-FOGROD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f1e7891-055e-42d9-81e8-d93d69bd2848	3D-FORENSICS	\N	3D-FORENSICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ff30a707-03b0-493c-9893-c50f857102ee	3D-Forensics/FTI	\N	3D-Forensics/FTI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8f16235-5a4b-4117-9c67-c8731fc3379c	3DFOSSILDIET	\N	3DFOSSILDIET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae55d71c-bb28-4fec-9df1-361a5667648c	3DFSE	\N	3DFSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9da1c784-401a-4885-b3f4-241b87ceda65	3D-GATED	\N	3D-GATED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
57a739a1-9f55-4723-9598-7718f5429cad	3D GENE SHAPE	\N	3D GENE SHAPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eb28aed9-7b36-424a-86d0-8be69ce237f1	3D Genome Dynamics	\N	3D Genome Dynamics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5ced9375-e7ca-4587-b532-56e56cf3eb2c	3DGUIDE	\N	3DGUIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0340abb1-26d0-4b10-a003-7d9116cfe45d	3D HCS imaging	\N	3D HCS imaging		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12ceae04-4bb3-45a3-a0b9-73870d5f5878	3D-HIPMAS	\N	3D-HIPMAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
144f109a-7589-4ee1-b980-d2edb59919dc	3D HMEC-MT-TIP	\N	3D HMEC-MT-TIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b01f814-6d09-43f2-bc16-bc0022ca0ea2	3DHumanSpinalCord	\N	3DHumanSpinalCord		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04fccfce-22ff-43ad-928c-123c8bf0ce7d	3DICE	\N	3DICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eed6e8b9-b70e-43b4-bc97-ed5eff48405f	3DIMAGE	\N	3DIMAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e333c379-902c-4818-89e5-c8b7bf0d4a31	3DInAction	\N	3DInAction		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9a4f8241-ed3a-4d27-8e49-3010391d281f	3D-In-Macro	\N	3D-In-Macro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
99f42550-9281-4d63-b9c7-8309758753d7	3DINVITRONPC	\N	3DINVITRONPC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9e4f8a8d-45b8-46e4-81cc-201ba66ae020	3DIS-NN	\N	3DIS-NN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
230fa893-d76b-4545-b9e6-6fe811de9c99	3D-JOINT	\N	3D-JOINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12d24ba9-9891-48ff-9d39-765476f55d74	3DKF	\N	3DKF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a493ba13-b82c-4281-9cb4-6ee574ec0ce0	3D-LEAP	\N	3D-LEAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2d673b24-6074-42f5-a186-dde9c2f26413	3DLENS	\N	3DLENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76d02663-2deb-41ad-aeb3-58a0b1c2a585	3DLife	\N	3DLife		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd2d3bf8-129b-49b9-bf8e-b44b13a6b391	3D-LIGHTTRANS	\N	3D-LIGHTTRANS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ef295c63-9928-4222-98b8-451b6234b1a8	3D-LIVE	\N	3D-LIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
beb708ec-bec1-4be9-a52e-5c6312de02f3	3D-loop	\N	3D-loop		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
52ac189c-a005-4317-b580-a6c3b6d4b09e	3DLT	\N	3DLT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
609beede-aab7-4c6e-a9d9-5ddd81e37e18	3D MAGiC	\N	3D MAGiC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78b5794a-f3c3-4993-a43f-3630944b071e	3DMAGNANOW	\N	3DMAGNANOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4bc18bf3-7446-46d6-a720-d25e08d5dd5a	3D-Maps	\N	3D-Maps		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ebe8241b-0495-4e58-b513-7f90fbe2ae56	3D-MASSOMICS	\N	3D-MASSOMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07c077ff-2019-4440-84f4-67ae5bc47276	3Dmaterials4Energy	\N	3Dmaterials4Energy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04c3eba8-b9a8-4aa1-9d26-5dbbe49531e8	3D-MIFS	\N	3D-MIFS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
716541f2-5686-4f15-90b2-4940c20ee2b2	3DMIG	\N	3DMIG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d78938d-a769-4d33-82fa-511f2da30bd1	3DMOSHBOND	\N	3DMOSHBOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f71c537-5f7f-4b5a-968a-fc289529a7bf	3DMP	\N	3DMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fcaa13e6-fd78-4c65-b17a-6e3885f6d92d	3DMUCHO	\N	3DMUCHO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8e3ed1ad-8ed2-4c00-bc0c-fcb921227d55	3DMULTICAT	\N	3DMULTICAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a1a7b15-4fc4-4d59-833d-2eb239ca53dd	3D Multicell Growth	\N	3D Multicell Growth		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c7eb636-c302-4f38-b6a2-37974d68169a	3D Multiscale Model	\N	3D Multiscale Model		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3996593f-ddcd-45d0-90c3-c42fc2918bca	3D-MUSE	\N	3D-MUSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2d7ff4bb-34ff-4f40-b369-6ff0a9f99dfc	3D-NANOBIODEVICE	\N	3D-NANOBIODEVICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
49c33038-2add-4291-912b-ac5b58c119bf	3D NANOCHEMISCOPE	\N	3D NANOCHEMISCOPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8a792330-8c11-42ff-b932-8d87c95c9aca	3D-NANOFOOD	\N	3D-NANOFOOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1a3413ce-f3d0-4b8d-8d14-a267b1a8a3c7	3DNANOMAG	\N	3DNANOMAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4621cb0a-b8f9-432e-8f2a-e77223062e4a	3DNANOMECH	\N	3DNANOMECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26e04c44-9f0f-49d3-b1dd-91fe116cda94	3D-nanoMorph	\N	3D-nanoMorph		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bca9a36c-0627-4edb-97e6-3828ac0fba82	3DNCPM	\N	3DNCPM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
830befc2-c2c7-4101-a99e-6875fac23da9	3D NEONET	\N	3D NEONET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ff2b350c-1df3-4dbd-81c6-ffbe9c2497eb	3DNET	\N	3DNET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
697d6f24-463c-4cc4-b87a-e0e7bb8e2d73	3DNeuroN	\N	3DNeuroN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ed9c416-9a82-478f-8e1a-0ba5d32d2fe2	3D NKCC1	\N	3D NKCC1		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
366bae0a-0ff9-43dd-98bf-56458052f1c2	3D NOAM	\N	3D NOAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1218c0b2-3998-47a7-9438-8b71fa7f9089	3DNSBT	\N	3DNSBT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3aa2e39a-6030-4332-a93c-dee71e3c0d4e	3D-OA-HISTO	\N	3D-OA-HISTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5a1e73c5-461c-46cb-9eaf-1a5e7b86e715	3D-omics	\N	3D-omics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
52c2294f-916f-48c8-8ea7-1fb8a01f8b3a	3DPartForm	\N	3DPartForm		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6fadb780-2a1c-4930-bf31-f6fbf8876b0e	3DPBio	\N	3DPBio		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dbea0f35-f343-44c7-ac2f-5479889b728c	3DPD	\N	3DPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d665507e-c3bf-457c-a310-3d5bb14790b2	3DPHONE	\N	3DPHONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dac164ce-32de-490e-bb2e-08bef76ee97f	3DPILcat	\N	3DPILcat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a0d50baa-0099-47b3-9d8c-d4d6d214b9e7	3D-PITOTI	\N	3D-PITOTI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5d8b78b0-8435-4ef5-85d2-ea63a45b38f4	3D-PIV	\N	3D-PIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6227ad4b-5f29-4b36-a372-dff4715f0b38	3D-Plant2Cells	\N	3D-Plant2Cells		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fbf13d55-4e17-4803-8c2a-59d72224d02e	3DPLASTICITY	\N	3DPLASTICITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e61e6ea-354f-484c-ad8c-9cabd4403cbc	3D-POWER	\N	3D-POWER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
94593afc-51bb-4be1-8083-7f37cf764c32	3DPresence	\N	3DPresence		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1a5cf997-0b98-4fe1-9d23-142f93cd60d6	3D-PRESS	\N	3D-PRESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b4b7bbc1-8a26-4f4e-b294-fe9e5dc4882d	3DPRINTEDOPTICS	\N	3DPRINTEDOPTICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47cbd3a7-4580-4b3e-a273-d163cac2d6a7	3D - PRINTGRAPH	\N	3D - PRINTGRAPH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58380410-5f26-4287-a9bf-8cc08c03faf8	3DPRINT-VASCU-CHIP	\N	3DPRINT-VASCU-CHIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d2f23a8-e233-4d0f-99ca-b95f18b90760	3DPROPLYDS	\N	3DPROPLYDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6b31e33-26ef-4f67-97dc-e46e3a71c7d8	3DProSeed	\N	3DProSeed		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5cea6bf-35eb-473e-aafd-ac39e33b8cc5	3DPROTEINPUZZLES	\N	3DPROTEINPUZZLES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ff4bc15-e43a-48a1-9188-42b66ccc0f0d	3D-PXM	\N	3D-PXM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
66c3cd24-b8db-4ada-b64a-c6c2e0427451	3DQDOTS	\N	3DQDOTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e14d3a7a-7fa8-4c8f-ab61-2c02fc8d85cb	3DQuant	\N	3DQuant		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fe663125-5a38-4eab-bb93-4675d15312fb	3DQUANTGRAV	\N	3DQUANTGRAV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ecb0587c-f76e-4181-831e-907a75f1b6a4	3D-QUEST	\N	3D-QUEST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9aa08e5c-56e1-460a-8300-b35b3bedaa44	3D Reloaded	\N	3D Reloaded		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0fc3fdd4-c406-4f2a-a89e-8aa789e83dbe	3D-REPAIR	\N	3D-REPAIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
69de824e-7015-45ed-8087-da3eeefe5f33	3D-REVOLUTION	\N	3D-REVOLUTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb6b18b5-a8da-4f8f-9bad-6c36a2624dbc	3DRM	\N	3DRM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00678f88-a925-4627-b665-e382ebf0654a	3D-Roving Deposition	\N	3D-Roving Deposition		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f3df5116-bbc2-4cf9-ada9-9783fe149dfc	3D RZP	\N	3D RZP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
634c7d88-be63-4c1b-87fb-655e703dc01d	3DSCAN	\N	3DSCAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
20e3e24a-8212-42d1-a195-cb39894ffe58	3DScavengers	\N	3DScavengers		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56233aae-35e5-4da2-ac96-66faa4054760	3D-SE	\N	3D-SE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
41322efc-fbd6-4d53-a264-39622a4b12f6	3D-SITS	\N	3D-SITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
49d672dd-92e9-4da2-b6e2-4dbd1aa9872a	ALFA	\N	ALFA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
964e9be7-9eef-4e61-8d71-626c6ce8ceed	3D-SMoHC	\N	3D-SMoHC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
792044e2-e121-4521-aab6-d9b04e71a6b7	3DSPIN	\N	3DSPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e79b746d-7aa6-4a09-9c81-af8148fbcd7c	3DSSS	\N	3DSSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c0d3b932-ade3-407d-8ccf-63d1b5a48858	3DSTAR	\N	3DSTAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
612726b4-a334-477a-a269-95f1de33e6d5	3D SWARMING	\N	3D SWARMING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c6fac28-c39a-44e1-8306-77e1422b4651	3DTransducers	\N	3DTransducers		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c2d7ecc-fa3b-464f-b5bb-b0d5d6fa3a17	3DTRAY	\N	3DTRAY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9ee87ce-a51b-4eaa-bec0-18f1c17931d4	3D_Tryps	\N	3D_Tryps		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
da574bee-8de3-4936-967f-944e53c06d32	3DTTool	\N	3DTTool		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e97d79ed-18c3-4279-99f8-ca5a1ff4cca4	3D Tune-In	\N	3D Tune-In		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b147b07-ff99-4c98-842c-17568943a8b2	3DTVS	\N	3DTVS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e8f511ba-7b77-4493-aa80-37b9c836a9ca	3DUNDERWORLD	\N	3DUNDERWORLD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32a0218e-aea9-40ef-a3e2-aac2069a4dd6	3DV	\N	3DV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13e1ab23-3030-4815-b395-f2e79e228d4a	3DVasCMD	\N	3DVasCMD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42dc35e8-97ed-49bb-908f-d288c6d35844	3D-VIEW	\N	3D-VIEW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d63e284b-27d9-45f9-8141-88687fbb2bc6	3DviralRNA	\N	3DviralRNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
53961334-4a8b-459e-9ac8-cf7217d24a77	3D VIVANT	\N	3D VIVANT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bedfcc85-cc4b-4e4e-9bbe-1b2065956949	3DWATERWAVES	\N	3DWATERWAVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2784e119-a365-4164-9941-7d61aa69d7e0	3DWISE	\N	3DWISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d02f0dcd-8c33-40d8-9f8d-78b989c9d405	3DX-FLASH	\N	3DX-FLASH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
941e1949-02e0-4aa9-a558-0925b6ba3d40	3D-Xist	\N	3D-Xist		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71b3c97a-8760-418f-bd58-da2a3c7b88c8	3DX-LIGHT	\N	3DX-LIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4670520d-390d-4ce8-b090-cc9346ed1566	3DZZI	\N	3DZZI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8c49f39b-9e4f-469e-b53c-f4f9085096f8	3E	\N	3E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ff56d475-16bc-4fac-bb66-718c6ced9c31	3eFERRO	\N	3eFERRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73430ab2-9b9e-4e20-94b1-d24f11b5db32	3EMOTION	\N	3EMOTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d40bb170-eaf1-4a70-9baf-16b29d74595b	3ENCULT	\N	3ENCULT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
919f6f5f-ca3f-4720-97a8-2f502e25c905	3F-FutureFreshFruit	\N	3F-FutureFreshFruit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0efaed9a-4464-409b-8cf1-726318ac9d8e	3FLEX	\N	3FLEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b2cbad4-dd96-4c8a-9473-f342379d4552	3GB-TEST	\N	3GB-TEST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22cdb3f2-6860-4354-97a9-dfe2c1704e8b	3H-ADC	\N	3H-ADC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
93e9465f-6221-43a4-8fa6-e24061fb0368	3IBS	\N	3IBS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c17e645-0a08-4d03-bb04-80ea5935e776	3-i ICT	\N	3-i ICT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2e96f5db-0501-4fec-9473-f1c8dd160a4a	3ITD	\N	3ITD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46bec9f6-a655-413f-ae62-f1f495af7c57	3L-HeCoMe	\N	3L-HeCoMe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9801e7e-79e4-4c88-9a5b-c380ef1cb520	3MC	\N	3MC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
686fe67f-d00a-4149-9a54-37a6a110dd57	3MICRON	\N	3MICRON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d3567696-c55a-4384-9576-f6cd83148e76	3PEAT	\N	3PEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9da362ee-0249-48e4-b6d2-04af30bb8fe1	3PLAST	\N	3PLAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f80949e-f208-4efc-99d3-3b2daae064be	3Ps	\N	3Ps		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c28e1d5-ba54-416e-a1d2-d6b9d3ff8452	3rd HAND	\N	3rd HAND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f2ae87ab-ff2a-43e9-bce4-96e28725c1a6	3S-BTMUC	\N	3S-BTMUC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5465e1b2-a118-4245-bea0-2ffc4e43ace7	3SMP	\N	3SMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7c9e6f27-e7db-4b39-a207-17a005a120c4	3SPIN	\N	3SPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d2b68b75-213a-487f-ad71-65c5aab1e972	3SR	\N	3SR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f189ae84-ad62-47f7-8a64-1ff40eceb392	3SST2015	\N	3SST2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b8abb7a-b375-447c-a0b5-1261634d04d0	3STARS	\N	3STARS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4028a255-f9dc-4ee2-8084-a47832b41480	3TANIUM	\N	3TANIUM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
217ee925-b012-4f96-9af5-3dec8b858ff3	3TO4	\N	3TO4		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9295b9f-add0-43dc-a56b-ec3aba9dd366	3-TOP	\N	3-TOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7003584f-2d07-4fdf-af3e-f6a75743e3b2	3TR	\N	3TR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
317bd78a-1b68-49ee-af1d-cf0d5774aafd	3VAL	\N	3VAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
021837ab-3cb4-496f-95d6-7f0d0c4b6edd	3W-RGB	\N	3W-RGB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bcb41810-31f7-4127-823e-7435180e71cf	3x3D Imaging	\N	3x3D Imaging		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1fc983a7-e346-4d11-a793-33c4ed5c9d53	40CACQED	\N	40CACQED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
66f59e0b-ce6e-4160-bd06-df8ddc727621	43CAQIP	\N	43CAQIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bfee16fc-331f-4127-ba08-4f0cb0c9b578	45HC.com	\N	45HC.com		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6c29674-4263-4acc-9c70-96ef07ec175b	4AirCRAFT	\N	4AirCRAFT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9baccb2-1762-4328-a502-f7c605d999fd	4 ALL	\N	4 ALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1b66263-98a8-4e0a-bbd5-1662932cd57e	4C	\N	4C		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e68939ff-ea16-4ff2-98ee-607ed5414b7e	4CaaST	\N	4CaaST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7ad97eac-bc5e-451a-b0c0-dd4fc51d8384	4CB	\N	4CB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e2f3ba20-ec3e-4a0d-8ef2-92f04438136b	4CH	\N	4CH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
befdb22d-cec3-4233-9cd3-7d52bc004f2f	4CWhite	\N	4CWhite		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d283c1a-c7ad-42f7-9496-d830e1599c56	4D	\N	4D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0204956d-049f-48f5-a52d-8d129ff74705	4D4F	\N	4D4F		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e384ca89-75da-4d77-8dd0-29531e71b9c0	4D4Life	\N	4D4Life		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7505d6cd-e983-420e-93e4-d4f048de54be	4D-Biogel	\N	4D-Biogel		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7916b4dc-3dbb-4677-8b86-748372962c97	4D-BIOMAP	\N	4D-BIOMAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
315b1173-28e4-4e16-a68f-3871da4cd99a	4DBIOSERS	\N	4DBIOSERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
87af8f62-29f9-43cf-b497-4005bb48710e	4D-BOUNDARIES	\N	4D-BOUNDARIES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eef84ce9-90fd-4083-8b16-0cd03269bea7	4DCELLFATE	\N	4DCELLFATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e5d46c7-426d-4813-b683-8f3dd428f555	4D-CH-WORLD	\N	4D-CH-WORLD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d9d6bcc-aed8-42ba-8746-0002613f4e59	4DCO-GC	\N	4DCO-GC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b344860-9021-487a-a820-642ff8254ee5	4D-EEG	\N	4D-EEG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1fccf24e-9146-4151-a822-8714cb2c4d92	4D-GenEx	\N	4D-GenEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
317a2f21-c4ba-457f-b349-705be940fea5	4D-GENOME	\N	4D-GENOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86e2a827-bff1-4def-ab54-d10b30b0bb61	4DGenomeReg	\N	4DGenomeReg		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8134575-e827-4d84-a271-ad45b230f6c1	4DHeart	\N	4DHeart		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2d47196e-5126-4bf2-9d3d-0bc617066ea9	4D hybrid	\N	4D hybrid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
470bf13b-b234-4268-a46a-30b36aec6251	4D IMAGING	\N	4D IMAGING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b5db16d-62b0-4096-bc29-7a489b4f2bad	4D lipid phase	\N	4D lipid phase		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2292b906-bfc7-4353-813c-523e6fe0927d	4-D nanoSCOPE	\N	4-D nanoSCOPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4aeaea8a-d343-486c-8394-647e13c92549	4D-PET	\N	4D-PET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ec01e7f4-fa83-4f26-8dac-be1e7d69ba21	4DPHOTON	\N	4DPHOTON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
487019c0-d703-42fc-b323-c34bfed3ed01	4D-PhytoHybrid	\N	4D-PhytoHybrid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58d8351a-472d-403c-84ae-d774940525de	4D PICTURE	\N	4D PICTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1717ab95-2647-4084-a1d1-ac330a934cb0	4D-POLYSENSE	\N	4D-POLYSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1ad75b9-b490-418a-a0d4-408c7d96cd7e	4DPrintedHeart	\N	4DPrintedHeart		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e5ccf328-0354-44a2-bb49-b269dd83e8c6	4D_REEF	\N	4D_REEF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8508e9de-a344-4878-a9de-5fca7aaa7662	4DRepLy	\N	4DRepLy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7f562411-892e-4495-b7af-cb6204a4b0b9	4D STENT	\N	4D STENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b879efb-d5ed-4d19-8cd2-de0f95978e31	4DVIDEO	\N	4DVIDEO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d3131d07-e7f1-416d-ac19-dee4e2835327	4F4REJUVENGLIA	\N	4F4REJUVENGLIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e5cb8f7f-8c37-4886-8a6c-8ac843b5d40b	4F CROPS	\N	4F CROPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bffbb3b3-e49b-4cac-b6a6-a22f3e422630	4f-Mag	\N	4f-Mag		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7579a62b-b12d-40e7-8a89-0add2d102039	A2F2	\N	A2F2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3f83650-7df2-4cc2-bdc6-660854658966	4FNANOMAG	\N	4FNANOMAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bed88011-faf7-42da-a3f0-a38633562b64	4FOLD	\N	4FOLD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7cb6d30a-14e0-43cc-bc8e-edec29a42983	4FOLD Phase 2	\N	4FOLD Phase 2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e94056f3-541c-4c4f-beef-fbfcb75095f1	4FUN	\N	4FUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
731f7e0e-5779-4bfe-a70c-6ee60a932380	4Gen Light Aircraft	\N	4Gen Light Aircraft		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f215ea1b-7483-41f2-b4b4-b3c572dc7ce7	4G-PHOTOCAT	\N	4G-PHOTOCAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a3b777c4-bbea-4ff0-a7fe-546ee6392c4a	4-IN THE LUNG RUN	\N	4-IN THE LUNG RUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1a0dcb37-674f-4fbf-8f52-849278e30bb2	4I-TRACTION	\N	4I-TRACTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86077abb-1d9d-4c0e-a035-82cb8c6c51bb	4lessCH4	\N	4lessCH4		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c74f31f7-eff0-4cc4-91db-03983f2e07b9	4M2020	\N	4M2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40225622-cbdd-4420-b7f1-90d10f8d56d7	4NEM	\N	4NEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0fc3c4db-bd8d-4cc3-ba83-51a6469d6b31	4-OCEANS	\N	4-OCEANS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
202b5646-42d2-4a1c-bc30-a715786a0027	4PHOTON	\N	4PHOTON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b465ddf7-c218-4982-955a-f8e9dc797aeb	4PI-SKY	\N	4PI-SKY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89b168d7-1871-4eab-afe7-a0109e7d328a	4PRIMA	\N	4PRIMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
29ceee0d-f97d-49a3-b090-f9c119f7c713	4REFINERY	\N	4REFINERY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0299790e-4953-482b-9dd3-90ddbc8cdbe8	4RinEU	\N	4RinEU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
729ba9f2-cb0e-453a-a26c-9d20b698b27f	4S	\N	4S		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0e34ccee-1305-40ce-a486-c857f321f776	4SBATT	\N	4SBATT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
357e1c31-b572-4588-aade-91c7436cfe81	4SBLOCK	\N	4SBLOCK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df08311f-d7af-4243-a1f2-1683c76c08e8	4SEAS	\N	4SEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ee6032c2-380b-43cc-b1d6-b8f96b8470ae	4SECURAIL	\N	4SECURAIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
79ddad5a-1004-4166-b8b9-0f294a92ae84	4SUNS	\N	4SUNS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ebdb24ba-e039-481f-ab70-de0a9ff7ca16	4Sure	\N	4Sure		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0dd22bd0-c5e2-43d4-b5ce-07f7511a5d0f	4TH-NU-AVENUE	\N	4TH-NU-AVENUE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ee38f2be-c697-4fc7-81ee-e79de534b0ee	4-TOPS	\N	4-TOPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b2e06a3-929e-4240-9db2-13fa2d7e8f07	4U2Night	\N	4U2Night		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ebd866a4-9233-4faf-ad25-10e4cfa2e564	4.UNCAN.eu	\N	4.UNCAN.eu		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54018e36-6c81-4693-9534-93b47646430f	4WARD	\N	4WARD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bb34a792-72aa-4564-9f1c-3d5789058227	5-Alive	\N	5-Alive		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
066beffe-59e7-429b-956c-8eda67e42c2a	5COFM	\N	5COFM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd225ef5-cc00-4f85-b4d8-353f5d808f26	5CYRQOL	\N	5CYRQOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22638318-0499-412e-a23e-aff70b2aaafc	5D-AeroSafe	\N	5D-AeroSafe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a56aa444-e412-4143-8d37-11a9f12331df	5D Heart Patch	\N	5D Heart Patch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9444c92-ec3c-474f-9bb1-a762d4e62605	5D NanoPrinting	\N	5D NanoPrinting		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6a52be50-0d40-46d5-9225-14a64af244c5	5D-NanoTrack	\N	5D-NanoTrack		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cfa93b87-59f8-403c-bbd4-b8880b6a500e	5E	\N	5E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
959762c9-b999-4762-a074-b665f979ebe6	ACM	\N	ACM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9f76337b-f5fc-47f5-9f76-274fc0b2e51b	5-FU PGX	\N	5-FU PGX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bac87271-0102-499e-99b0-84c512acc070	5GaaS	\N	5GaaS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3ea70f72-b56a-4dcc-884a-af84ba472233	5G-ACE	\N	5G-ACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f12d6f33-9f60-427e-b61e-54b3c44eabb0	5G-ALLSTAR	\N	5G-ALLSTAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73daee59-7ff7-4e61-b7a4-5dd01b5dad02	5GASP	\N	5GASP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c56599da-d7d3-4633-945e-53a4b35f2187	5G-AURA	\N	5G-AURA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1f9010e4-eabd-4397-aa2f-0a90a8807a96	5G-Blueprint	\N	5G-Blueprint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df4f44b6-89fe-4976-8e42-f6e1a432304e	5GCAR	\N	5GCAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8ef1a6e4-cd97-4975-8295-36a0fc95ba31	5G-CARMEN	\N	5G-CARMEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34a40eb6-1e4a-4cad-8c98-322b089ac22a	5G CHAMPION	\N	5G CHAMPION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a32c79bd-0c54-483a-b661-1e31886ca25f	5GCITY	\N	5GCITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fafe373a-db2d-4ef4-aab0-886bcf0fe839	5G-CLARITY	\N	5G-CLARITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
960c8967-184d-4e5d-996b-66563a7ac50c	5G-COMPLETE	\N	5G-COMPLETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0451d800-0579-48c8-a3a8-0d1e09c82689	5G CONNI	\N	5G CONNI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ea756cf4-e3a6-459a-b11b-097cd034ac39	5G-CORAL	\N	5G-CORAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
19df1ca7-de4f-41f8-a81d-05c44c98ccd6	5GCroCo	\N	5GCroCo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
359ca69f-e172-4d3a-8602-6499d7cf6132	5G-Crosshaul	\N	5G-Crosshaul		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2a70a081-2e5c-4228-9ec0-dcc7bbc36cdb	5G-DIVE	\N	5G-DIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce36ef8a-4658-42b8-b98e-8f8256516270	5G-DRIVE	\N	5G-DRIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ea133258-6fee-4e97-b6eb-7a3b07a7fe08	5G!Drones	\N	5G!Drones		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ba8c84fb-94a4-417b-bfb9-866c651e2816	5GENESIS	\N	5GENESIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb954ae7-ee97-42d6-8131-ca7fea00c2ed	5G-Enhance	\N	5G-Enhance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ad7b9b73-c815-4b41-9d3c-396c97f2bd30	5G-ENSURE	\N	5G-ENSURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c69c949-4686-4d98-8a0c-d916391822d9	5G-EPICENTRE	\N	5G-EPICENTRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f329cbbc-f1c9-40ff-9676-b383cd23509c	5G-ERA	\N	5G-ERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc9edf3c-c0e1-47cb-b627-41c9018434be	5G ESSENCE	\N	5G ESSENCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3028c9d-b234-4251-9a93-6c22463d19f3	5G EVE	\N	5G EVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68dac146-a678-4546-a0f9-77b6783aa8a3	5GEx	\N	5GEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0c6546d-41db-4b79-b8bd-a93c3fc37756	5G_GaN2	\N	5G_GaN2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
605ac924-9087-4e38-bf18-682489099fc6	5G-HEART	\N	5G-HEART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
605690ea-727f-4198-b6ab-a55454daaf3f	5GhOSTS	\N	5GhOSTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6819103d-c212-4209-87b8-e9124b25d4ff	5G-IANA	\N	5G-IANA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b93d3ed-c95a-492e-9aed-803201938cf8	5G-INDUCE	\N	5G-INDUCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d5eee19-763e-40f2-b06a-0fbe665b256a	5GINFIRE	\N	5GINFIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e9ec2b3-25df-4371-8148-a883744cdb8c	5G-LOGINNOV	\N	5G-LOGINNOV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5b743857-9d61-4cc6-bf50-1f0ded40add3	5GMED	\N	5GMED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f53e17e-1fcd-42df-8088-07e96c68fb1d	5G-MEDIA	\N	5G-MEDIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
36f67e04-077e-49b4-9c42-cb4e4ebd9a08	5GMediaHUB	\N	5GMediaHUB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
238e52c1-c5ec-44a1-9ee4-0edd5a2cc5a6	5GMETA	\N	5GMETA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f5a697cd-2fe8-4b6f-89b2-bea46d2dd953	5G MiEdge	\N	5G MiEdge		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f941fffe-e7a3-4295-a4cd-53a2f608584b	5G-MOBIX	\N	5G-MOBIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ff02d97-1113-4f1b-b993-7f6f17d30979	5G-MoNArch	\N	5G-MoNArch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e5438a5-708e-43e2-a195-208a4cc6bc10	5G NORMA	\N	5G NORMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4510cffb-ac24-4165-9725-2d406888c105	5GNOW	\N	5GNOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d7f4fe5-9476-4f91-af9a-e740df023542	5GPagoda	\N	5GPagoda		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
163a921b-3ca5-4d80-b3e9-529d44f80c0c	5G-PHOS	\N	5G-PHOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73ca0506-63ba-47e4-8b03-ac676a1e06db	5G-PICTURE	\N	5G-PICTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
14133297-cb35-4a3f-af2d-73b0f0d3a7ca	5GRAIL	\N	5GRAIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
37740fb3-719a-412a-b068-8417fe30e6cd	5GRANGE	\N	5GRANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
007b7308-0736-4e25-bd0c-0d9982578b8f	5G-RECORDS	\N	5G-RECORDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6510018c-17e6-4733-ac3b-e680613bd46f	5G-ROUTES	\N	5G-ROUTES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71f86c0b-077a-471b-b6fe-18638548e67d	5GROWTH	\N	5GROWTH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
699719fc-6fd5-411a-a975-9dc943326f75	5G-SMART	\N	5G-SMART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
734f6a31-947e-4e92-a068-ea6ed8a32152	5GSmartFact	\N	5GSmartFact		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d957a29b-8b48-4782-bdca-ff5833ff4d3e	5GSOLAR	\N	5GSOLAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d534614d-9e4a-4ec4-b8e1-194e02906c61	5G-SOLUTIONS	\N	5G-SOLUTIONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6948a9d1-433c-42fc-ae04-90c0b7105700	5G STEP FWD	\N	5G STEP FWD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
69bbc179-4900-431d-8dfd-dc3edb52da69	5GTANGO	\N	5GTANGO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b499af91-d1b0-4f1c-961b-e55f8ec15c76	5G-TIMBER	\N	5G-TIMBER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6ef698e-ccfc-4e05-b7f2-9defed2b577c	5G-TOURS	\N	5G-TOURS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71c68dd2-1e71-4f41-991f-38ef7b8c92ab	5GTRACK	\N	5GTRACK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
de41df43-d653-48cd-b73a-274f2418d8b4	5G-TRAIN	\N	5G-TRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bea03ae0-8334-4366-9d59-25b52d89c078	5G-TRANSFORMER	\N	5G-TRANSFORMER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c07ef293-8492-4d11-a2b4-461fb2a59669	5G-VICTORI	\N	5G-VICTORI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73ab8a51-413d-4be4-a69e-8c7d5060c88a	5G-VINNI	\N	5G-VINNI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c19bd94-b60b-4f5f-92f3-1a276a5430a5	5G Wireless	\N	5G Wireless		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
337f5160-d9b6-4d16-9892-f3b68bd44357	5G-Xcast	\N	5G-Xcast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9896243-8cc5-431a-ac2e-26b8daf1343c	5G-XHaul	\N	5G-XHaul		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5c0de633-f043-4ac4-9b09-955948247fe1	5GZORRO	\N	5GZORRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
be787df5-8aad-45b2-982c-09e5fab192f7	5HTCircuits	\N	5HTCircuits		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a809d221-a988-4eed-a1b1-45a97e431a1c	5HT-DREADD	\N	5HT-DREADD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d3fbb04-7024-4858-b0f1-e379085805c7	5HT-OPTOGENETICS	\N	5HT-OPTOGENETICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55d0dfb5-2541-4534-b8ac-df4893abfd8f	5-HT Radiotracers	\N	5-HT Radiotracers		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e1049b3-de58-4f75-864a-15f674f2b69c	5 LIVES	\N	5 LIVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b2edc2d0-2caf-4984-8fd5-9010103bf780	5TOI_4EWAS	\N	5TOI_4EWAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77974bc6-24ee-4513-a91d-250feef92136	6CHOICE	\N	6CHOICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e23a7d82-9629-4963-b857-d2ae658f34d8	6DEPLOY	\N	6DEPLOY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e4b7afed-e968-4538-a8fa-af97bb755e10	6DEPLOY-2	\N	6DEPLOY-2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73f47d18-1bc3-4fdf-82da-369a93c87a9c	6D STRINGS	\N	6D STRINGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d3982228-ede7-40c3-96b6-6a216adde05d	6G BRAINS	\N	6G BRAINS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7f9db53-8312-4de2-9fe9-5a697f190f61	6G Channel Coding	\N	6G Channel Coding		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2a2bd8e8-1e7c-4a36-a189-9a893052e9ce	6GStart	\N	6GStart		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c48f9f66-2521-41bf-9f98-8a77039e3a5c	6i-DIRS	\N	6i-DIRS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51d3373c-412f-46f3-ad0d-1893aa6ff042	6-SENSE	\N	6-SENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
db7dcb6c-8ae4-4ce2-9d21-f8fa52251795	720IEQ	\N	720IEQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
723244c2-a15c-47d0-bafa-4e54266c8b3f	79GHz	\N	79GHz		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
919d7929-e5db-415d-bdf0-7554fa0c7357	7MW-WEC-BY-11	\N	7MW-WEC-BY-11		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0fa521e6-bb50-4e88-8b1c-b0fd5dde0b75	7SHIELD	\N	7SHIELD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e2122eea-c825-4d29-bc31-c0c7a7ffb82c	7TReImHo	\N	7TReImHo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b6f7a42-236d-4c3c-9d1f-4bf2de24fb05	80Days	\N	80Days		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9d149279-1045-4ee8-8883-4c5a7e31b139	9eGEN	\N	9eGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6088770-697c-4289-bc62-c3c1c3ac8bbf	9 SALT	\N	9 SALT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1a085883-e848-44e8-9016-a5dc69c87235	A20APOPTOSIS	\N	A20APOPTOSIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86fecba1-b858-4625-9439-9dcbb2fe0bce	A20 DC SUBSETS	\N	A20 DC SUBSETS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9d69c7d4-4644-48d6-960e-3406f8b344ef	A20 IN ALLERGY	\N	A20 IN ALLERGY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0330788a-8df5-4ec3-8fdd-687e28ea189f	A2CM	\N	A2CM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
65e6b1bf-c914-4770-96bd-7defc932ea9c	A2F Conference	\N	A2F Conference		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b600ea11-087c-49d8-8edc-2c4439cc25a2	A2M2TECH	\N	A2M2TECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d18bb121-f01a-4267-b34f-a1672136afc0	A2Miro	\N	A2Miro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
196b38a9-9f52-4036-83e7-c2e9dd3f59a7	A2MIRO	\N	A2MIRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e5378ac-d8d0-4ef1-824b-1c2bed4bcfef	A2MStools	\N	A2MStools		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68747933-bf93-464a-8ba6-1e3ae7868f22	A2-NET-TEAM	\N	A2-NET-TEAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
308ee276-ef11-4d6d-81e2-ccdfb14cd9c5	A2PBEER	\N	A2PBEER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fec16a25-ffaa-4040-970b-5b42324ef65e	A3	\N	A3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0ac740c4-da5e-4bde-80af-e33cf2331501	A3BL	\N	A3BL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
30d8b23a-e922-4060-a72f-f9d27e559d55	A3R	\N	A3R		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ad72e5dc-ca2a-4b60-9e6c-b89709cefcb2	A4A	\N	A4A		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b01dddb-6b7c-41d2-ab2d-0800d29e0f26	A4B	\N	A4B		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5471f756-39b6-47a1-8209-5a4e8544073d	A4BLUE	\N	A4BLUE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3739678e-5e5f-4008-922e-5fc8dc1e304b	A4CLOUD	\N	A4CLOUD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40a6bf47-ee1d-469d-ae82-e49a392873bf	A4L_ACTIONS	\N	A4L_ACTIONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98e85efd-9551-4cdf-b6e9-bc713551775e	AA	\N	AA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7901cee5-8673-49ad-83c5-b8c8053e35c0	AAA	\N	AAA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8e28f4e6-6c85-4f9c-b8dd-8b9925e10023	AAA+LON	\N	AAA+LON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32773316-1926-471b-8dd3-8cc5ea426824	AAA-PREVENT	\N	AAA-PREVENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a598eb98-a0f0-4fe4-bd4b-8ea5c8c8502e	AAASP	\N	AAASP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
550982ce-87cf-40b1-97ef-d5f649d0bc2a	AAATSI	\N	AAATSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
538ebec0-18fa-4a96-a1c0-661ab9132555	AAC	\N	AAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54110bc1-830b-4e57-bf98-a12c2acb9ca2	AACCT	\N	AACCT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
981ef749-55ed-4f03-aabd-5bd2a69e14ad	AaDAMS	\N	AaDAMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
62f95bec-74b5-416a-9dfb-a23a966957ca	AAL2	\N	AAL2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6529c803-a8b8-4876-aa13-36944275ffc9	AALIANCE	\N	AALIANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
791f675d-a35b-4c4d-9a4f-3ae1e9d835b5	AALIANCE2	\N	AALIANCE2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c3d0d71d-d0a8-4a63-b1ba-9a4da7f6f7cb	AAMDDR	\N	AAMDDR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
63b6b70c-5092-49d6-9d82-519c4262f847	AAMOT	\N	AAMOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
23051161-6b77-4809-b636-4180bc3961b0	AANChOR	\N	AANChOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c01d6d53-eb0a-4240-b7c6-e33a53d0b2ea	AAPD	\N	AAPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf992b81-2f51-4aef-8812-bf68079b7369	AAPLQIC	\N	AAPLQIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
057b7bb9-ef2d-4325-953d-113218b02496	AARC	\N	AARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6e34aba9-b6b3-4155-9d7f-2be354f4c3dc	AARC2	\N	AARC2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
922b5eff-a465-46c9-96e0-4f3602b2444a	AAREA	\N	AAREA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
adb657bb-c99e-4072-ab24-4a4e6a97d5cf	AARN	\N	AARN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb9ae8fd-a39b-4e1e-a406-d04c037128b4	AArteMIS	\N	AArteMIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6b6221c-6ecf-4d53-9c7b-fd42cb91c8c4	ABEP	\N	ABEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bdf804ff-3124-436e-84e5-1ed3ace5d6d5	AARTFAAC	\N	AARTFAAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12a1feeb-d3d7-490b-95dd-6a20c29a3b6e	AAS	\N	AAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ed20e1a0-727b-4aee-9690-20bdbb5ab1dc	AAT	\N	AAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
afb3c08b-a7a1-4a76-aef0-339077c44ade	AAT-NAA	\N	AAT-NAA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd3bc3b3-a466-4b08-8ef1-4443c001a2b1	AAVEYE	\N	AAVEYE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e48f1095-53b2-40e8-bc5e-769553acc813	AAV-FACTORY	\N	AAV-FACTORY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
20c4de86-0268-476c-a919-7f28da0ecc7e	AB4Rail	\N	AB4Rail		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c4cd217-9e72-4a7a-b626-aa0b5e1cdd82	ABACCR	\N	ABACCR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c40b2cd9-bc98-4d80-8bdb-520f1cd09c11	ABACUS	\N	ABACUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f0d57153-6091-436e-a222-15f687e7d2df	ABAG	\N	ABAG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f6e6b06-4952-4e83-9018-17d0188e8768	ABA-GrowthBalance	\N	ABA-GrowthBalance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46abafd7-e584-4736-ac83-e95d67ee28af	A-BAM	\N	A-BAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0788c93-155c-4842-b74e-417960918acb	ABANDONMENT	\N	ABANDONMENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c5addd07-1832-42b1-8fd1-aba82e00351f	ABASynth	\N	ABASynth		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8c7ccf43-d593-44d9-953c-1b95db7034be	ABATSYNAPSE	\N	ABATSYNAPSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
61ca4b70-d7b7-4f5e-b0d3-228d9a8422af	ABBI	\N	ABBI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e062a289-58a0-4bc3-9b38-22abafe5ed8e	ABC	\N	ABC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6beecdaa-d0bc-4f78-b6aa-0c1e6440c3d4	ABC 21	\N	ABC 21		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6b465f3-44a5-40c4-b875-d7204b33ce7a	ABC4EU	\N	ABC4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
903fb547-a6d5-498d-bc2b-470c5a868a85	ABC4Trust	\N	ABC4Trust		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b850bccb-ee7d-4916-bda2-36c297eef72c	ABCDE	\N	ABCDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35e403ea-8e59-417c-ab4a-1746703bea86	A-B-C-Deep	\N	A-B-C-Deep		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c603f41-3c6a-4b0e-bf7e-250412dc7704	abcdeSIM-VR	\N	abcdeSIM-VR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9d8835e-e70e-4abd-972c-ea645bd1a18a	ABC DJ	\N	ABC DJ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d4cbcf1-5d0a-46b1-a7a1-b78679953097	ABC-EU-XVA	\N	ABC-EU-XVA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54c4a741-cda5-443b-84d5-99a012509b46	ABCIT	\N	ABCIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
efe82813-33e2-4d63-9842-0510b7887353	ABC-S	\N	ABC-S		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47a48ad5-4172-4053-9ac4-1996505905f4	ABC-SALT	\N	ABC-SALT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
19936437-1660-48fa-b1cf-69c892935f83	ABCTRANSPORT	\N	ABCTRANSPORT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b900f5e9-2aad-4a78-9bdc-8a3e21862db8	ABC TRANSPORTER	\N	ABC TRANSPORTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4cdae4db-f0f9-434a-972c-8d163e760873	AbCURE_COPD	\N	AbCURE_COPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
654f19a7-a17c-46a8-be96-fd528dfcd47b	ABCvolume	\N	ABCvolume		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f767285a-4fdb-4975-b474-7b6d067926b3	ABD	\N	ABD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
267e8fa2-6720-4b75-a55d-c62f603e390f	ABDES	\N	ABDES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc1ad09c-9c90-4892-878e-687661c5c1fd	ABDESIGN	\N	ABDESIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e2573fc3-fa2a-4c21-9a48-1d388af188b7	AB-DiRecT	\N	AB-DiRecT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5db201de-2787-4540-b5fd-264ca9867092	ABEL	\N	ABEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
16e3b0fb-b70b-4b31-b566-96592502d6a2	AB ENGINE	\N	AB ENGINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6e930b45-933e-4338-a69f-fa1213bda85e	ABESTII	\N	ABESTII		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
28f18a2b-1bc3-4554-a381-bc80b0677348	ABEST III	\N	ABEST III		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f97e00cf-5631-48f4-8088-1b92aa2ff0d5	ABETAALPHASYNTAU	\N	ABETAALPHASYNTAU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
44c760b1-e987-438a-940f-6d99e945dcd6	ABETACOGNITION	\N	ABETACOGNITION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51314407-a15f-4745-a602-f89b4e5051f0	ABETAPRESYNASTRO	\N	ABETAPRESYNASTRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ce8fe59-439a-44d5-998e-315732713aae	ABFT SNP	\N	ABFT SNP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce423bc8-fb8a-41b6-b1cf-5f19749b3e34	ABIADA	\N	ABIADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51a36551-ede1-4117-9e5e-1a4ceb98d7df	ABI Energy	\N	ABI Energy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fc8c3c46-3b17-4375-9c16-57328636f74c	A-BINGOS	\N	A-BINGOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8cd4474c-7c5a-4e70-82da-ac1d096adc1a	AB INITIO	\N	AB INITIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
652c5b08-1dde-4a84-954e-3431de5336c4	ab initio and QMC	\N	ab initio and QMC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fe2310ae-3c5d-4de0-9377-9782ffdd9276	ABINITIODGA	\N	ABINITIODGA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6bbc31e-0b3a-446a-8f97-102274a1cc2b	ABIO	\N	ABIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d511d8e7-300d-4f07-8dfb-4eb7dc9cc30b	AbioEvo	\N	AbioEvo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a94a998-fd92-449d-a018-752242c901ea	ABIOMATER	\N	ABIOMATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b9e4d5d-d96f-4cee-85ac-9c6a022bb67f	ABIONYS	\N	ABIONYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73d654e9-3e5a-42bd-8db9-9c6e9f2a7dbf	ABIOPES	\N	ABIOPES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4247cdcd-7e0f-4e45-81fd-bcd7ffd3a27f	ABIOS	\N	ABIOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40fe46f3-4465-4b7d-a66c-1adadcbdd3dd	ABIRISK	\N	ABIRISK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5476e1b5-8274-4d40-abd9-ebe563ac69f3	ABISSE	\N	ABISSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5963b270-fba0-4bec-be02-8e8b51c7b726	ABJM	\N	ABJM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d5e378c4-cb12-4dbc-a4ff-4879dd68fa3f	ABLADE	\N	ABLADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
27711491-5765-49e7-bf63-c61ff967b63b	ABLAMOD	\N	ABLAMOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd895db0-34d3-45d9-b884-ff540a606ebb	ABLASE	\N	ABLASE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0f40c4e-9914-4699-b946-70dfca4a7fb0	ABLAVIEW	\N	ABLAVIEW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
092a2f8a-5add-4e8d-b32b-18c71d4a1e6d	ABLE	\N	ABLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b0eaa5c-d66e-4993-8d87-1116c1603879	AbleGames	\N	AbleGames		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6cbf460-7180-498f-a611-bb9413314c1a	ABODYFORCE	\N	ABODYFORCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b271e7cc-dc33-42a6-b552-0ba5f03ee42d	ABOLED	\N	ABOLED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
755727f5-b1aa-476e-9426-b25bce0e5898	ABOPEN	\N	ABOPEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d5ced327-1ef6-45f9-a0d2-0516fff1767a	AboutFlow	\N	AboutFlow		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a2191097-8787-4e9a-8abc-7d1ff8a9d303	ABPP-PROTDRUG	\N	ABPP-PROTDRUG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f73c3da5-b744-4be3-b8ac-36ac081e3a3b	AB-Prevention	\N	AB-Prevention		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7c91c8f0-96de-4793-a750-c9448fa6c2ab	AbQuantumSpec	\N	AbQuantumSpec		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
084ffd99-dcf7-44b4-950e-6bce6a83a2c4	ABRACADABRA	\N	ABRACADABRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7dceb76-7cd1-4f35-ba4b-bba22b0e3389	ABRAM	\N	ABRAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b71d426-7176-46d1-956f-a9dbd6107eac	ABREM	\N	ABREM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
30229020-1e3c-4704-8cec-69f907b069f9	ABRIM	\N	ABRIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5b469721-3521-426f-bb96-158298133c32	ABRSEIST	\N	ABRSEIST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d89b5f13-71bc-49d7-bf0c-b945ba9bdb4d	ABrucioli	\N	ABrucioli		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
043bcbab-3a9b-4d36-8619-92abd2c8ad36	ABRUPT	\N	ABRUPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05114acd-cb9a-4ade-b850-846c3fbf8207	ABSENS	\N	ABSENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81b0c160-4494-43d6-bbe9-cc033a4b5c93	Absent Presences	\N	Absent Presences		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00381f04-91fd-44df-9f35-fb1aebb666a0	ABSHA	\N	ABSHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d0f03d7-8699-4450-ab94-fcacc206fbaf	ABSolEU	\N	ABSolEU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d8f77a2b-c6da-411b-a7be-ead646938c25	ABSOLUTE	\N	ABSOLUTE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68bf4758-bfb6-4743-b25c-e6721b2f7ca4	ABSOLUTESPIN	\N	ABSOLUTESPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e7f8ad59-7698-457f-a0c1-d4fa3be45d99	ABSOLUTISM	\N	ABSOLUTISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a83d083-255a-490a-9339-958d623e3748	ABSORBNET	\N	ABSORBNET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6f0d27d-ebca-4bd3-ba30-7cdd4b163dbb	ABSREF	\N	ABSREF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
28753a8e-e67e-435c-a308-d6bd36b7dc8d	ABSTRACTION	\N	ABSTRACTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d488364c-032c-4f81-9701-d2482080927c	ABSTRESS	\N	ABSTRESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9fac1bba-b392-40d9-b8ef-cac34c0d02cb	AB-SWITCH	\N	AB-SWITCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb0afb8a-9b66-41dc-9ebc-09650aa4865c	AbsZero	\N	AbsZero		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
39e3f192-1c28-4eb9-a7dc-34d6a0d21db5	ABT	\N	ABT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b6a3da81-539c-402a-ba5d-33cf5f4da0cd	ABU-MATRAN	\N	ABU-MATRAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e5535b97-67e4-4cc3-acf9-502d99e3f749	ABV	\N	ABV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f94398ca-b6de-459f-b46c-23b2958ab17a	ABWET	\N	ABWET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c05134c0-4af5-4117-a124-2797936edcbe	ABwipe	\N	ABwipe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2f90d4a9-6e12-47b1-a074-97fddf966bdc	ABYSS	\N	ABYSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
304281c8-1960-4cac-b156-218d6729b522	ACACIA	\N	ACACIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3a2e61a4-bcde-4625-baa2-e4228633c79e	A CACTUS	\N	A CACTUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ceeb56d-2016-4072-9b3b-0daeff9c0dcf	ACAD	\N	ACAD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
85fbaef5-75e9-4866-8466-8f26165d5e1e	ACADEMIA	\N	ACADEMIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
87acc1f6-c0c4-4b19-9657-f6b53fe420a9	ACADEMIC GMP	\N	ACADEMIC GMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d004bd5-cec6-429f-b933-59f5e29542a0	AcadHist	\N	AcadHist		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2dbf5b26-d8df-44d8-b6f7-fce3dbb5a32a	ACADIS	\N	ACADIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
debcda8f-7506-48c6-b0e0-ef98edf4e2a4	ACANTO	\N	ACANTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a5b5d5f-32ea-481f-80e8-46227af17928	ACAP	\N	ACAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8bdafdf7-ef29-4f0c-b5fe-411713318595	ACAPOLY	\N	ACAPOLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a66200c7-8be2-4bd4-bf3f-6f50a97873a7	ACAR	\N	ACAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7ab0b1d2-ca88-4a8a-921c-debe41499d0d	ACASIAS	\N	ACASIAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
895f9e8a-1cd9-4aa0-b986-4b0e10c5313a	ACAT	\N	ACAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
989e9cd3-a7a7-4365-8335-711a3d73d436	ACB	\N	ACB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82f5b14e-1243-46be-94e9-114702094bcf	AC BREAKS THE SPHERE	\N	AC BREAKS THE SPHERE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f3a7d4a9-f950-43cf-90a2-8b819f622e78	ACC-3D	\N	ACC-3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c2985736-841c-434c-8989-5ff5fb29b679	ACCA	\N	ACCA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a4318ba5-6a92-44a7-834b-2e718ac5660d	ACCARC	\N	ACCARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
88c0f6b3-2e86-419f-a733-186248fb2caf	ACCDECMEM	\N	ACCDECMEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
57eff1fc-2179-4a15-965b-625efb008051	AccelCMR	\N	AccelCMR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81769e0e-a953-46f3-b759-49396714615a	ACCELERATE	\N	ACCELERATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c8aacaa-8028-4aa6-86fc-1ca3169f1ba5	ACCELERATES	\N	ACCELERATES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d7e151af-0056-44b5-aeef-9d401005f00a	Accelerate SUNShINE	\N	Accelerate SUNShINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b7c73fd-ed59-435a-82b0-498be4367999	Accellta	\N	Accellta		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
480cf31d-75f2-4c47-bf86-7cf5544c91b0	AccelOnChip	\N	AccelOnChip		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
354836ce-e7fa-4973-91a3-eda745851030	AccelWater	\N	AccelWater		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6d075d81-f9a8-4511-a668-5766e26bf459	ACCENT	\N	ACCENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1a7d5688-434d-4525-bb68-24c3db97916a	ACCENTO	\N	ACCENTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9981571-1758-4d1c-b0d4-1a6db419fe64	ACCENT-PLUS	\N	ACCENT-PLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e650c00e-f5bc-470a-ac22-b86c34626de5	ACCEPT	\N	ACCEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90e1b6b3-e893-4b12-acd1-0c509e859f9c	ACCEPTA	\N	ACCEPTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
186797c2-2c19-4605-8586-aea0929b7761	ACCEPT PLURALISM	\N	ACCEPT PLURALISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
162b60ff-030d-4273-bbb9-722014792a0f	ACCESS	\N	ACCESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d241aa3e-9fd4-444c-b5ce-aabaf0c0da9a	ACCESS 2 ALL	\N	ACCESS 2 ALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1618d014-4a73-438f-931f-f83c88c8af6d	ACCESS2CANADA	\N	ACCESS2CANADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
821a94ee-af08-41b4-a43d-78a3639ca778	Access2EIC	\N	Access2EIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9c9890cb-2e39-435a-9d47-ede574ab7b46	ACCESS2EIC	\N	ACCESS2EIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2f6a4e5f-9f91-4759-a9e6-0b21a3700f03	Access2Europe	\N	Access2Europe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc96b5d8-c231-4d6f-b610-3a3ca7b09688	ACCESS2MEXCYT	\N	ACCESS2MEXCYT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b156a5c3-e079-449f-8c90-49d827750c30	ACCESS2WM	\N	ACCESS2WM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a95f4680-bf55-4bb6-9b46-e06fdb53b053	ACCESS4EU:NZ	\N	ACCESS4EU:NZ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b34c401-889b-4064-897c-d32d4a7403f9	ACCESS4SMES	\N	ACCESS4SMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
992de7c3-a79c-46d5-91c2-222d1018ae00	ACCESSIBLE	\N	ACCESSIBLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9f62ae5-ee92-4ce6-8407-e849109d7a31	ACCESS-ICT	\N	ACCESS-ICT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04faea3a-5960-45dc-a628-b1d1dfe879f5	AccesSME	\N	AccesSME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34369a22-eac4-4cba-a450-d905d8e07af9	ACCESSRU	\N	ACCESSRU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e0b13f9e-91ca-4287-b99f-6f756fc5e546	AccessVote	\N	AccessVote		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cf51ec46-42bc-4f31-b436-b5729342e0d0	ACC_EXT	\N	ACC_EXT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
99b8f666-4ee1-4eaa-9174-00f91a02e6ed	ACCLAIM	\N	ACCLAIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c7583aea-f23a-492c-9250-1804ac6866ee	ACCLIM	\N	ACCLIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
28422d52-faa6-47b7-8e75-149d340e542d	ACCLIMATE	\N	ACCLIMATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bb190c3f-ebd7-42be-8a42-bd714939a86c	Acclimatize	\N	Acclimatize		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4409f654-f3f0-439c-b3f3-cd4618e486ef	ACCLIPHOT	\N	ACCLIPHOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e34cc6a8-bc1e-4f1b-b05f-aa473ef1a8a7	ACCMET	\N	ACCMET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b835059b-2a3c-4234-a1a6-740ef46bd0db	ACCOMIM	\N	ACCOMIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a58b21ca-f0e1-40b1-9b6c-d02938b01b10	ACCOMPANY	\N	ACCOMPANY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3c312951-3245-4344-b9f0-6bf957cb8e8c	ACCOMPLI	\N	ACCOMPLI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8caf9c88-ac77-451c-ba92-0a6a431941d6	ACCOMPLISSH	\N	ACCOMPLISSH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fcb4f7e9-5dab-495b-bf7f-f28a7eefa1d5	ACCOPT	\N	ACCOPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
315e625b-37b9-4f65-bc4c-eb17a898c362	ACCORD	\N	ACCORD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
edd36882-63f4-4761-9b30-a2db9c6935ad	ACCORDANCE	\N	ACCORDANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
da3376ac-6d51-46fd-94f9-ff5bcfe60ae6	ACCORDION	\N	ACCORDION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a379c031-a451-445e-8463-ca4dfa73c512	Accordion Bioreactor	\N	Accordion Bioreactor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f331755b-fcdd-4544-8dd7-b5043074130a	ACCRA	\N	ACCRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c87fdbe3-23da-4608-96d1-cd9b70060a39	ACCRETE	\N	ACCRETE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b3f8e69-cad9-4973-a6b6-807c6e6bea1a	ACCRETION/EJECTION	\N	ACCRETION/EJECTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ad08d1f1-5a20-48e1-aae6-803d0f118e16	Accretion states	\N	Accretion states		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9ea035d-f9ef-4067-8189-99f2b0231f80	ACCSESS	\N	ACCSESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fc5e36cf-5c63-44fd-8bb9-1f0369781f75	ACCTING	\N	ACCTING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
63cfc6cf-0338-412c-ae9d-537d02016713	ACcTIOM	\N	ACcTIOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
11a9d200-4601-4d2b-97e5-41a26c8b8aa2	ACCUBLADE	\N	ACCUBLADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
710f312e-058c-4bf8-8245-a4e301d42b9c	AccuCT	\N	AccuCT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
343cd2ca-b138-4477-843f-f0b382e9a3a5	ACCULTURATION	\N	ACCULTURATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fa603880-a8ac-44e5-b5c7-9c203f40bba6	ACCUPOL	\N	ACCUPOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
15ced2f0-f605-46b1-84cc-861b6c815f7a	ACCURAT	\N	ACCURAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ece0dff-7e3a-4900-9566-f48c44cadb33	ACCURATE	\N	ACCURATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f3c1919-9e32-4354-9126-c9484d12d014	ACCUS	\N	ACCUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4fb33fb5-6f84-49de-b101-07d8115bfb2b	ACCUSIM	\N	ACCUSIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12d5f4f0-ca17-48ce-b6f9-088f6747695e	AccuWater	\N	AccuWater		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
deb374d9-db82-492f-b3de-ed6f05b874a6	ACCWA	\N	ACCWA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
079f29a3-b5f4-4b72-a335-e14c6d0a8432	ACDC	\N	ACDC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
75604dc9-85eb-450c-a339-98b88a22f622	ACE	\N	ACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
74d739fd-c889-4b42-8184-5ae293daf598	ACE Creative	\N	ACE Creative		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
20ac3eb9-2fa7-4f9c-887f-451ba7119bca	AceForm4.0	\N	AceForm4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9841b69-cba1-465d-a55e-6dc8633ba382	ACE_GFAT	\N	ACE_GFAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c13c697-1c6a-4e70-924e-aa4922f975c9	ACElab	\N	ACElab		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b28c8e9-aeb4-4ab5-99fe-c70d83766f44	AceLSAA	\N	AceLSAA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f26a90ab-1096-4bd0-8fb4-99839a77b391	ACEM RAIL	\N	ACEM RAIL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
53bd1f99-e053-4840-9544-b9620cc21e42	ACEnano	\N	ACEnano		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cf3c4d19-3a01-4b91-a0ed-67734487cf61	ACENTSPINTUB	\N	ACENTSPINTUB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
69d083c3-3bf6-46a3-80fd-49d0e4cb8cfa	ACE-OF-SPACE	\N	ACE-OF-SPACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f686b50-7aae-4966-806f-f144f0a940e1	ACEOLE	\N	ACEOLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9640e347-6c83-48a9-a19d-a672d8f5c9d2	ACEP	\N	ACEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d72f9187-c3d3-484c-8fa0-052acffea4c3	ACEPOL	\N	ACEPOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
25feb528-88ca-4502-801f-4289147acd3d	ACES	\N	ACES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
386bcd20-6443-499a-be86-24139b607ddd	ACETOGENS	\N	ACETOGENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cead17b5-edd4-4c0d-bf2d-450917fefbf2	ACETO-SAGATAC-HUMAN	\N	ACETO-SAGATAC-HUMAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
edf996a5-86d8-4779-9f6e-6e270b6bc3f6	AcetyLys	\N	AcetyLys		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b24ecee1-12d5-4b67-86db-80b1c27995c0	ACFA 2020	\N	ACFA 2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c78f35e-e33b-4694-9742-f55379377901	ACFD	\N	ACFD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f51e846a-bc3f-444d-9ccc-5d640c95729a	ACfoil	\N	ACfoil		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
433c8f2e-0b9b-4485-953e-3fd7fa74c55f	AC for PKU treatment	\N	AC for PKU treatment		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1856fad6-ad6f-40b4-92d9-540a9b0ef59d	ACHEON	\N	ACHEON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d08c4a7e-f574-472c-a48d-66f175bd8b1d	ACHIEF	\N	ACHIEF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d0a6a97d-3a60-48ce-a38d-411ab03d0589	ACHIEVE	\N	ACHIEVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0175b2ed-590e-4cac-bc1f-6db948159cf0	ACHILES	\N	ACHILES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d1f2151-2373-4df8-bfb0-5547dfec7fad	Achilles	\N	Achilles		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90a4a6ee-c665-4e64-9ac6-7124c32cf95b	ACHILLES-HEEL	\N	ACHILLES-HEEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92d6892e-cd85-48fd-870e-6c9962b13a74	ACHILLEUS	\N	ACHILLEUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d40e57e1-3341-40e1-910b-be8a5f56035f	ACHROMAS	\N	ACHROMAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
31a8f4ea-cbd6-4408-a8e2-e9619bcd804b	AChSo	\N	AChSo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
289966ca-7ad3-4a12-a6cb-3d8d8cfd0e56	ACI-AMS	\N	ACI-AMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
03fd0e6d-7f92-4aac-b3cb-d85ef4116e43	ACID	\N	ACID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
94450007-be0a-4595-a10c-b2805deb193b	ACIDIBACLIGHT	\N	ACIDIBACLIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6fbdc8a7-6b19-48cb-8a7d-b3975d84b0b4	AcidICC	\N	AcidICC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
baba8cf6-0899-4bca-b3b3-1b9b905c9df8	ACID-MARS	\N	ACID-MARS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5983edd5-b7e7-40f3-b0d0-e863aeb392bf	ACIGDSLE	\N	ACIGDSLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9e2ef714-e11b-44f1-b074-a7687d9adba8	ACIN	\N	ACIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54c13ab3-658a-4045-9bd8-378f93ac3697	A-CINCH	\N	A-CINCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d2a05ea0-2caf-499f-bf2b-bfc7960a2af7	ACINO	\N	ACINO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
601b099c-e3a6-4b42-8008-32506ddab906	ACINPLAST	\N	ACINPLAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35c2faca-548a-431b-ac00-2316a0548af0	ACI-UV	\N	ACI-UV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1311bb6-cf5f-4b95-9366-ac7a7266d844	ACMAC	\N	ACMAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
036df95d-05b6-441a-a892-84507be6a855	ACMC	\N	ACMC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e035e1a5-5a9e-4c0e-bc90-8a749f4ea5c1	ACME	\N	ACME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
464df4cd-d180-4238-90bb-afbe07e17021	ACMO	\N	ACMO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9d8c8ef6-b4e8-4172-80a4-1d753e449342	ACMOL	\N	ACMOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8cb48c44-4886-400d-bd64-f2d4a8b4659a	ACO	\N	ACO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dfb21354-d6bd-4bb4-ac50-4b09b3f07727	ACOBAR	\N	ACOBAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
efd175ed-f9e5-432d-86cb-18e219b198aa	ACOBSEC	\N	ACOBSEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d94d7dcf-15d0-4527-9c07-92423534d565	ACOC	\N	ACOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b81ab2dd-7ae7-4c11-a46e-e986d3626cc9	ACOC-TH	\N	ACOC-TH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56e5d04d-02ea-4166-bc8c-bd663536981f	ACOCTIA	\N	ACOCTIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f3024bf4-2a1b-4eff-be92-fd9397070be9	ACoDM	\N	ACoDM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8daa9715-6fd4-457f-a9d2-53c56bfb3925	ACOFC	\N	ACOFC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1785c883-f1a2-4364-a3f9-f32c255d82d9	ACOFORS	\N	ACOFORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b73363fd-c943-477f-b439-4569da43cbad	ACOLA	\N	ACOLA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6369392-1a2c-46b8-a1dd-8487e86c1124	ACOM	\N	ACOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ba0d17d1-4928-4b02-a608-2594a4e783aa	ACOMIN	\N	ACOMIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1525bde4-e96b-4e42-99f4-c5663b28a7a7	ACONIT	\N	ACONIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7f4e7a63-d220-4cda-8193-383c4ff1ca5e	ACONITE	\N	ACONITE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
496693dc-93ab-40c0-bf3b-89a7cbbe73e2	ACoolTouch	\N	ACoolTouch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bae5d5ba-0db1-41a8-becf-f4d055c2a075	ACOPS	\N	ACOPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
862fde0c-6b69-4509-8e19-add3fc776b3a	ACORN	\N	ACORN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eedab620-0aa4-4992-9a98-9f236c053652	ACORN-BP	\N	ACORN-BP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
70d8bb64-02c3-4941-891d-2e427ba1f3f3	ACOSA	\N	ACOSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8888d366-b58a-4a66-b933-0c6e61191458	ACOSE	\N	ACOSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
64181524-b1be-4ef2-a269-80ec2fc71637	ACOSENSE	\N	ACOSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
af3bb9e3-c464-4684-991d-60d8ee0bac2b	ACOSPECTOR	\N	ACOSPECTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e1bd09e-bbce-4477-9d55-37700d046a04	ACOST	\N	ACOST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
27cdc994-685d-4d3e-9de2-0bca893a2e02	ACOSVA	\N	ACOSVA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81901079-cd15-43a8-a018-163b4e943c05	ACOTAAL	\N	ACOTAAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
50bd3277-e9b5-46cc-b65d-26de7626934e	ACOULOMODE	\N	ACOULOMODE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7a50a1f6-f498-4898-ac5d-83f9bc846292	ACOUPLASMA	\N	ACOUPLASMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
187f98af-9991-41cf-9b30-1986cf4afcea	ACOUSEQ	\N	ACOUSEQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86031c5d-04b9-4136-86ba-d6dbf76cb055	ACOUSTIC	\N	ACOUSTIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2cfe86a4-f948-414a-a38c-3260b676193c	ACOUSTIC ATLAS	\N	ACOUSTIC ATLAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d216aeb-d3d0-4fb6-add3-361467b1de2a	ACOUSTIC RAINFALL	\N	ACOUSTIC RAINFALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b2585ba1-f53e-48df-9f0f-82d3e7b85ff3	Acoutect	\N	Acoutect		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8302f5e3-bac5-499f-bf87-677b31be8a30	ACOUTRAIN	\N	ACOUTRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
210d709c-0f8a-4e24-860a-c96198acdaa0	ACPNMR	\N	ACPNMR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3aff0957-3552-4658-b658-56ea24fe0a1c	ACPRE	\N	ACPRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
09b89c38-434b-4b86-970a-d000c2c128b2	ACQDIV	\N	ACQDIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a4d8fa63-fa1d-427c-8ba3-68ce4c535b01	ACQUIRE	\N	ACQUIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
610a4083-c81b-4023-9aa5-9e52a41d039a	ACQWA	\N	ACQWA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89803d5e-56b6-4783-97af-029b753d29d6	ACRCC	\N	ACRCC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ba56cb9-88bf-4cfb-8a49-5ab591dfae70	AC REMOVAL MECHANISM	\N	AC REMOVAL MECHANISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d54c1b0a-4d76-462c-bc4e-810bda220ea5	ACRES	\N	ACRES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22d1348f-7092-4f19-99a7-a1692f14ee51	ACRIMAS	\N	ACRIMAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9b16be61-b98d-4b09-aa90-b2524b7b6352	ACRIPET	\N	ACRIPET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5623a9e3-5d03-4ff6-8bdf-cb595b295072	ACRITAS	\N	ACRITAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
09045029-bb83-476c-a351-d63d195eeaf4	ACRIT CY	\N	ACRIT CY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00ee9d2e-e00e-4f03-931a-a3c6e65a8a88	ACROBA	\N	ACROBA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6cae7e1d-2184-465f-91f5-2873f71c3b75	aCROBAT	\N	aCROBAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ef01ca80-2d41-4169-9685-b3077ac833be	ACROBAT	\N	ACROBAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56800c40-88ec-479d-a063-90efa75ab11c	ACRONAM-Speech	\N	ACRONAM-Speech		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6fbe070-e84c-4bbc-a237-df8d99012049	ACRoNNIM	\N	ACRoNNIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
31c6e1cd-3982-43ad-b612-ab8c6ed2ea17	ACROPOLIS	\N	ACROPOLIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d14ae27-6328-4cbc-a076-fd50257c209a	ACROSS	\N	ACROSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7ebe5d19-c763-4dfb-bc80-b52cd95f2d4d	ACROSSBORDERS	\N	ACROSSBORDERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bedf0d8b-831b-43ac-8009-6e93c275ce4c	ACROSSING	\N	ACROSSING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0bcfc07d-65c2-40d4-b5aa-6b8a3020f085	ACrossWire	\N	ACrossWire		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf5b8f75-c963-4912-8710-2cba29679fb5	aCryComm	\N	aCryComm		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
39ff3120-f868-4d3d-bb9e-a76250c46e4c	ACSAC	\N	ACSAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13707ddf-2e55-4b8e-8ce4-cbd9352c0e2f	AcScapeStress	\N	AcScapeStress		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
16f2c1c2-fb39-4da9-8245-707f3c530437	ACSELFASSEMBLY	\N	ACSELFASSEMBLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7bee1c73-16b0-4441-8c2d-a31ba9470b5c	ACSEPT	\N	ACSEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bc049af3-9a0d-43d5-b7d4-76192b58e225	ACSI	\N	ACSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d063a13-8b69-4985-a536-4619640e1e6b	ACSol	\N	ACSol		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ebec1a20-f846-4372-85cd-05ddbf61cab9	ACT	\N	ACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d90528fb-6e41-47c7-a1c3-68b79194502e	ACT4INFRA	\N	ACT4INFRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5dab0ace-67da-4625-9143-98fff49ac896	ACT5G	\N	ACT5G		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35e44557-ca71-4dc2-aabc-546dfd23829a	AcTafactors	\N	AcTafactors		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d743cbae-9bb4-4ea6-9ff4-ddbfb6eafc38	AcTaferon	\N	AcTaferon		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
162c1bed-1c35-4092-b309-4abef9a3fb53	ACT against AMR	\N	ACT against AMR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ebf495a9-0ada-48e1-aa54-46278755caef	ACTAGREEN	\N	ACTAGREEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e0758378-f808-4139-96f6-c31e482bad47	ACTAN	\N	ACTAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3a763b7f-876e-42dc-92ff-246d7f34caf8	Actanthrope	\N	Actanthrope		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5cf34e30-a400-4161-af1a-4e4027ed4131	ACTAR TPC	\N	ACTAR TPC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d70615af-a643-4d43-a893-6908c0f418ce	ActDisease	\N	ActDisease		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3ba8a8e3-741c-4312-986a-9f7393f26719	ACTECH	\N	ACTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5906c3a4-cf22-452f-b1ac-80edcec84080	acteno	\N	acteno		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c7d4acd-5860-4961-9183-bece4e147257	Act-EPR	\N	Act-EPR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
87226966-0155-4920-91c7-5b19ba261af3	ACTIBIO	\N	ACTIBIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb78e1f9-b6b0-4b6a-b03b-f46c23c7a006	ACTICAPS	\N	ACTICAPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e603cf0b-6ebf-42d5-96de-874f8dec33df	ACTICELL	\N	ACTICELL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1e4db7e-c7f3-433e-820c-e272c218fced	ACTICIPATE	\N	ACTICIPATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2673998c-e81c-42b4-9fa1-14c4a2e52ddd	ACTiCLOUD	\N	ACTiCLOUD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f2a2a38e-a9cd-492f-b659-363e1a4c61ad	ACTICO	\N	ACTICO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d0d7bb02-1603-41e9-b375-a4b4bd58eb9d	ACTICOSPACK	\N	ACTICOSPACK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
52100041-6351-48f2-8037-3a5f38940eef	ActiDoC	\N	ActiDoC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4354a568-6e1d-4437-84b7-1be7da0095f3	ActiDrops	\N	ActiDrops		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46ef7373-43ce-4016-8880-1c34f090e05a	ActiLit	\N	ActiLit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5fbb4470-f4e5-4d8e-b9d4-022daf716f1c	ACTINET-I3	\N	ACTINET-I3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3628716-d7fe-4386-b356-9ae8f475d40d	ActIng	\N	ActIng		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40197539-4260-475e-b3f4-70145d1b11a2	ACTING-NOW	\N	ACTING-NOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5324f10-bcef-4257-8a91-3e7a60e43877	ACTINIT	\N	ACTINIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d19670c9-8c9b-4790-9a7f-7e8164d41cbe	ACTIN-NUCLEATORS	\N	ACTIN-NUCLEATORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a67cfa93-aa51-441e-8280-383f194d1745	ACTINNUCLSHAPECANCER	\N	ACTINNUCLSHAPECANCER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68181126-faa3-456a-b0df-37b023b3f750	ACTINONSRF	\N	ACTINONSRF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c25d9d44-791c-4cf8-bada-af91622518ba	ActinSensor	\N	ActinSensor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
06a3e269-19c8-416d-9c63-e15100dd5073	ACTION	\N	ACTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f6c24ad3-95e2-482d-ada4-fd2c6838c3ad	Action and Time	\N	Action and Time		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2aeb72c5-74f7-47ae-afd6-3bea3cef61c4	ACTIONCONCEPTS	\N	ACTIONCONCEPTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
150bbb75-3595-4133-92b6-f685212eb3e5	ActionContraThreat	\N	ActionContraThreat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c359e0ba-bcb7-459f-9f51-f332886f8d27	ACTION COORDINATION	\N	ACTION COORDINATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
84fb6fcd-4bdf-47a4-a4be-4e67a6838b3a	ACTION-Grid	\N	ACTION-Grid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e57f8fbe-b726-489b-add4-f3ca47086ecf	ActIonHeat	\N	ActIonHeat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6229075c-4297-423a-82c7-0b1e614b68ce	ActionPlanT	\N	ActionPlanT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b9e7afb-a0e3-4905-aa25-206dea7bd50a	ACTIonRCraft	\N	ACTIonRCraft		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
28aac894-e69b-4786-bbf6-0fadc5a05812	ACTION TO GESTURE	\N	ACTION TO GESTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05f50b20-1c61-4506-8609-4920e6ac82e6	ACTION-TV	\N	ACTION-TV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b26e1696-ed6f-426e-88f1-7fa64d2157b1	ACTIPPTSENS	\N	ACTIPPTSENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
49554441-72d7-4ab7-8d24-6ed51a8f192d	ActiTOX	\N	ActiTOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e933bc5-d3ca-487e-a804-9e5551b06966	ACTIVAGE	\N	ACTIVAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
088909f0-fa0e-4bfc-8127-ef0f4ef6e37b	ACtIVAtE	\N	ACtIVAtE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0721e931-e756-4fa0-9350-c5a91ddc7c15	ACTIVATE	\N	ACTIVATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d38a94eb-bff9-41f6-94ae-ad0fd498a50f	ACTIVATION OF XCI	\N	ACTIVATION OF XCI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d12e054-0169-4bf8-91b8-afd8f856bd6d	ACTIVE	\N	ACTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f0b3ef4d-9663-4da6-b920-b711434a58c3	ACTIVE_ADAPTIVE	\N	ACTIVE_ADAPTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5ec2c6b0-6d0e-4423-8e78-12b93d7d3ce0	ACTIVEAGING	\N	ACTIVEAGING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00616fa5-c565-4a12-8fe0-a1afa764e1ec	ActiveBioFluids	\N	ActiveBioFluids		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
10807f5f-d615-446e-b33a-fd675668a6c9	ActiveCortex	\N	ActiveCortex		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c33fede-789e-4476-9925-2c145b0757e4	Active-DNA	\N	Active-DNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71e989bc-beb3-47ad-8159-8f6c517da87d	ACTIVEDYNAMICS	\N	ACTIVEDYNAMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73f63e3c-3bfd-4f80-bd63-9fc7dad95db1	activeFly	\N	activeFly		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
555be634-8813-4f31-a83a-e3e45e08f122	ActiveGrid	\N	ActiveGrid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4e0103c8-5f82-4c60-b1c7-a39e6826cad2	Active implants	\N	Active implants		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9c95ece-beaf-489b-8a6a-9d0d0720f1a2	ACTIVE_MARS	\N	ACTIVE_MARS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f16e65f-34cc-4934-9ac0-beb16006e12e	ActiveMatter	\N	ActiveMatter		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4ecb57f4-54f4-4f5a-8b32-f459c27fb0fc	ACTIVEMOTION3D	\N	ACTIVEMOTION3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
701347d4-6310-4ad7-8082-113df5186990	ACTIVE NANOPORES	\N	ACTIVE NANOPORES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bc5b119d-aef6-430f-85de-d87482a14e86	ACTIVE NEC	\N	ACTIVE NEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4054198f-c2fc-4de1-91ab-e71e7baba953	ACTIVE_NEUROGENESIS	\N	ACTIVE_NEUROGENESIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04763e4e-634e-4504-b979-aa2f94c38299	ACTIVENP	\N	ACTIVENP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f9a15f9-8062-461e-8c75-2f0d0d31b331	ACTIVE PERMAFROST	\N	ACTIVE PERMAFROST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7116c17d-4c6e-44d1-a19f-995ab29f0cb8	ACTIVEPHANTOM	\N	ACTIVEPHANTOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f99a14d-687e-49ce-8b2c-cc533863bd34	ACTIVE SNIFFING	\N	ACTIVE SNIFFING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d9cb8989-6a9d-45c5-9834-29fb098925d8	ActiveTest	\N	ActiveTest		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
998e04ce-ad45-4cdc-aa43-eec00a2387a2	ActiveWindFarms	\N	ActiveWindFarms		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a67ab61-dd85-4051-960b-7151cfe3391d	ACTIVIA	\N	ACTIVIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c56d383-ecab-4c52-a44d-e12536b1839b	ACTIVIN AND CANCER	\N	ACTIVIN AND CANCER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d26c299-853f-46ed-a039-649558d12b91	ACTIVITY EXCHANGE	\N	ACTIVITY EXCHANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89ccb75a-4baa-4c7e-a70f-bc2313a84878	ACTIVITY & PLANETS	\N	ACTIVITY & PLANETS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a4c548ae-53e1-4586-b2ee-ec6f8391d9cc	ACTIVMOBSEC	\N	ACTIVMOBSEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4aee701f-4f22-4b10-afb3-55b8cd82111a	ACTIVOXY	\N	ACTIVOXY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ee80080-239f-4b95-88d4-8f3d3321b2be	ACTIVRENERGY	\N	ACTIVRENERGY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e7a388c-eb49-48d4-8f84-afe340c8030a	ACTIWATE	\N	ACTIWATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e38aaa56-2afa-49e5-9400-d88cffbf2a39	ActLight	\N	ActLight		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
02a0f78c-3455-43af-ba0c-7c5c54c5ff22	ACTMECH	\N	ACTMECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
254457d0-6753-4ad7-8b2e-1e2947f39a43	ACTMOST	\N	ACTMOST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8cae7f7-8a7d-4269-b108-9ae84b190e6b	ACTOIDS	\N	ACTOIDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78d093a5-a24d-4649-bf6a-b352421e1a30	ACTOMYO	\N	ACTOMYO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9d9ea25-4e28-4130-ba6b-78272dabd099	ACTOMYOSIN RING	\N	ACTOMYOSIN RING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
285ff772-8e65-46d2-a347-24c107766f63	ACTOR	\N	ACTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8a7c053b-7213-4041-876a-46b57c9342f0	ACTORS	\N	ACTORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb9f912d-90e0-4de7-a56b-9ef8eb6e6462	ACTOSPED	\N	ACTOSPED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3c7dc207-fc43-4265-b881-4f77799dfd9f	ACTPD	\N	ACTPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9668229-b4a9-4c12-9725-2c9d3dba893f	ACTPHAST	\N	ACTPHAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d72df3e2-fd1e-49ed-a1a0-b94fa4dae373	ACTPHAST 4.0	\N	ACTPHAST 4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3699e74-944d-4f91-a6fa-3844591eae4b	ACTPHAST 4R	\N	ACTPHAST 4R		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
554036ae-7295-4b5b-afb7-c67321d94b59	ACTPUP	\N	ACTPUP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
873e241d-9494-4e1b-acda-56920d7f7e57	ACTrans	\N	ACTrans		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
528f2dc1-9e0c-4731-a4ed-ede4e2def619	ACTREAL	\N	ACTREAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34f763e7-69de-4213-b10d-d75bbe60f41c	ACTRIS	\N	ACTRIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b227c48b-19a7-4679-9de6-e5feb742fb9c	ACTRIS-2	\N	ACTRIS-2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d63749b-8a95-41a7-b450-96d94b364e80	ACTRIS IMP	\N	ACTRIS IMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b77767a-e870-4019-9ade-0b777a8bc2df	ACTRIS PPP	\N	ACTRIS PPP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d557d004-7f11-46b5-9054-9952f6812a54	Actsa	\N	Actsa		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55151afa-077a-478b-884a-3b003ccd59cd	ACTSELECTCONTEXT	\N	ACTSELECTCONTEXT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c43199f-e19d-41c6-8aac-c3c7a5ff9609	ACTTiVAte	\N	ACTTiVAte		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
586cdbaa-172d-46c9-a0cf-6a77b03ba552	ACTUATION2015	\N	ACTUATION2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c5bfbc99-9b33-4dcd-9739-d97fddf3864b	ACTUS	\N	ACTUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5b2cc04f-ddf1-4022-92f7-696bf496cc55	ACU-AHvE	\N	ACU-AHvE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0af684cc-7de6-4911-af19-3b67cb885c9b	ACUHRA	\N	ACUHRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
627cc9f6-44a3-48e0-a7dd-02f322c6beba	ACUITY	\N	ACUITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d530755-dd4c-4173-841c-3df84bef8711	ACUMEN	\N	ACUMEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
79b13917-769c-4277-a3e5-5092b7ffad2f	ACUSEP	\N	ACUSEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d35d939c-bd7f-4246-9155-291a1b592e45	ACUSLABS	\N	ACUSLABS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
38d892cb-cc98-4c63-a605-4b27195f7f61	ACVOIHE	\N	ACVOIHE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cbcfff8e-db30-41ff-b920-04fd08dfa523	ACWIND	\N	ACWIND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5c2a987a-a81c-469f-a0b2-be85f0b3268c	ACXIS	\N	ACXIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9e57cef9-8f29-4f62-a075-86cee66fd02e	AD4GD	\N	AD4GD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0004894a-dd75-4367-bb24-d1d574ee839e	Ada	\N	Ada		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
27be7e55-ff03-4aee-8971-ddd8b1fd7285	ADA	\N	ADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a67a5769-3565-4a1c-b20b-534f2b5611a5	ADABTS	\N	ADABTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f1351e2-50c0-4d90-aa83-cc7b03d34c0b	ADACOM	\N	ADACOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7cf44639-4287-4f09-8be9-9e1e5fc9b044	ADACORSA	\N	ADACORSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b1ab148-7e0d-45c4-9ec1-891cc227eb99	ADAFARM	\N	ADAFARM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d94d76ce-f2b0-472d-9fc4-3b9c23071f74	AD_AGING_AND_GENDER	\N	AD_AGING_AND_GENDER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f03f1a00-d55f-4449-8b27-801f9ec5bb34	ADAGIO	\N	ADAGIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bc86fa1b-e301-4afc-ad8a-997974e1d669	AdAI	\N	AdAI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d94c5961-29bf-4edb-8b5e-cf860b2f9a21	ADALAM	\N	ADALAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aa197db8-a471-4013-a6e5-ee6c0b0d9315	ADAM	\N	ADAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2019d569-f843-4118-9775-f47fd405f2b5	ADAM-15 AND AF	\N	ADAM-15 AND AF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1dbd330-1fd1-480e-99ad-f3726230dd46	ADAM^2	\N	ADAM^2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3b03fe65-25a8-4e14-96fd-cbdccac9a129	ADAM4EVE	\N	ADAM4EVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d7894015-9153-468c-b290-c2ea8192fb9c	ADAM5	\N	ADAM5		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fe192858-c328-412d-b135-32e4d9486c15	ADAMANT	\N	ADAMANT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0154b632-070e-4c64-815f-e6c182fa2cab	ADAMANTIUM	\N	ADAMANTIUM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b29c7976-26b9-4d97-ae3a-632618a19efd	AdamFrame	\N	AdamFrame		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
09810ec4-f2bb-4a43-8e5c-7d7019f6fbad	ADAMNEURON	\N	ADAMNEURON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ac258dc3-d565-44c2-985b-11cfeb990f68	ADAMOD	\N	ADAMOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1a0ba480-66ba-4082-b70f-3356cc92f408	ADAMO Robot	\N	ADAMO Robot		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ca2c55ee-1fc1-4f91-8847-e6c444be459a	Adams	\N	Adams		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1131fd4c-390d-4b23-ad05-9ceef92819ca	ADAMS	\N	ADAMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2340d2ac-4836-49f2-b90c-8b0de5195f86	Adams Hand	\N	Adams Hand		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78a8579b-3bb6-4b1f-b9f4-3bd0c805a434	ADAMtx	\N	ADAMtx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6117866b-68bf-4247-bed5-df88255a3b86	ADAO	\N	ADAO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e48a4d24-37a2-41f0-a3d4-1a20cbdf6f55	A-DAP	\N	A-DAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b54e9a84-b716-4528-a123-716657dffbc3	ADAPOND	\N	ADAPOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ab0ea645-e9ee-4503-bf2d-d0fd414d8240	Adapptise	\N	Adapptise		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
faa410de-488c-4d3d-bee9-c87233bc3557	ADaPt	\N	ADaPt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
66ae1f2d-81a3-4919-a6b6-c5306f65c2dd	ADAPT	\N	ADAPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56701aaa-6f36-4e33-9ffc-4a6357d1aae5	ADAPT2FLOW	\N	ADAPT2FLOW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ab78093-23c5-43c6-960a-b81650c23e23	Adapt4EE	\N	Adapt4EE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2431cd53-5b8a-4282-8e82-009ce821afaa	ADAPTATION	\N	ADAPTATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
28b99f72-326c-4d62-b4fa-64eec79ad6bb	ADAPTAWHEAT	\N	ADAPTAWHEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
756b6e02-c335-4f50-9c58-61f1f1db7963	ADBCRZB	\N	ADBCRZB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
322597df-be8b-4342-b7bd-d1442c849046	AdaptClim	\N	AdaptClim		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a04e8e73-b75d-4e40-86f7-e1cbc9e7f4c6	Adaptcontrol	\N	Adaptcontrol		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b027ec7-a6d1-48c2-ae1c-cfc10849d09f	AdaptEconII	\N	AdaptEconII		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
942cc5e4-12ce-4121-81bf-88632360af2e	adapTEd	\N	adapTEd		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c1f0e3a-373f-4aa6-8926-8c1f6e5be959	ADAPTED	\N	ADAPTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cd5ac940-aa90-4d60-8883-a1c7ce2b5aa0	ADAPTEM	\N	ADAPTEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5d8fc3ec-96fe-427f-976c-7c8d5efd6e39	ADAPT-ENVGENOME	\N	ADAPT-ENVGENOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42934fe5-8879-4d47-89f0-6c5bd36d914d	ADAPT_EVOL	\N	ADAPT_EVOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
03bf7f48-c17b-491c-9fa4-62e93ea8f0bc	ADAPTIMES	\N	ADAPTIMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9284f331-c36f-44ea-a4dc-7f6702a94db0	ADAPTING2UNCERTAINTY	\N	ADAPTING2UNCERTAINTY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d67c2331-bb4b-448c-b4d7-d375204c3d89	Adapting Dickens	\N	Adapting Dickens		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0160e2a1-f115-4c60-b7b2-775adb6e41a9	AdaptIVe	\N	AdaptIVe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2edb949b-f733-4cb4-a836-fefa61605e07	ADaPTIVE	\N	ADaPTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3845296-fa50-4d65-bcfe-806bae5cd822	ADAPTIVE	\N	ADAPTIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
79756a08-e553-4b84-8f5f-4bb44ce71c39	ADAPTIVE INVERSIONS	\N	ADAPTIVE INVERSIONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5d1f52ca-71e7-4cde-b112-8562bee4e867	AdaptiveResponse	\N	AdaptiveResponse		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56e8e34b-f94d-4625-bb48-a38bf626d630	ADAPTIVES	\N	ADAPTIVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1bcf0601-f148-4b37-8751-1c698a9a332d	Adaptive Simulations	\N	Adaptive Simulations		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1293181-6ffa-45b4-b9c0-30d9ea8d8f0c	ADAPTIVE SPECIATION	\N	ADAPTIVE SPECIATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
96ff5ba7-e26d-43ee-acc4-aa72cc09d248	AdaptiveSTED	\N	AdaptiveSTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98aab660-ede9-4980-9ca9-a0fc04e33eef	ADAPTIWALL	\N	ADAPTIWALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6a63117-188f-4454-ad8c-20819efa745d	ADAPTNANO	\N	ADAPTNANO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8a329323-dd75-422d-a2a8-4b9fca60367d	AdAPtoGENE	\N	AdAPtoGENE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c35a4a8a-7f3e-407b-bca6-317fe029e59c	ADAPTOMICS	\N	ADAPTOMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e45d9350-c436-4575-b96f-e065c8db8d38	ADAPTOS	\N	ADAPTOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f40589b6-e4d3-4765-9f53-a59cec8c66e3	AdaptoSCOPE	\N	AdaptoSCOPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3de31633-dc0e-4b59-b916-be717d90a96a	ADAPTPOLY	\N	ADAPTPOLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82a22a06-cd71-4ca2-aa28-d2a31fd05135	ADAPT-r	\N	ADAPT-r		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7f6ab65d-3584-446c-8ea3-cbd6f6127610	ADAPT-SMART	\N	ADAPT-SMART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
48b09520-d394-4e1a-9f68-4d564e64199b	AdapTT	\N	AdapTT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d87793e5-68f7-48e7-b261-f078953bb5b5	ADAR1 AND RNAI	\N	ADAR1 AND RNAI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
03b49cce-afef-4dea-94f9-74c91e3bff22	ADASANDME	\N	ADASANDME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ed8fd19-848b-4707-b265-834427bada60	ADAS-EU	\N	ADAS-EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f5832a7-ee2c-4e25-a50c-9a83a7f5266d	AdaSmartRes	\N	AdaSmartRes		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f3f4465e-4630-49b4-a360-d4f821396f26	AD ASTRA	\N	AD ASTRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ba1cd00-9356-4dbb-8f59-3e4f7da8163c	A-DATADRIVE-B	\N	A-DATADRIVE-B		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9c19adb6-6244-4a7a-915f-d232f0453d13	ADAVES	\N	ADAVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2acda630-c443-4b04-8beb-d260b7bffe5b	ADAW	\N	ADAW		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b6db58b4-7577-48c3-abf3-4ab0020a8953	AD BIOMARKERS	\N	AD BIOMARKERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82567891-3bf4-48a9-bc1f-5dc6dd4302c5	ADC	\N	ADC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3dabdffd-0c3c-495e-954c-7aa4c6833abb	ADC2GBM	\N	ADC2GBM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ed25c10-8f3e-4f3e-abfe-74498e08da1a	ADCC	\N	ADCC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
744efb28-9e50-44fc-a253-20c44208bf15	ADCELLPACK	\N	ADCELLPACK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
209b27a2-f665-49ce-b3f1-d8db98c268f2	ADCLICH	\N	ADCLICH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e94722c9-313c-47c4-894d-6f44b685d37d	ADDABU	\N	ADDABU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1de1b322-1598-4e3c-b3dc-aabcf1dee1ea	ADDACT GmbH	\N	ADDACT GmbH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d68018a-6ae1-4eec-979a-530eb67315f3	ADDAPT	\N	ADDAPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
015781cd-5ab8-487e-9fd7-1cb241fae869	ADDAPTTA SEALS	\N	ADDAPTTA SEALS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7ed6abef-e5e8-4e72-8945-6b134ee7feb4	ADD CONTROL	\N	ADD CONTROL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f0b9ec4c-a7ed-48a6-a515-1357cf1ee14a	ADDECCO	\N	ADDECCO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6eb213a-de57-4197-b897-a24cd2606ee9	ADDEGE	\N	ADDEGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3bcdf82b-addc-4909-a0d7-948243c9e605	AD Detect-Prevent	\N	AD Detect-Prevent		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae438866-6966-4f20-9d68-5f140183b7b3	ADDFACTOR	\N	ADDFACTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1fa517b-f334-49ac-992c-885f2b0a10c6	AdD HyStor	\N	AdD HyStor		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a75c7942-6e65-4933-b5fe-ee1b105f59e2	ADDIA	\N	ADDIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92308c43-2fd2-443c-9b21-ec4ea9c0e59e	ADDICTION	\N	ADDICTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26202aa0-7bb9-4ed0-bc1d-3aba8784e3ca	ADDICTIONCIRCUITS	\N	ADDICTIONCIRCUITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6602783-15a2-4505-a39b-8915c9e4c698	ADDIFLAP	\N	ADDIFLAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
08feb612-2ca1-4ecb-bf47-8a531491e819	ADDIMOT	\N	ADDIMOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3768a513-508a-4b35-a2b0-e2f8c1a89c64	ADDIO	\N	ADDIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f82dab5f-d2e0-4af7-9cde-ad5ffd20c7f5	Addionics	\N	Addionics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d5ba56e0-5268-4528-9036-23a7b690ff19	ADDI-OPTIMISE	\N	ADDI-OPTIMISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
205da3f8-97d9-42b8-9dfd-cad9025f1d3a	ADDITAC	\N	ADDITAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54e185bf-e86f-4a25-8e05-ee965865b55b	ADDITION	\N	ADDITION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9b9ee0ed-76fe-4bb8-a012-f7362b70a822	ADDITIVES	\N	ADDITIVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9a925ffa-5255-4a78-b919-c4786e011fc7	AddMan	\N	AddMan		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
64b3466c-3b36-4afa-96bd-a613c1d12f4d	ADDNANO	\N	ADDNANO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32b98cc1-72f2-4f96-88ee-0f9bcc51ff55	ADD-ON	\N	ADD-ON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d3e4a0ff-7b4a-45c6-bee3-ed29e7e48587	ADDOPTML	\N	ADDOPTML		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47c36392-07d3-4760-8415-ebf867d85832	ADDovenom	\N	ADDovenom		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
512e8e7a-f606-490f-b731-b8eef6d8a34c	ADDPLUGIN	\N	ADDPLUGIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2825a009-7b05-4026-be30-a93ecc5613d4	ADDPRIME	\N	ADDPRIME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
84c1ae76-762e-4a80-aca6-7e2434c310f4	ADDPRIV	\N	ADDPRIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b47599fb-ae40-4d16-ac3e-9601260d6ff1	aDDRess	\N	aDDRess		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d288cb81-800d-49e4-82fe-1cdde708525d	ADDRESS	\N	ADDRESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
075044c6-7fef-4f7a-a4d2-e8aa0680faef	ADDRESSING	\N	ADDRESSING		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
499ae637-410d-4f7c-921e-14262cabd87e	ADDSAFE	\N	ADDSAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd8d5838-b4f3-4b9d-8bae-0cd9ee40a945	ADDUCE	\N	ADDUCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc6c9474-b89e-4e81-8053-f80c56417bef	Adductomics	\N	Adductomics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2538798d-aac3-4584-b526-a3eebeef9395	ADE	\N	ADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a710eee6-7ddb-4af7-8af0-8e094924416b	ADEC	\N	ADEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
31234ad3-4e8e-41a4-90dd-4bc3ba411fa0	ADEL	\N	ADEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0f0eee68-cbd1-4ca3-9f71-b6f035b8741d	ADELE	\N	ADELE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6973b5b6-4aa7-44a7-8c85-3a22d57affd2	ADEMU	\N	ADEMU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13d78a41-fc99-4167-83f9-dd5fa568bb60	ADENEAS	\N	ADENEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d8d04fc8-6e8c-48ac-8ba3-63e673557755	ADENOSINE	\N	ADENOSINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76f373a0-7f69-49e7-a368-edc3c7f17a31	ADENOSINE-RECEPTOR	\N	ADENOSINE-RECEPTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
112d8d61-d99e-4f89-af17-2ffbcdd997a2	AdEPT	\N	AdEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cd099e15-6306-445e-891c-51856140a9e2	ADEPT	\N	ADEPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a85a1d00-b89d-4204-ae57-c9c28ad1944c	ADEPTNESS	\N	ADEPTNESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d526e83-96f2-4d27-ac6c-f22c5b0b2a06	ADEQUATE	\N	ADEQUATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
659d909d-f0be-4790-a24c-dc3e0c23eff9	ADERS	\N	ADERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d152adbb-92a3-4bb3-8cce-18b5cd80271b	ADFIMAX	\N	ADFIMAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40e5cef0-75d3-4901-9b68-804549cf8fb8	ADFLICO	\N	ADFLICO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c63da5e9-6953-4d64-857a-39d1cd13456a	ADFU	\N	ADFU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1fcc8cb3-17e7-4d80-b24d-f65c3df0fa63	ADGENTHE-CDA	\N	ADGENTHE-CDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
252e6ee8-9347-4e13-8b8c-076c587e8c59	ADGLASS	\N	ADGLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f78e4d2d-1df2-41f4-ae10-54a6ddcb769d	AD-gut	\N	AD-gut		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d5ce5447-0ea9-4d65-be67-18c41ea0fa5f	ADHCEM	\N	ADHCEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3a242172-d594-41b7-b917-34632c68a2b1	ADHDLightUp	\N	ADHDLightUp		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90aca84d-74da-4c72-94b0-dcce7b65b36b	ADHERE	\N	ADHERE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e32e0597-1a2b-47b9-ba35-bb66468722ce	ADHERO	\N	ADHERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5aa6d93-a558-4f55-b73c-467ae03f746a	ADHESION	\N	ADHESION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1769c60f-05fd-4a66-8ce7-7d0f9e7201ff	AdheSurf	\N	AdheSurf		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6436b766-3141-4159-85ba-4ff29a08d2bb	ADHESWITCHES	\N	ADHESWITCHES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3ad7fe7-6dc3-49d9-b231-d3809e8ab3c9	AD-HOC	\N	AD-HOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
113bc7da-c969-43ae-86c2-589ef0c3f7cb	ADHOPHTA	\N	ADHOPHTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
23ef69e8-403c-4037-9c37-42a58d2c3c8d	ADIBAS	\N	ADIBAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
30ba6a7f-032e-4650-b865-e95ed65943fa	ADIBET	\N	ADIBET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4fc68066-c130-4024-9a48-d5ba199d1ecf	A-DIET	\N	A-DIET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
64f07f44-f54a-4732-9e01-400ea6750c79	ADIFF	\N	ADIFF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e5ea2402-1e1b-4556-8acc-1da416c5860a	ADIMMUNE	\N	ADIMMUNE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
683fbe34-288f-4f45-8e47-64c3a90a2e8c	ADINE	\N	ADINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
418a36c2-7b0c-4fad-adb6-978796d9a49f	ADIOS-RU	\N	ADIOS-RU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9e58b086-838a-4b33-bb74-9746b69b1a63	ADIPOA	\N	ADIPOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc213667-a487-4b9c-ae4e-65546c647224	ADIPOA2	\N	ADIPOA2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
64d41e19-2c9d-4adf-8574-c17e97bde2a8	ADIPODIF	\N	ADIPODIF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
37c6d882-3027-47dc-9db2-a6ce088329bc	ADIPONRF2	\N	ADIPONRF2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ecfb28b-1455-42ff-8163-0fb955644d2a	ADIPOR	\N	ADIPOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c4fd54b9-c8e5-4ad0-b005-b0dc269d0c01	AdoDigitFamX	\N	AdoDigitFamX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
678f8203-e6f5-429b-8f86-c803f04d9658	Adipose genetics	\N	Adipose genetics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ee4f972-fcc5-4271-bec5-b7ba579a1d39	ADIR	\N	ADIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4edc14ba-81c2-418e-9121-9e03d4fe5723	ADiRaS	\N	ADiRaS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1f816d1-853f-4d98-9fb1-af7a721d63d3	AdIrCAT	\N	AdIrCAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
766cdb4d-e3bf-4dcc-bda4-3df521c44cd3	AdiScale	\N	AdiScale		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a590d95e-92ca-4574-a069-d0d38c6603f4	ADITEC	\N	ADITEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a23df02e-9fd3-47bd-bf28-11255e56147d	ADIX	\N	ADIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89d78903-7d23-4ca4-8a7a-857a64f4f309	ADJSYN	\N	ADJSYN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26913ce7-5a1a-45f4-856c-f8c590fd02b3	AdJUST	\N	AdJUST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
70b87e72-7d9b-4475-bae2-e3a5a526261f	AdjustNet	\N	AdjustNet		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a899215d-f179-461a-96e7-7d301e5fe98c	ADJUTUB	\N	ADJUTUB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6257e315-522f-4fb7-9fe3-361826be944b	ADJUV-ANT VACCINES	\N	ADJUV-ANT VACCINES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d895e61-0161-4479-b3b3-256351368bf7	AdLibYeast	\N	AdLibYeast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35bfa621-3c9b-4895-b049-19f069152a27	ADLIFE	\N	ADLIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d37f4d7b-5d24-4658-943a-939db3cf130e	ADMACOM	\N	ADMACOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9fad0c4e-21a8-4b2c-9ba3-66cc6859d21c	ADMAIORA	\N	ADMAIORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56304a67-0af8-4fc8-9a56-6e55f1fedc2f	ADMAIR	\N	ADMAIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
086dfbcb-3cf3-4445-be3e-463851c22f7c	ADMANTX	\N	ADMANTX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5a3ef72-9c0b-4bc2-b472-0eb3cdee8d05	ADMAP-GAS	\N	ADMAP-GAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
edb9486f-9cf8-484d-a5c1-3a12cc0c309b	ADMA TranS4MErs	\N	ADMA TranS4MErs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3be073af-e556-41dd-a93c-779a4c407d92	ADMEHE	\N	ADMEHE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e37daa21-ee01-4a6b-9417-dffe4ecd8f12	ADMEP	\N	ADMEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68603d1c-7ddd-47f8-b816-fb2366b51bc6	AdM-ERA	\N	AdM-ERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4821da5c-8cf0-4157-9ebe-7bb4d07e72fc	ADMIENV	\N	ADMIENV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9a234393-1274-4781-85ba-d27962907689	ADMIGOV	\N	ADMIGOV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5ee29518-5ae3-442a-b03c-65f89827da46	ADMIN	\N	ADMIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ef9e8d4-7626-4d27-a279-8858d954623b	ADMIP	\N	ADMIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ef24048f-8df6-44f1-908c-8ebe2f39a308	ADMIRATION	\N	ADMIRATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f83a655f-d766-408b-ba84-56da8ae76e38	AdMiRe	\N	AdMiRe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
460bbaf8-e305-49dd-be79-28d3afefffff	ADMIRE	\N	ADMIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7a0a04ae-081e-4c2b-ba7f-12c6fa988c07	ADMIT	\N	ADMIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8409b63-b9f6-4169-98bf-f09e5f53c6b2	ADMITTED	\N	ADMITTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
035a1f4a-37fd-49f2-8d35-37d0255f80f3	ADMIXTURE	\N	ADMIXTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47f627a7-fe58-46d8-9c1c-2d19525f12fb	ADMONT	\N	ADMONT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1a765b5-212e-497f-8049-69b97633174e	AdMoRe	\N	AdMoRe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1be80fa6-ac47-44e1-a1ea-e71aac0942b8	ADMORPH	\N	ADMORPH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6151488-8c4b-4e2d-abde-2169060384e4	ADMOS	\N	ADMOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2938d155-72f4-4cf8-9076-994e7b5dc7ab	ADMS	\N	ADMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8ffb5e1d-7a76-4c98-943f-6f2846b2f659	ADNABIOARC	\N	ADNABIOARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b4d9868e-7cff-480b-8487-b08badc8fb72	AdOC	\N	AdOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1984867-3147-4a32-bbea-aa3c8602b322	ADOC	\N	ADOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b59e8c37-060d-4d60-a0b6-52efd2674d5b	ADOCHA	\N	ADOCHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e2834dc-5588-4b6d-a72a-25c2b94bb824	ADOLESCENT DEV	\N	ADOLESCENT DEV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd856799-a9e5-4bca-b785-588cb8dfa89e	Adolescent identity	\N	Adolescent identity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6ea6578-8477-4041-b448-821a86b3d772	AdOMiS	\N	AdOMiS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf11f714-215d-4a26-92d3-73d1ad0cba59	ADONIS	\N	ADONIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a599a735-5903-4dcc-ac50-ce14b261b719	ADOPD	\N	ADOPD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a3a3f25c-bd77-4226-8a22-6326c43b1d0c	ADOPSYS	\N	ADOPSYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
327335dd-950d-4e2d-aeec-77192b2db175	ADOPT BBMRI-ERIC	\N	ADOPT BBMRI-ERIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ee346c1e-160e-432d-9c31-c88ba2d3acb2	AdOptEx	\N	AdOptEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
831521f6-224b-4e5d-920a-efaf87920fdf	ADOPT GRANDPARENTS	\N	ADOPT GRANDPARENTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cf46ab06-2b60-4847-b60a-41161ebdb73a	ADOR	\N	ADOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7768339-a6f0-4470-a7ed-2ea264b49620	ADORA	\N	ADORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
084853e0-7deb-4c7d-8967-17961b68721e	ADORNO	\N	ADORNO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b19f309-f6bb-4f85-99d5-800409312a56	ADOS	\N	ADOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1f4def5-e7c2-4c70-a519-065e16ddb155	ADOSE	\N	ADOSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1bdf0e7-665f-41d8-8c9c-933cf369a959	AD PATHOGENESIS	\N	AD PATHOGENESIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b279eebf-a7cd-49ad-a742-13b35c23de12	ADPROGRES	\N	ADPROGRES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
82bd5db9-20fa-40e6-96f3-ec1d1049a248	ADR1EN	\N	ADR1EN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77908c46-f05a-4d78-8d05-a02b4f21f9c8	ADREEM	\N	ADREEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26c22e9e-e8c5-463b-9c8c-7fbccdba8fef	ADREM	\N	ADREM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ee85d20f-2f25-42a3-b085-5b502024f423	ADRENAL ENZYMES	\N	ADRENAL ENZYMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ca8575a-ed72-40af-8386-b76b6c529019	Adrenergic receptors	\N	Adrenergic receptors		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f1fae56-1e2f-48b5-b406-158a8dbf028c	ADRIA	\N	ADRIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35b97a8c-de97-4013-af70-4e302386d3eb	ADRIANA	\N	ADRIANA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00e54c62-23f9-4018-a693-6bf34e398fd9	AdriArchCult	\N	AdriArchCult		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0e24b1ff-5709-4d79-bf2c-a31ffa8c2c89	ADRONE4LIFE	\N	ADRONE4LIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3083dbae-227c-4459-b6b1-b42fc0e1eb70	ADS3DV	\N	ADS3DV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
45ae6154-6a67-4476-9fde-0af0ed1f7fa2	ADS CFT	\N	ADS CFT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7072d9e1-1aaf-4883-8b70-75a83cdad58b	ADSCFTBNF	\N	ADSCFTBNF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a3667ca7-ac59-4b52-8045-3710a0fd1704	ADSCFT MUNICH	\N	ADSCFT MUNICH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fb66c54e-0754-4a39-a181-963ae64927f4	ADS-CFTSINGULARITIES	\N	ADS-CFTSINGULARITIES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
efe5ef49-70a2-445c-bdc8-cd5a3831f3b8	AdS-CFT-solvable	\N	AdS-CFT-solvable		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ac4c5bb-9650-4776-bd7c-ed28bf8ce7a3	ADSEAT	\N	ADSEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d17c5f93-f521-483c-abdd-bc9c70711741	ADSNeSP	\N	ADSNeSP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2bb73d44-1f1f-4902-8b1c-977b3eca0dda	AdsorPLAYERS	\N	AdsorPLAYERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b509b1c-0751-43ce-b0a5-4c821254b63e	Adsor-Resor Cycle	\N	Adsor-Resor Cycle		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67f2341c-42a5-4906-8f81-04947825fa73	ADSOR-RESOR CYCLE	\N	ADSOR-RESOR CYCLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3358e89-8881-49cb-ad4a-61179863527c	ADSPRA	\N	ADSPRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
744b0899-238d-49b9-a9b8-60b2e926e3ae	ADS Project	\N	ADS Project		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f9050dd-0d2d-4dd1-8272-7686da1b37d7	ADST	\N	ADST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf5eeaa2-b99a-49d4-a943-9ceda50ea157	AD SYNAPTIC DEFICITS	\N	AD SYNAPTIC DEFICITS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78cecbff-0cf0-4bf5-8155-c83bf7ac5229	AD-TO-STORE	\N	AD-TO-STORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f5120f1-cbda-4b93-83d8-7ad3cabd9e05	ADUKKIPA74	\N	ADUKKIPA74		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1522030-c2ea-4161-8b61-daf57d146ff0	ADULT	\N	ADULT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e18c52b-4805-4254-b9bd-da8f808ac7b0	ADVAGEN	\N	ADVAGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1bbee446-247f-426d-980a-7ab9ccaf2dda	ADVANC1-METH	\N	ADVANC1-METH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12bdf4e8-99a8-432d-8077-674ec1ac7111	ADVaNCE	\N	ADVaNCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
747d1fdc-a1df-4274-9cf4-80e78173769b	ADVANCE	\N	ADVANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0fee71c8-b468-4802-9df7-2fd692a3643d	ADVANCE-AGT	\N	ADVANCE-AGT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4b9b5a1a-8fe0-41d4-8472-789a8b7bfc63	ADVANCED	\N	ADVANCED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8ac2a343-d69b-4fc4-aca1-c4813fb6eed8	ADVANCED BIOANALYSIS	\N	ADVANCED BIOANALYSIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
692fb81c-5576-48b5-b717-cb7061015bc7	ADVANCED-BIPV	\N	ADVANCED-BIPV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d8c1388a-240f-477c-9d0c-69ddddbe1d5c	ADVANCEDMODNEURO	\N	ADVANCEDMODNEURO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
552f7417-dd0c-43df-83aa-6faa1f490dd3	ADVANCED_SAR	\N	ADVANCED_SAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bba83f6c-e737-435a-9209-00e0521e10d5	Advanced-SiMP	\N	Advanced-SiMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5cc6686f-e5a4-41a4-bbf6-2e6dbb6deccd	AEGIS	\N	AEGIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c82dff1e-f0c8-43ad-8ae1-a7ee752f8236	AdvancedStarForm	\N	AdvancedStarForm		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
15828f09-eb42-466e-982c-395aef2022cd	Advance_eLTER	\N	Advance_eLTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
44ff9af1-bd5c-4be3-b0ef-5bf0a259f9b9	ADVANCEETV	\N	ADVANCEETV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
baa0a592-21ed-4a9a-997b-5cf98ed48380	ADVANCE-FSP	\N	ADVANCE-FSP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32d1f194-d01c-4ab3-99d9-6b73aaa2fc6c	ADVANCEFUEL	\N	ADVANCEFUEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
36a5b522-6820-4631-9962-3094bb1bc849	ADVANCE_HTA	\N	ADVANCE_HTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
501fea87-05ab-4e1c-98e2-4641605537b9	ADVANCE-SIS	\N	ADVANCE-SIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1bcd06db-a16f-4a0f-aecf-65a397f72974	ADVANSYS	\N	ADVANSYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bab125ab-ebb8-499c-bfeb-6ddddb494a13	ADVANTA	\N	ADVANTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
555fe9ca-62e9-40f2-9269-a875497fc8da	ADVANTAG5	\N	ADVANTAG5		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e4502c55-9cd1-4e40-9244-000a80202581	ADVANTAGE	\N	ADVANTAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4730df0c-1cb9-4380-aee1-9b68198de34e	ADVANZ	\N	ADVANZ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
844ddfa5-dbcd-44bf-b9a2-dd5f5fa774a7	ADVASCULATURE	\N	ADVASCULATURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89b0fa97-b895-46ea-8152-5ff954ca613c	ADVCARBONMATLS	\N	ADVCARBONMATLS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bebe24f0-a53f-470b-bb3a-967807d16685	AD-VEC	\N	AD-VEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f2ce19ca-0c18-414a-9a99-d269ce1f4f02	ADVENT	\N	ADVENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58da77d8-bfcd-48fd-8aea-3549150e53c6	ADVENTITIA	\N	ADVENTITIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
944da674-2798-4a60-b820-dfc2bb63a7ff	ADVENTURE	\N	ADVENTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0f2ca95-4f08-4545-aed4-2e1420b42acb	ADVERSARY	\N	ADVERSARY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c0a31dec-18d6-450e-8501-ad2d05692f5c	ADVICE	\N	ADVICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56145a61-f23a-4cf8-b6e9-e0f391828d3e	AdvIOT	\N	AdvIOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98662bee-3ee9-4f04-9f86-03d33e8191f0	AD-VIP	\N	AD-VIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c12516f-538b-4e51-a2bc-c5b6981edaf6	ADVISE	\N	ADVISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
411ddae2-8af1-43bf-86df-e94cba09b0f1	ADVITAC	\N	ADVITAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
696b997e-938c-48db-80a8-132cb7c689cd	ADVOCATE	\N	ADVOCATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81ea8407-023c-4ee0-ae2d-01d39debaf19	ADVODID	\N	ADVODID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77dcba9a-afa1-41b6-b6a7-d8dd19031764	ADVOLUTA	\N	ADVOLUTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4958e526-a09c-4825-9f5d-5ef699fcaa9c	ADVOS	\N	ADVOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f00447b-a473-432b-a4c0-f5912f09414d	ADVOS-COVID-19	\N	ADVOS-COVID-19		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c335ab32-cec2-4f79-8c99-9c7b779b84de	AdvRootAgeStrig2010	\N	AdvRootAgeStrig2010		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d8c7e7fa-447d-4bbf-b621-4cbbe1d55ccc	Adv-SAEC	\N	Adv-SAEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
25cb713c-8ef1-47a0-b67e-a2a1fcae6771	ADV VISUAL OPTICS	\N	ADV VISUAL OPTICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8814bef-cb11-403a-95f8-5524d7b7b7d4	ADWICE	\N	ADWICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ad388a32-408d-4350-a36b-7bd36fc355c1	AD-WINE	\N	AD-WINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
619bcf7f-ccc5-4ccf-93f9-cde3876b5b6b	AD-WISE	\N	AD-WISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f80997ed-afcd-41db-b88b-af1bb2d3cd33	AE4EU	\N	AE4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a3204b00-c92e-4615-ac1d-091f303d6424	AED	\N	AED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67340bff-0f20-432b-a63d-59e422b0b7db	AEDIB|NET	\N	AEDIB|NET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fdd6ec73-7bba-4bb8-b39c-4fc6efb0c26e	AEDMOS	\N	AEDMOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e60528a1-82af-40e1-82dd-900f397e5f06	CND	\N	CND		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b82d4b0-ee15-4933-b665-7e1c240f3a2f	AEDNA	\N	AEDNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1ac686a-721e-4f83-99b6-9d2740a8ae23	AEDNET	\N	AEDNET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c67d261e-25a6-4dae-bd28-a4e6220fc8b6	AEGART	\N	AEGART		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
27941030-c388-48eb-8d56-f3262ea81606	AEGILWHEAT	\N	AEGILWHEAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
06333b6f-b916-40b2-8256-e595852b3978	AEGLE	\N	AEGLE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c207fc0-c670-44ad-b4a3-c0aad6f67ac9	AEGOS	\N	AEGOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6d13b25-33bd-41db-aac2-f0f94212102b	AEKSP	\N	AEKSP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
80a174f4-90aa-4cd8-a0ff-0dd8c72c2270	AEMMPN	\N	AEMMPN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7fa1f5ab-7d37-479e-9789-b869dda98f92	AEMS-IdFit	\N	AEMS-IdFit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5d29df3-747a-4a1a-9ab8-48f658903b37	AENEAS	\N	AENEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6ff43b9-7932-421d-830c-3b30d65df33e	AEOLIX	\N	AEOLIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07ef7039-c985-4a9f-96a3-ff5ed1f512cc	Aeolus	\N	Aeolus		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9a95e0cd-9af0-4181-84d5-443c736c6ca4	AEOLUS	\N	AEOLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df705d22-860d-40b9-976f-75f3427a132b	AEOLUS4FUTURE	\N	AEOLUS4FUTURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26413bd2-12eb-4220-be56-77803db2eb61	AEOM	\N	AEOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e7a163aa-6a2a-4326-bb80-d235d89714ea	AEON	\N	AEON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8092fc03-435b-473e-ab77-40a9d9ceee00	AEONS	\N	AEONS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b628037-1ebd-4fda-99c8-3b69594b2385	AERA - Pro	\N	AERA - Pro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b745e2ad-df84-4a2d-99f0-2509a2382d1c	AERAS	\N	AERAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1314e84-dab9-4314-b6d7-b128c21f5830	AERFOR	\N	AERFOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5d0d097e-4a4e-4dda-9281-f40b10c13ef3	Aerial BCP	\N	Aerial BCP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9bb59c2d-0df7-4021-8b4a-ec0af1a9ec87	AERIAL-CORE	\N	AERIAL-CORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cdd0af74-ea52-4041-9195-f52722c4e98f	Aerial Insights	\N	Aerial Insights		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9ad078f-88fe-41c4-88d8-89e42d1d9fd2	AERIALIST	\N	AERIALIST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9859bf84-2c7a-4062-bfb3-ae9b1499cbd2	aEro	\N	aEro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae21454e-7be4-4a30-9573-2329f8e09239	AERO	\N	AERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0546fc4d-67d1-42d6-9ebc-06eb44ec239f	AEROAFRICA-EU	\N	AEROAFRICA-EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
08a85af8-cb91-4449-aa38-24ade19799f7	AeroArch	\N	AeroArch		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
09b18ed9-e598-43c9-aac0-aab5129b330f	AEROARMS	\N	AEROARMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32350064-a055-4339-b19b-97c23f063a29	AEROBEAM	\N	AEROBEAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
269110aa-0511-4e93-b32f-19cf5541d3ca	AEROBI	\N	AEROBI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc2a4b67-b9e2-46bb-a744-228668a04229	AEROBIC	\N	AEROBIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3b0690f-fa17-4ecd-bfb0-57a0441086bb	Aerobits	\N	Aerobits		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9e9e26a6-7bae-4b07-8a38-ac5c43a01bdc	AEROCAT	\N	AEROCAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
30c642e3-9f92-4609-a948-f7fcaf916ca0	AEROCEPTOR	\N	AEROCEPTOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
37c5f585-75bc-4ee3-a226-8b76f507db01	AEROCHINA2	\N	AEROCHINA2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b221ef32-85a2-4099-92e9-1f2c10bb5458	AEROCOINS	\N	AEROCOINS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
62687991-dabf-4472-b6bf-36f452e5b522	AEROCWE	\N	AEROCWE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0de8da5d-834b-4d9d-acc3-b5ad7e448d61	AERODAYS2011	\N	AERODAYS2011		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6f52267-06b3-4f63-bf2b-9916f7bd6e32	AerodaysUK2015	\N	AerodaysUK2015		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf92efc9-cd15-40c0-a659-d9e1576be8d6	AERODESIGN	\N	AERODESIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5a8785d9-0d33-47ee-84e0-8de3a883c1cb	AEROFAST	\N	AEROFAST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
432e6f65-aea7-4ec0-ade5-35c3e5b33245	AEROFLEX	\N	AEROFLEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
48c2dc63-685e-43bc-b664-d09c5956398c	AEROGLASS	\N	AEROGLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77aa47b3-781d-487c-9bb2-e51a9d9410a8	AEROGUST	\N	AEROGUST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f958547e-a264-4afe-828b-9d738161027d	AEROL-HP	\N	AEROL-HP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
287a5bee-8c32-4f31-917d-ec3c79897ba1	AEROMAP	\N	AEROMAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f644075-fe84-4574-a727-f104a5e99e71	AEROMIC	\N	AEROMIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46a6f5bf-5330-444c-b37a-4c4bb348c1d7	AEROMO2	\N	AEROMO2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
784893db-7fe3-4325-b83a-1d621468224c	AEROMUCO	\N	AEROMUCO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
017a82f1-3102-4ba8-b557-e9ccd2e867e4	Aeropaft	\N	Aeropaft		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bfe1b117-4447-44d5-af37-7a505d121359	AEROPATH	\N	AEROPATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98d84e59-9caa-4ce9-a8bc-4ea0a3ca2e21	AEROPCM	\N	AEROPCM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8fc077f-ccb3-470b-8b38-0064ebcffbfc	AeroPlan	\N	AeroPlan		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9b23b4a-f02e-41c3-b699-e00701222e64	AEROPORTAL	\N	AEROPORTAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0161539e-452b-4dd0-836f-2ae0cb1cf904	AeroPul	\N	AeroPul		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71331c74-b3c5-4fee-b93f-b85317b997e6	AEROPZT	\N	AEROPZT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9fe6e64-82a1-40b7-a7df-9bfe68703b45	AeroSim	\N	AeroSim		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ac86b33-6617-4bff-9610-8ec459fc32f3	AEROSIMULAT	\N	AEROSIMULAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
37814434-1087-47ea-9a3a-7d6f541318d6	Aerosint	\N	Aerosint		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fa2ba3c0-62d9-4079-8d24-5cb3a41d1c8d	AEROSOL	\N	AEROSOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
565ca7c0-398f-4141-8e48-8cf0a714a233	AeroSolfd	\N	AeroSolfd		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b9fa4e8-be5f-42f6-9381-1ae4938787fe	AEROSPACEPHYS	\N	AEROSPACEPHYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b93487c1-e244-4345-9104-a125257409a6	AeroSurf	\N	AeroSurf		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
14198c68-080c-4618-8e9f-fa9ccd50b658	AEROTHERMOPROP	\N	AEROTHERMOPROP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90ff98e8-4461-4a5c-8cee-d4822a6abc67	AERO-TRAIN	\N	AERO-TRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9c7ce338-d524-4114-9f42-6c02b3d5c127	AEROTRAIN	\N	AEROTRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7fb26314-58e3-4e24-8ea4-cf648d4d8d24	AEROTRANET 2	\N	AEROTRANET 2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78e00582-76bb-4566-9cf2-15bf10f86bc5	AeRoTwin	\N	AeRoTwin		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d52f1963-2112-4863-90a8-3ee637458507	AERO-UA	\N	AERO-UA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d77bc1ec-5f8c-436a-938f-a7876f280940	AERO-UKRAINE	\N	AERO-UKRAINE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6a65b20f-f8e8-47ef-8dc0-f0af27059bf1	Aerowash II	\N	Aerowash II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0e4ca58d-3f38-408c-a584-ee46bb0a4063	AEROWORKS	\N	AEROWORKS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6458b30a-4c96-4963-96c3-dc430df0b3ea	AerSUS	\N	AerSUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
158af60f-9ab2-408c-99b3-1d472e25ab83	AERTECVTI	\N	AERTECVTI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a671e7e1-60a2-4153-9453-01ec3a654c00	ÆRTOS	\N	ÆRTOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c31c5fdd-656f-46be-8af4-15c8a6b2647f	AestApp	\N	AestApp		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0e22822-370e-4412-a77a-fe47f8e7ec0d	AESTHETIC INNOVATION	\N	AESTHETIC INNOVATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4e9b54b8-23b2-4860-8d97-97ad2fd60e7e	AETHER	\N	AETHER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32ff7491-8d9d-4905-ba37-cebe4800a637	AETIONOMY	\N	AETIONOMY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7612097e-f7a8-4572-8d02-dc24ca9e60f0	AETSOM	\N	AETSOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1e5ac1a4-9d8f-485d-896e-495a0fe74919	AEVIOM	\N	AEVIOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c973e8dd-6673-448a-9a50-4b5f05bd8313	AF16	\N	AF16		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c7199738-2024-46e1-aff9-56287239d03d	AF3	\N	AF3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b5553a4-3b6f-427a-9c8f-ff6d54db3085	AFactory	\N	AFactory		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
84da7f8a-15ce-4319-886c-d75e8af9501f	AF and MSOGR	\N	AF and MSOGR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
69210e13-af43-47fe-96f1-071de58c22c4	AF AND MSOGR	\N	AF AND MSOGR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b95eda29-8e27-40ae-8bf1-0feb989dde64	AFarCloud	\N	AFarCloud		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9811bb1-975b-4fdb-9ad4-ef6f7e63f109	AFC4Hydro	\N	AFC4Hydro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c183299f-d926-4674-aed4-6a61d48c52a5	AFC4TR	\N	AFC4TR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6031376-7cf3-4334-93b6-0fb93052d092	AFCIN	\N	AFCIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8361a19d-b72f-4446-821d-4591e6d74278	AFC-TEFL-HLC	\N	AFC-TEFL-HLC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7031adc1-f7db-4a07-9050-69d5cf98278c	AF-Cyber	\N	AF-Cyber		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77d9e91b-1099-45f3-b1dc-0a853c4a5f63	AFD	\N	AFD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
24513fe5-6573-4f7e-9509-d85fe7579396	AFDAR	\N	AFDAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
003eda72-f5ef-4207-a921-4245d6d3c2ed	AfDevLives	\N	AfDevLives		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c3b4dab-55f2-48eb-b728-981a3646d887	AFDMATS	\N	AFDMATS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3af370d7-f9a1-4dcb-96fc-601205db6a40	AFEG	\N	AFEG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cf47b9a1-05b0-41c0-97d5-4cae1a4c6d5d	AFEL	\N	AFEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42574acf-c629-44e2-8a19-718696af6619	AffecTech	\N	AffecTech		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f4eb2f3-fe0d-44c1-9016-40d587211d81	AFFECT-EU	\N	AFFECT-EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4b5594c7-4a88-44c7-a532-c0a459ad059c	Affects	\N	Affects		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bef07a55-902c-47ae-a8a0-d1a7644c89bb	AFFECTS	\N	AFFECTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
995f6518-35a8-4016-9c32-ed2e7073201b	AFFINITY	\N	AFFINITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
965daae6-984a-4adc-ba20-6038c585d7a4	AFFINITYPROTEOME	\N	AFFINITYPROTEOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd94af28-3ad3-44f0-a664-d224501036e4	AFFINOMICS	\N	AFFINOMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5cc5ddd3-badc-439b-b6b5-e329d101072b	AFFIRM	\N	AFFIRM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ad11fdf-541b-4d37-88ef-b50bbc3b569a	AFFIRMATIVE	\N	AFFIRMATIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cf8ae459-cce7-4fdc-a320-54eee58f2381	AFFIRMO	\N	AFFIRMO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51adfccb-25be-4d88-b537-d8558af62fb1	AFFMA	\N	AFFMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6dd9b97b-4409-422d-9510-debd4d4d26ff	Affordable5G	\N	Affordable5G		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
813d9195-dd7a-4451-b308-56731a1aa360	AffordBoneS	\N	AffordBoneS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c8313431-e3a3-41f0-867f-f774357a7c7b	AFFORDS-HIGHER	\N	AFFORDS-HIGHER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d6017ac-d01c-4ade-9f44-e3e8d9b0184b	AFHELO	\N	AFHELO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d39f9f7-e2db-4b7a-a577-eaab9901b3a6	AFIBROTIC	\N	AFIBROTIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c780539-12d2-442b-ab29-a9a634c6fd13	AFib-TrainNet	\N	AFib-TrainNet		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5f73a67-856c-4c55-a5ba-63f16db46f7d	AFINET	\N	AFINET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9d9f2854-6e41-432d-8237-733711196274	AF in Human Myocytes	\N	AF in Human Myocytes		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b80c98da-cb5b-43cf-8f8c-d0ca009a9c4d	AFIRMATIVE	\N	AFIRMATIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d33073c0-5325-4860-91f4-75608ebd174a	AFISYS	\N	AFISYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a2700f31-b5f7-4bb6-8a03-9f55e836df8a	AFLOG	\N	AFLOG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e576b66-5b01-409c-bcd0-ea7e9f4c0d79	AFLONEXT	\N	AFLONEXT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b424bb27-402a-44b9-b660-5dcdfed18cf6	AFloWTest	\N	AFloWTest		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0aaf307d-c297-4013-9f57-0e04acb8ce8e	AFMIDMOA	\N	AFMIDMOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
981175ea-fe55-4fff-ae5d-2838081e077c	AFNAP	\N	AFNAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
06037b21-e1c1-4e5f-8516-a5a7a6992f31	A-FOD	\N	A-FOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46810e21-f2b1-4005-8212-4aef60c5866f	AFOOT	\N	AFOOT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
786b3bf7-b55d-414f-bd46-2d225b7d17c7	A-FOOTPRINT	\N	A-FOOTPRINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b838b0b8-0845-40fc-a88b-e18d435dd1c1	AFORE	\N	AFORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e2e0509-824a-4b46-876c-28dea9f01bb7	AFOREST	\N	AFOREST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ed0b24d-9c3f-4323-811a-f8800f0a2a60	AFPMeT	\N	AFPMeT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd7acd7d-ca3e-4ea9-aaee-72f1d13b2c95	AFRAB	\N	AFRAB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8de8dc1b-4c17-4889-b33c-1ec018008f39	AFREELAMIDE	\N	AFREELAMIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76739033-4be1-42ed-a3ac-62fda66540d3	AFRESH	\N	AFRESH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
971f10cb-5bf8-4359-b760-6d71444d254a	AFREXTRACT	\N	AFREXTRACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54ba13e0-0c66-4129-97d0-da36dcd0ac8a	AfriAlliance	\N	AfriAlliance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2915c1aa-b5d2-456f-8178-3b682961d335	AFRICA BUILD	\N	AFRICA BUILD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5160b8ce-9c73-48df-9a76-50e421ab7d10	AFRICA-GHG	\N	AFRICA-GHG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c2b3aece-98ef-4bdd-a947-984d2bf607e4	AfricanBioServices	\N	AfricanBioServices		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35ddbda5-1e85-4fc5-977d-13091d282a4c	AfriCAN Climate	\N	AfriCAN Climate		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ab751a36-1865-4777-b341-f0c07f1af679	AfricanMigrantWomen	\N	AfricanMigrantWomen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4c3ab84b-ad79-4235-a7b4-4326a644c0fb	AFRICANMIGRANTWOMEN	\N	AFRICANMIGRANTWOMEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0818646c-884b-4f68-9159-7df39941a896	AfricanNeo	\N	AfricanNeo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73e6b0af-8f20-4ba1-8f89-3daf134bfb0b	AFRICAN TRAVELLERS	\N	AFRICAN TRAVELLERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
919d6c0f-7764-48d5-8e7c-2b7800606030	AfricanWomen	\N	AfricanWomen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
af3684a2-1902-4297-a36e-320231c8cbc7	AfriCoLeish	\N	AfriCoLeish		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
15d20860-4fdc-4edf-806e-aabfe396ba4a	AfriConEU	\N	AfriConEU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
11b70359-57d6-4662-9bbc-20d11150c1b6	AfriCultuReS	\N	AfriCultuReS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0998ac74-fbb8-4edf-9ede-108cf7f37f48	AFRIGOS	\N	AFRIGOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a52e8eb1-ccc4-458f-b06b-c1c16a3cb327	AFRISCREENWORLDS	\N	AFRISCREENWORLDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ff6a49df-cfd4-4777-94d8-254c4c89e195	AFRI-SKYFOR	\N	AFRI-SKYFOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
64fccae7-ce00-47cd-8a5d-47a4950d4b8a	AFRIUNI	\N	AFRIUNI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ccef645-51f7-4a74-b987-f3a468193180	AFRIVAL	\N	AFRIVAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7bcec608-3391-4847-9a81-400444a1435c	AfriVeg	\N	AfriVeg		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8fafe644-8418-4e69-a815-b660a38dfda7	A-FRO	\N	A-FRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6e890213-f818-4923-bfeb-fdc42ef68683	AFROBRIDGE	\N	AFROBRIDGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
16d6ef52-16e4-4d93-9294-2e4af700976d	AFRODITE	\N	AFRODITE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d282859-7f48-4a02-9eb1-40133b8f3427	AFROEUROPOLITANS	\N	AFROEUROPOLITANS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7f112cb9-8620-4fd9-a108-9d1527a0ffa4	AFROMAISON	\N	AFROMAISON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77cf6113-5e48-4cd4-a167-b4baf807d3ef	AFR-PD	\N	AFR-PD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22e982fa-a52a-4d4c-b6c8-1f996d69b8ed	AFR-POSTDOC	\N	AFR-POSTDOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
005af51e-b4b8-4307-af45-216019c15dd3	AFSIAL	\N	AFSIAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d97ea869-08fc-41c8-a113-895b0fc3a7e3	AFSID	\N	AFSID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
43798be4-f87c-4c4e-9999-a4c0ee1aec81	AFSJ-AGENCIES	\N	AFSJ-AGENCIES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cb31c460-966e-44df-a445-d9d8ddfe1c7e	AFSPAN	\N	AFSPAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7639022f-3b4c-48ec-8689-4e63eeb5dd0b	AFSPPEOAS	\N	AFSPPEOAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c8b83299-e1ea-4e76-8f14-86ea8e0d8cc2	AFTAT	\N	AFTAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46170004-9a90-44c9-b81d-9af3bd96bb0f	AFTER	\N	AFTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
57bd9709-d2c6-4338-812f-43a010dcac80	AFTERBIOCHEM	\N	AFTERBIOCHEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d62f7540-f8de-4ed2-b359-c33bb638cbb7	AFTERLIFE	\N	AFTERLIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a3b6318f-3bd8-4b68-8b44-e4904231722e	Aftermath	\N	Aftermath		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6a928b8f-3942-4f02-8d4e-278caed2461d	AFTERTHEGOLDRUSH	\N	AFTERTHEGOLDRUSH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e5742f3-1c9d-45fc-9a1a-1019880e10ff	AfterTheIce	\N	AfterTheIce		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05c6af39-d72e-476a-90b9-dd070d163f30	AGAGAP	\N	AGAGAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce9ff8d9-6e32-4caa-86d6-5ccf2081d30d	AgainstResistance	\N	AgainstResistance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
60687594-487a-42e4-951b-eaf043f2d589	AGALT	\N	AGALT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
debfe539-dd51-4b1f-b686-79088a2331c2	AGAME	\N	AGAME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d9672d65-1c31-4605-9bdf-56c9c5b0fb91	AGAPAC	\N	AGAPAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34c6c333-2c67-47e6-b06a-ae61d82762bc	AGAPE	\N	AGAPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
625c071b-6a65-4f20-acc7-1ed5c34c7cce	AGATE	\N	AGATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68d550b1-1e20-4e77-baec-5fcf918c3a46	AGATHA	\N	AGATHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf181dbc-2d02-4761-8950-f499f53cee31	AGATHOCLES	\N	AGATHOCLES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
57d81647-3f90-4f58-ae88-8c10b057dad4	AGATM	\N	AGATM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3807375-fb06-4032-a9d6-835c9271a0e6	Age Asymmetry	\N	Age Asymmetry		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89032d46-1c49-4608-8cfa-34dc5dc4d8e5	AgeCogCity	\N	AgeCogCity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5f88578-fafb-45fe-ad06-9989837734ee	AgeConsolidate	\N	AgeConsolidate		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cbf32734-12f1-432e-a59f-bf82994c6ebc	AGEDBRAINSYSBIO	\N	AGEDBRAINSYSBIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
794d80c2-75a2-4bc3-b702-0b18cb7b6063	AgedLGBT	\N	AgedLGBT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
239cc41c-9c76-499a-a128-771b91b661be	AGE-FRIENDLY	\N	AGE-FRIENDLY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ea271e6f-7fcc-49dd-bf5a-74384159587a	AGEING AND RS	\N	AGEING AND RS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51dd09f7-50e8-44a2-a33f-b02d22d3a4fb	AgeingatWork	\N	AgeingatWork		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bef7861d-d976-4957-bb11-ce3a8e358912	Ageing Network	\N	Ageing Network		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3880c7bc-6fa0-4739-985f-e12295e53419	AGEING PLASTICITY	\N	AGEING PLASTICITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e37eb5b1-012c-408a-9853-99e3b8d65c43	AgeingSexualConflict	\N	AgeingSexualConflict		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5bea3faa-514e-47ff-88c4-cda39f7562a7	AGEING SKELETON	\N	AGEING SKELETON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6858812f-fed3-46f1-8991-f3ec77de7238	AgeingStemCellFate	\N	AgeingStemCellFate		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fe817fdd-4aea-4313-8c03-a2d5e143ddba	AgeingTimeUse	\N	AgeingTimeUse		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5cc49475-415b-436f-bc30-c4f54ceba198	Ageing with elegans	\N	Ageing with elegans		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07293e05-f8f0-468e-89a6-3ebeca68ab26	AGEISM	\N	AGEISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ddfb7cb2-5fdc-4334-b05c-790dc5f72452	AGELESS	\N	AGELESS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c15c753-f175-4af2-9233-936e5ae0135c	AGELYSPARK	\N	AGELYSPARK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d7543aee-f8e9-42a1-9ffb-5dd533b01a9e	AGEMEC	\N	AGEMEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a6ef613d-f1b9-427f-aedd-e674515d15c2	AGE-MEMORY	\N	AGE-MEMORY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e14fd4f-7be4-4a50-a7ee-df24464afecc	AGEMERA	\N	AGEMERA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
15cb6a73-e525-4e5c-9073-a73f0ca3f5c5	AGenDA	\N	AGenDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f81d007b-0792-42a3-bf75-77afa4cbeb4e	AGENSI	\N	AGENSI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a362ffd8-a213-4f6b-aca5-c17f74aecb4a	AGenT	\N	AGenT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
10670354-242b-48fb-b859-382bf5311bdb	AGENT	\N	AGENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c47b2c3f-737d-4861-931f-84efeb2bef2d	AGENTA	\N	AGENTA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
49a22fce-a6da-46e3-9991-ea0be118f01c	AGEnTh	\N	AGEnTh		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00c9dee3-e44f-4849-8819-eac5ce55fb25	AgentSeal	\N	AgentSeal		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
33509045-1cd0-48d1-b2b3-7b8e2039ba5c	AGENTSEGET	\N	AGENTSEGET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c3976ed9-793b-4b4a-9002-6fcb7921479a	AgePhagy	\N	AgePhagy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a27de791-c52e-48f6-8d8d-cbb70f36ca6a	AGePOP	\N	AGePOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
779431bc-9bff-4e50-94ab-072af234302c	AGERISK	\N	AGERISK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae415a01-02c7-4c5b-9f40-75deb599fb9b	AGERPIX	\N	AGERPIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9fbdacb2-3f38-4358-b5c2-75185c6f8c68	AGESPACE	\N	AGESPACE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c65bd19-8fb2-4f9e-bc76-4a81be85b027	AGEWELL	\N	AGEWELL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c0a0de94-24f6-4704-99ca-ffd5c0c3317e	AGEYE	\N	AGEYE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
442c0d69-97f6-4ebc-bd9f-45aa37103c8e	AGF	\N	AGF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d2c80d6a-0584-450c-857f-249cc234657c	AGFOODTRADE	\N	AGFOODTRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6495676a-e454-4f19-a342-f6cda5d26667	AGFORISE	\N	AGFORISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e762d0b1-d0e5-4775-97a8-c5ddb9d87405	AGFORWARD	\N	AGFORWARD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3b417641-8537-41f6-bfc8-82b0849dde7f	AG-GF	\N	AG-GF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
63829719-9898-4df9-a99a-091ab9b43d7d	Agglomerates	\N	Agglomerates		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4dd64e90-fbd0-4692-98bd-b4d572a68f8c	AGGLONANOCOAT	\N	AGGLONANOCOAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7e85b6a-9070-45ea-a647-23d6cdde4656	AggregAT3	\N	AggregAT3		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1147e9f-9862-4151-8982-866045cf808b	AggregatingProteome	\N	AggregatingProteome		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
872cea71-650a-40f2-ba0e-89cbdb3418aa	AGGREGATION	\N	AGGREGATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c2152def-3c98-48bf-831a-82a7a9ca8c66	AggregationKinetics	\N	AggregationKinetics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
04085c63-f6f4-49df-9d30-6dacb6639ef4	Aggregation selection	\N	Aggregation selection		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
19c7cd1b-8a3c-4b48-968d-e4f25753a6cf	AGGRESSOTYPE	\N	AGGRESSOTYPE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0215a5c8-75f7-4eaa-9cf9-43a9a60af961	AGG-REST-WEB	\N	AGG-REST-WEB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
528135db-5495-4c5b-871d-0eece994bc8d	AGILE	\N	AGILE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d7f90954-9866-418f-a05f-1b10c69a1973	AGILE 4.0	\N	AGILE 4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1b37cd9-4c72-465f-bcf1-6f11a9e32257	AGILEFLIGHT	\N	AGILEFLIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
17631d9d-d644-4e08-947b-408041418763	AGILE-KWS	\N	AGILE-KWS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ac6297a6-669f-4270-9756-c9d8b85e476c	AGILENET	\N	AGILENET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
288b506f-228e-4566-b063-4abda050d9d0	agINFRA	\N	agINFRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3faf773f-ece9-41a1-a9d7-5649ec727919	AGINFRA PLUS	\N	AGINFRA PLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76304355-809c-4a96-9488-25813510ea6d	AGING_HORMONE	\N	AGING_HORMONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1035cbdd-a8ce-4e7f-b10c-5366d2430d36	AGING MATTERS	\N	AGING MATTERS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6a27b7ac-e7d2-47f1-8d3d-b896ed771523	AGINGSEXDIFF	\N	AGINGSEXDIFF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
24529a36-875f-4367-a99f-0ca813819c9d	Aging stem cells	\N	Aging stem cells		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a8438893-c77e-40ca-8fee-2959ef69cc68	AgingTimer	\N	AgingTimer		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c276f08e-3c01-477f-9901-38342fe2122b	AGINSURANCE	\N	AGINSURANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eac52dec-5d16-4733-91d7-12877030e6eb	AGITATORCBM	\N	AGITATORCBM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34d657b5-7c51-4e32-a09a-2540dcf51d70	AGLARIS	\N	AGLARIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
43859576-7e6f-4c24-905f-b12e8b7e4d94	AGLYC	\N	AGLYC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81d1b6f7-3b2f-4e88-bc2b-9907dcf1e212	AGMS	\N	AGMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
163126a9-8761-4cbd-bfc0-6f23cde1fd01	AGNES	\N	AGNES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f90591f-44fd-461d-aade-e820e88a5c11	AGN feedback	\N	AGN feedback		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
70efa070-d2a1-48d4-ab3c-3801dc6a580b	AGNOSTIC	\N	AGNOSTIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4091b1b5-361f-4320-bda3-b6530f0b82eb	AGNPROBES	\N	AGNPROBES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e623deba-7d2d-41e3-9d98-4ec3e750545d	AgoIM	\N	AgoIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7176ded0-9cb3-476c-a05a-28e1ac607d16	AGORA	\N	AGORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
285d772d-7b9f-4e3f-979c-189b5c151439	AGOras	\N	AGOras		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
16188369-c3ba-4ae3-83a7-c8f0e6d34c93	AGORAs	\N	AGORAs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
49fa535e-96ed-4845-9765-043e3c475ff3	AgPro4CSA	\N	AgPro4CSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
582e9745-2352-4d6b-b123-5f992f7b1b17	AGRAL	\N	AGRAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
80ee8e04-7d99-4469-8656-cc7c6d9e4229	AGREE	\N	AGREE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58bf0e2c-6a53-4371-838b-984a26a569b8	AGREENSKILLS	\N	AGREENSKILLS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77ce5087-e0b6-47bb-b695-32ac5115de9c	AGREENSKILLSPLUS	\N	AGREENSKILLSPLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0cfdf99-e984-4d85-b6ab-a886797b2f09	AgRefine	\N	AgRefine		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
85233b5a-7a2f-437a-8336-7ea1e1e9a258	AGRELITA	\N	AGRELITA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
60ced358-0633-460e-a1eb-89e9f0274018	AgriBIT	\N	AgriBIT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e3638e47-a593-442e-9441-07dec8ea4dcd	AGRICAB	\N	AGRICAB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
35a3235b-50e9-4003-8595-1d0285cfa934	AGRICADOPT	\N	AGRICADOPT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6307c6f2-4bf5-4f3e-aa58-033b3f25b0db	AGRICAM	\N	AGRICAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b073b51a-d64b-4a58-9fcf-c1619b319bb9	AgriCapture	\N	AgriCapture		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0276f26c-225c-46ea-9349-7ed9f96e4af8	AgriChemWhey	\N	AgriChemWhey		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4a60e741-4387-4033-903a-f8ff9efe92fa	AGRICISTRADE	\N	AGRICISTRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1ff12f61-f240-445f-8119-55d8093e78ee	AGRIC-LASERUAV	\N	AGRIC-LASERUAV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c6ee1515-5cdb-40c1-8c6b-64dc1fa8e1da	AgriCloud	\N	AgriCloud		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1fde70e2-4024-401a-8f4f-f58b505b1874	AgriCloud P2	\N	AgriCloud P2		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42e31eeb-e506-4572-b09f-0d56f834b3f6	Agricolus DSS	\N	Agricolus DSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
23fb3603-eeff-4e4b-a9df-63abb3f9b9ce	AGRICON	\N	AGRICON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2124cc38-683a-430d-9358-ed9d44acab6e	AGRICORE	\N	AGRICORE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
72f02366-1735-4b19-bfa0-b96f982ca3c7	AgricUrb	\N	AgricUrb		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ef23aca7-237d-497e-bbcf-e407ce1d87d5	AGRICYGEN	\N	AGRICYGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cd06b730-b2bb-4e73-95a3-2703603d5da9	AGRIDEASCOURSE.TRADE	\N	AGRIDEASCOURSE.TRADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c13b9a8-9b8f-4dd7-b9ca-0a4be649e2e0	AgriDemo-F2F	\N	AgriDemo-F2F		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ca815f83-77c9-4d06-9d96-df4d8d91c6f6	AGRI-DRONE	\N	AGRI-DRONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47e5b684-6dfd-4d76-a0a9-8eff344cd670	AGRI-ECO SERVICES	\N	AGRI-ECO SERVICES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2972e0de-af58-4e31-85a0-5c0bf67ee82f	AgriFoodBoost	\N	AgriFoodBoost		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
41282acb-0578-490c-929b-55a99fdeca70	AGRIFOODRESULTS	\N	AGRIFOODRESULTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bb58e3ad-3061-47dc-95fa-df89eb9c675b	AGRIFORVALOR	\N	AGRIFORVALOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f2079a81-d543-4050-8d0d-730c6915aef9	AgriLink	\N	AgriLink		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6763835d-1995-43d4-a416-7ebc3596f237	AgriMax	\N	AgriMax		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f239666-4a92-432f-b9d9-be0970a7d015	AGRIMKT	\N	AGRIMKT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ac699c8-8eb3-42a3-967f-0d8389129156	AGRINA	\N	AGRINA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26ba07ee-b820-42e4-b6c0-f270f0b1ea6a	AGRINUTS	\N	AGRINUTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3baf219d-f8be-4ef1-91e4-aa255ee9287c	AGRIPOLICY	\N	AGRIPOLICY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
240e2187-9e92-4892-9614-1e9c722a1952	AGRIREFORM	\N	AGRIREFORM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b58b26fd-1231-4ac2-932c-ed0429fd10ac	AGRISAFE	\N	AGRISAFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a512ff47-d5dd-4add-bdb9-523cd30a2c46	AGRISCENTS	\N	AGRISCENTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d2531b9c-48fc-4d89-8d6c-47a2abe7d6fa	AGRISCIMONT	\N	AGRISCIMONT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
14bd1da5-4567-4467-990d-274f7e61180a	AGRISENSACT	\N	AGRISENSACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58882894-e245-4895-a561-d905129f931c	AGRISPIN	\N	AGRISPIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e429bd9-d89e-44cc-9824-7a3a26dd1a66	AGRIWESTMED	\N	AGRIWESTMED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b9177a05-c354-4569-9da5-7fae07b56ceb	AGRIXCHANGE	\N	AGRIXCHANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0fa546e0-9627-4c5f-a755-f6ed363dd3b6	Agro2Circular	\N	Agro2Circular		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
41826e20-2b14-4549-adaa-d54d5c4b7902	AGRO-AMF-AOX	\N	AGRO-AMF-AOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9b5099e9-37d5-473a-9c57-e2fc35bdccbb	AGROBIOFILM	\N	AGROBIOFILM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
693a1150-fab2-4ea0-a48f-841dc41e7b52	AgroBioHeat	\N	AgroBioHeat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3b2788f4-6ffe-449d-9789-fc7b5cb27152	agROBOfood	\N	agROBOfood		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7dfcc844-aa5e-4eac-a522-5b54a602d494	agroBRIDGES	\N	agroBRIDGES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
847529c2-ead5-465e-a735-2e461d437457	AGROCLINICAL	\N	AGROCLINICAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
68d4ccbc-40eb-4582-b5c5-0fb1845e9ff4	AGROCOS	\N	AGROCOS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f617ddb-7b3f-41ff-9668-eb31ebcf21cc	agroCYAN ECO	\N	agroCYAN ECO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c35b55b8-c680-4509-bc29-eca4c41751a1	AgroCycle	\N	AgroCycle		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2a4cc33e-04f2-4857-9df6-3821615f8f8d	AgroFossilFree	\N	AgroFossilFree		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77859e3c-1c36-43c3-8888-496241e1306f	Agro Highway	\N	Agro Highway		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7b73f0cc-5cf1-4949-b728-5c4af2574dcf	AGROinLOG	\N	AGROinLOG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1142491a-9722-4b08-a2a2-62bd5662dfed	AGROMIX	\N	AGROMIX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dde091e9-f22b-4304-83a7-e71af90e31ba	AgroPellet	\N	AgroPellet		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
168215f1-bf2b-4163-922e-46b36edc696f	AgroPestAlert	\N	AgroPestAlert		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1b8d9ef-1f68-4b98-8aab-fada2e9299e9	AgroPHYS	\N	AgroPHYS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
de552052-1d05-4bce-b3c3-eef023251db0	Agroptima FM	\N	Agroptima FM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ac6f33d4-a5bb-4fd6-ab8f-17f936fe5050	AgroRadar	\N	AgroRadar		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1c63c545-001d-4aa6-bf7a-70be68178cfe	AGROSENSE	\N	AGROSENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b5ac6d5-33f9-4bec-9459-155cdd99729b	AgroShelf	\N	AgroShelf		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
db12b08c-9c33-4212-a1d6-78334f4d5982	AgroStore	\N	AgroStore		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0e059512-0a5d-45fb-983c-aafcbd134b5c	AgrowFab	\N	AgrowFab		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8c8e6a0-168b-46f6-957c-9560c0a48328	AGRUMIG	\N	AGRUMIG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07fdad40-acd8-4cf2-92ff-6f647892487e	AGS	\N	AGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
def69780-2443-46f4-9aa0-52f959426ba0	AGTECH	\N	AGTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c43f5ba0-97a6-4cf6-8901-104d88a639b2	AguaSociaL	\N	AguaSociaL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f510fbaa-8c7f-4880-b1cf-80c5d9eeb785	ahead	\N	ahead		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
33176798-2467-4bd4-9c65-fad405dbe07f	AhEAD	\N	AhEAD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e5033ab4-e86d-4bf6-9580-3391de7311c3	AHEAD	\N	AHEAD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ed8679da-f639-4ec2-826a-ddd1dc433365	AHEAD2020	\N	AHEAD2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5652e65-30c6-493f-a8da-d278b13fee6a	AHEAD III	\N	AHEAD III		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3b749755-21cb-4575-b602-45f087b81741	A-HERO	\N	A-HERO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b743baf1-ae6e-44ad-81bb-b3ad95e9788a	AH-GCOLSYM	\N	AH-GCOLSYM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
be20df2e-d9e3-44cb-8bbd-ee4bc7da2eae	AHH-OMICS	\N	AHH-OMICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
375990c2-7aaa-4045-9e0b-084739ea416b	AHICA	\N	AHICA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
460cb956-e9e9-43be-bbf5-d2a6113d2d24	AHPACS	\N	AHPACS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c50365b9-09ff-42b3-afd5-55fdd99fd945	AHRIMMUNITY	\N	AHRIMMUNITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
20f99223-5a4c-47f3-a787-f93994addf09	AHUMSCIENCENET	\N	AHUMSCIENCENET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9502bec-f279-40c5-b2e8-8aee7f1b4dca	AI2AM	\N	AI2AM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
56088e6b-9d06-479e-95b0-3da956364473	AI-2 Prodrugs	\N	AI-2 Prodrugs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
10160614-cb89-4bd8-9931-31d448050654	AI4Cities	\N	AI4Cities		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
97d29ea7-0889-4f65-8c83-0c6d63fe2e03	AI4Copernicus	\N	AI4Copernicus		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f5980e7-7b09-4468-93b2-801d8f2cfe8e	AI4CSM	\N	AI4CSM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
443f3b83-c1b4-463d-b2f5-38e8aa2d731a	AI4DI	\N	AI4DI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4fdd9a9e-e2fd-4cab-8ded-f3ffd56317c2	AI4Dignity	\N	AI4Dignity		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
53bd1675-50ea-497b-b5fd-82e5aab9f9bf	AI4EMS	\N	AI4EMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a4f0721a-1fa7-4761-bb70-75847007bfb4	AI4EU	\N	AI4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ab0b403c-9f9d-4192-aab4-cd0c6a011acd	AI4HEALTHSEC	\N	AI4HEALTHSEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ea018b35-3ce2-4bc5-ad5f-af7c577e898c	AI4LABOUR	\N	AI4LABOUR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
87cced25-d9ce-4df4-9d7d-bd779bfa34f4	AI4Media	\N	AI4Media		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9fdfecb-4e89-40f3-8bd7-f5228d2f06d9	AI4PublicPolicy	\N	AI4PublicPolicy		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d957e877-8db2-43de-8be0-b5430a465ba3	AI4REASON	\N	AI4REASON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7e70fa0a-0cba-41ed-aa37-c8743ac03457	AI4SmartCities	\N	AI4SmartCities		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
11d9166b-0b00-47fa-9335-c6d44e67cedd	AI4theSciences	\N	AI4theSciences		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
73d68167-55fe-444e-af01-481663423d06	AI-ARC	\N	AI-ARC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7bfbc830-3e2a-4d52-bb4e-574062503ca4	AIAS	\N	AIAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c51cf52b-22dd-4acb-807b-aea7c96533a5	AIAS-COFUND II	\N	AIAS-COFUND II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c20913c-529c-4da4-bdcf-a45aa83ed2d8	AIASGA	\N	AIASGA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13b3d15b-a242-43b0-805f-bad1ce486ffa	AIatEDGE	\N	AIatEDGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0f42e3fb-aaad-4831-bc15-ef7dbc33e6f4	AIC24	\N	AIC24		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e8857927-6373-49c1-a6fb-1abb42b3f4a0	AICCELERATE	\N	AICCELERATE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
124c0f82-4182-4cbb-8e0d-d65b85c1af2c	AICE	\N	AICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e987e9f2-721e-44c2-ae8d-cc06b7e9e06c	AICHAIN	\N	AICHAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
079b1306-6ccc-4182-a560-2b132b213de0	AI-CU	\N	AI-CU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
750de902-b9cb-4de6-941e-de29fc367a7a	AI-CUBE	\N	AI-CUBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0989cf2f-9e58-4e21-9eba-5bb7b6229292	aiD	\N	aiD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6a7ab566-b882-476a-978e-23a79b5a02d3	AID	\N	AID		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b2e4b02c-90e6-45a8-b6c0-e436198b23c4	AIDA	\N	AIDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bbf13450-e75c-442b-8d34-df22af81e9d0	AÏDA	\N	AÏDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c2ce3823-6e73-4efc-b20d-f7d7ced6b4f3	AIDA-2020	\N	AIDA-2020		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ab47cb2f-acbd-43f6-83be-f373f61d97f4	AIDAinnova	\N	AIDAinnova		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00cc3f18-b52e-4e21-abd6-b07187e17d9c	AID AND BEYOND	\N	AID AND BEYOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
749c8b00-68e1-4e71-bac5-5628021a8256	AIDD	\N	AIDD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8467daa9-5128-41af-991d-6766938b45da	AIDE	\N	AIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3ea245ba-808f-41d7-a67d-e478610b7b2b	AIDEAS	\N	AIDEAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f7ce3295-6643-432e-afca-2e315dcece9c	AI-DEMON	\N	AI-DEMON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b9fba43-d674-4990-84bc-f6823aeca750	AIDING THE NEGLECTED	\N	AIDING THE NEGLECTED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
54416cb6-2fb6-4600-aa73-a69d7e896361	AIDINMENA	\N	AIDINMENA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bbe18715-27f8-4081-a749-79a6ca2076af	AIDOaRt	\N	AIDOaRt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58ce1ab4-e9e3-4896-80df-7aa868530a7d	AIDPATH	\N	AIDPATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd482299-1a66-4d48-8b6f-22dd22bf968d	AID Recruitment	\N	AID Recruitment		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
891db46d-bd04-4fdb-a8ab-d08c1322fd87	AIDS AND MIRNAS	\N	AIDS AND MIRNAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
31fc7545-2bc7-4859-a547-517bc48264c0	aidsocpro	\N	aidsocpro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
531191c4-2530-4655-ab5c-b00c26c2527b	AIDSRIGHTS	\N	AIDSRIGHTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a593b722-fff5-4dae-8a86-c1b2ef4ba7ee	AIDSsilences	\N	AIDSsilences		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3f344461-5c4f-4563-9134-12b3d86852c9	AIDViC	\N	AIDViC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b915658-8691-4fcb-99c2-daea59de4066	AIE-RTP-PLED	\N	AIE-RTP-PLED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fc2f5988-7a0f-4196-aa7b-642b654713aa	AI-FIE	\N	AI-FIE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1c2e629-a6b2-46c8-8ebf-f50c8f387a97	AI for a faster web	\N	AI for a faster web		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bf276534-75f4-4491-8683-fb151f22ae62	ALARP	\N	ALARP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f04b7db0-a3df-4a36-8d72-6392a446baff	AiforCancerDX	\N	AiforCancerDX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dca37085-7bc2-4982-8d43-2f986c5277c1	AIFORS	\N	AIFORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92c175a8-75b1-419f-bc07-4e84f585843d	AIRBEAM	\N	AIRBEAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
683c6f36-9ab7-4bc9-b869-d148fd3e05e0	AIforUTracking	\N	AIforUTracking		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3a5278b8-ff67-4b06-b1c9-a497212e7497	AI-Inspect	\N	AI-Inspect		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0a85be0a-3ecc-497c-b565-1fbbb353325b	AILAS	\N	AILAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d170618-feb3-4d42-99f7-133c64475dfc	AIM	\N	AIM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98ed6c1c-8d85-43e8-99f3-dedec40bad77	AIM²	\N	AIM²		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d5b9ac9-c230-446d-a457-9a4ad2e63cf7	AIM2 INFLAMMASOME	\N	AIM2 INFLAMMASOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0ae60c31-7f98-4fd0-91e5-c572c221000c	AIM4NP	\N	AIM4NP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1da544e2-daa8-4600-aa8d-8f4c2df90c76	AIMACS	\N	AIMACS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8224a1fe-93ca-45ab-8fcf-7d13b598e2b0	AIM_COACH	\N	AIM_COACH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c105bd7c-5ae9-41c3-b944-085ef7011dad	AIME	\N	AIME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
17d3b045-5f73-4b32-b388-45eb174e9107	AIMed	\N	AIMed		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bb9adafb-f32c-4dd3-8f6a-01b761cb33b4	AiMeRe	\N	AiMeRe		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6216cd96-fb01-4826-87f9-93ccff79b3cd	AI-METHOD	\N	AI-METHOD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b769438-aacf-410b-9bec-41351d42b64b	AIM-HI	\N	AIM-HI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aff10ea1-a57d-4b52-a924-61b14c4fcd6f	AIM-HIV	\N	AIM-HIV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
355583c0-4bd0-4e91-9a48-af95ffce591e	AI-MICADIS	\N	AI-MICADIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d491fc1f-df31-469e-b590-dbf7f4a77f8e	AIM.imaging.CKD	\N	AIM.imaging.CKD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e9c7bc2c-f626-4579-bff6-f671c772e626	AI-Mind	\N	AI-Mind		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71bd13f6-c9b7-467b-9bb5-dc1976b2ec69	AimingT6SS	\N	AimingT6SS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6730257f-ca9b-4998-9bbe-d855da64460b	AIMMS STAR-PLUS	\N	AIMMS STAR-PLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
728c9cdf-8c6f-452a-903b-876d5d1b428d	AIMS	\N	AIMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6cc397b7-655f-42b0-854e-deed2b108493	AIMS-2-TRIALS	\N	AIMS-2-TRIALS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6cf9e9d6-7b3d-45f4-9e43-62e78d056248	AINARA	\N	AINARA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bae533ea-a907-4291-b99b-a4ef8a6dd5f5	AINIGMA	\N	AINIGMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
36866eb8-3257-4f17-a2e9-c34989553149	AIOSAT	\N	AIOSAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1e6bd5e-45d8-4731-b67c-3c734f3a2a70	AIP1918	\N	AIP1918		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6667646d-8113-4186-8ae9-29f21c44ccac	AIPACA	\N	AIPACA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dfff3358-1e7c-4fa9-b577-53dc383e6155	AI-PATH	\N	AI-PATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c9abef2a-d5a7-4106-8a96-01e8d8957f7d	AiPBAND	\N	AiPBAND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3129a12b-919a-426a-9595-2d0a16c1e089	AIPGENE	\N	AIPGENE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
afcb7993-3dfa-4345-9af6-a88c1d945efd	AIPlan4EU	\N	AIPlan4EU		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
69cdbd79-6b70-41b5-b673-3bacc32d857e	AIPM	\N	AIPM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9af2218-fa99-4c21-bc8f-12cfebc59024	AI-PREVENT	\N	AI-PREVENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ecc81b75-1399-4b15-bdc7-6c33b0d55ee2	AI-PRISM	\N	AI-PRISM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
46d09485-bd88-4f98-938c-d75f6d8d077d	AI-PROFICIENT	\N	AI-PROFICIENT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b839fe1-9b0d-4453-a6ba-44a61227e830	AIR	\N	AIR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e4913430-9366-4186-acc0-57b111943ce5	AIR3D	\N	AIR3D		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1458c2b4-afa3-428f-851c-d5a1359fd0b1	AirBorne	\N	AirBorne		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b67cf6b5-5bf4-43d6-8663-c588ea27b75e	AirBrush	\N	AirBrush		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6199f344-8051-4c60-b209-81e78caaf38b	AIRCARRUS	\N	AIRCARRUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce453f7b-b975-4f11-9595-99122c7392b2	AIRCOAT	\N	AIRCOAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9fafd291-8735-4ab4-a22e-dd245164120d	AIRSHADE	\N	AIRSHADE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c13218a-b745-4c5d-9fb3-18049df58c7c	AIRCRAFT DECON.	\N	AIRCRAFT DECON.		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
579fbf59-807f-450c-8a14-29b927c6cd69	AIRCRAFTFIRE	\N	AIRCRAFTFIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
efdb1df9-dd6a-4e7e-9d09-68fec23dfae1	AIRCRANE	\N	AIRCRANE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df9978f6-67dc-45b7-931e-fa61f9f7a27a	AIRDNA	\N	AIRDNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1b238474-8cd4-441a-aa75-340f48c34f95	AIRE	\N	AIRE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c13314fd-bc79-48d2-ae63-f895c5083261	AI REGIO	\N	AI REGIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6013b236-b29b-4b8f-a42f-dea54d13e368	AIRE-TOP2A	\N	AIRE-TOP2A		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55fa5991-5030-430c-a419-6ae25ef848a3	AirEx	\N	AirEx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a46cf273-d36e-49f2-8620-c2e949f70830	AIRFIELD MONITOR	\N	AIRFIELD MONITOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
906b81ee-90cb-4206-85c3-1ccbdb8b1fe2	AIRFORS	\N	AIRFORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21a62ed6-f0e6-44a0-83f2-69529c8e1bd8	AIRGAL	\N	AIRGAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
84466367-8fbd-4d58-9024-70f254b3bfb4	AIRGENEX-food	\N	AIRGENEX-food		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
97e9aba6-c40d-4ab3-b4aa-a5aae33fe66a	AIRIMGO	\N	AIRIMGO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b2c4c9c0-9cec-49bb-97aa-db8fabfcd9a6	AirKit	\N	AirKit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b4c60c9-b439-4985-861e-8919ffe8c62d	AIRLINES	\N	AIRLINES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8b6223b-edb5-4357-b564-166674feabeb	Airline Team NCM	\N	Airline Team NCM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f2e5a82-2ac2-4b9e-8bc6-e288a19c6445	Airline Team xStream	\N	Airline Team xStream		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47c8a8a4-5945-4995-af79-58fd3b59708a	AIRLITE	\N	AIRLITE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
914bf54b-55db-4ae1-bbd1-90bcf132c856	AIRLOG	\N	AIRLOG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e266236f-0cf6-4202-bcdc-df647de472c9	AIRLOOM	\N	AIRLOOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cb23656f-4bf1-4639-83a5-d5c8aba308b1	AIRM	\N	AIRM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b324f9ae-e769-430a-87de-57f67ff61555	AIRMED	\N	AIRMED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
362c12ec-2387-465c-b3b6-7d35c927d06b	Airmee	\N	Airmee		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0dc835a5-24da-4325-a4ac-3d60dccc8c4a	AIRMES	\N	AIRMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bffe0db6-ab2d-44ba-a42e-3f3767677ec1	AIRMINWATSFG	\N	AIRMINWATSFG		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2327e988-b12f-446b-ab8c-89ebe85ee5ad	AIRMONTECH	\N	AIRMONTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6dcf8b23-6a6a-4a47-956c-11031a431761	AiRMOUR	\N	AiRMOUR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
34eb58a4-a02a-4551-97fd-c66bbe35b666	AIR-NB	\N	AIR-NB		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c671b48d-851c-4181-9091-e311d3f8f58d	AIRobots	\N	AIRobots		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3689cdb2-7654-4ea9-a4e3-bcc895976139	AIROPICO	\N	AIROPICO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ccdfaff2-260b-49a3-a0f9-0ad382d965e7	AIRPASS	\N	AIRPASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5ce6c262-48bb-4f69-bd25-9dad4a77e957	AIRPATH	\N	AIRPATH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26ea8f13-ad1c-4198-b04e-3175e924a8b9	AirPlatform	\N	AirPlatform		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ca01a929-4609-463b-8213-358753390b78	Airport IQ	\N	Airport IQ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2429becf-3f0f-4442-8d96-0a4c0caa281f	AIRPOXY	\N	AIRPOXY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d8fd619b-54fa-4c95-83b3-8c8a8129d3db	AirPROM	\N	AirPROM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89f9950b-54c4-4908-b815-0a09e342fe32	AIRPURE	\N	AIRPURE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22245c97-4bd3-4923-af3e-cb58f8e0c59e	AirQast	\N	AirQast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ffa5900f-7ea6-4b8a-abe8-c5dd26bc3fe2	AIRS	\N	AIRS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6878ba4a-d61d-4a0b-939b-ec8622bbc41b	AIRSCAN	\N	AIRSCAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
424bff7e-c172-4f8b-9725-ce78a7e59cfd	AIRSEA	\N	AIRSEA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
da4ed705-f64c-4e7a-928c-e5bdede6031f	AIR-SEAL	\N	AIR-SEAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b323fe35-71fd-4a69-9898-559d50ff17c0	AIRSEAL	\N	AIRSEAL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ad06b655-42c2-4c3d-8ace-4911308c04c3	AirSens	\N	AirSens		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b894f088-dd91-426b-a217-a9b0efc0406f	AIRSHIP	\N	AIRSHIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9387241-4939-428d-bff1-0db07c21a376	AIRSKIN	\N	AIRSKIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d9d9862-100f-414c-9899-e5ca42ccc5ab	AiRT	\N	AiRT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78c46d44-1a08-43f8-88a4-638a0754635d	AIRTN	\N	AIRTN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2af169af-5edc-45c3-be68-58c598d51dc1	AIRTN-NEXTGEN	\N	AIRTN-NEXTGEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
74ae834f-6dd4-40c8-b979-bf0aaf0a4455	AIRUP	\N	AIRUP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0814ab4d-f959-461c-92bf-f6db69876be5	AirWatt	\N	AirWatt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4f966c99-aa67-4bc0-aa9a-beca5137eed0	AIRWAVES	\N	AIRWAVES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d49c9522-7969-4ed9-a582-a63a237111c7	AIRWISE	\N	AIRWISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00b58a1d-e116-4c1f-a664-3cb7fa0ba5c8	AIRX	\N	AIRX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71568656-87ef-43f8-bd08-42e1777376e3	AISA	\N	AISA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5bff6ba6-45e6-44c8-8b88-2db38c4deb09	AISAT	\N	AISAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4ef4307d-3afc-4368-acc4-a3c8ed169601	AIS-CaP	\N	AIS-CaP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ecbc7834-ee84-461d-8df9-2f2a6dfb3845	AIS-DC	\N	AIS-DC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81cc9531-3b6d-4663-a6fe-b91514d956ff	AISENS	\N	AISENS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
416c64ee-fac7-4209-8095-f8ac97c68758	AISENSE	\N	AISENSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
63d966b0-b4c6-4d5e-839a-9f0aebfc3731	AISHA II	\N	AISHA II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47ae627e-75c2-4a4c-9826-032daf581862	aiSim	\N	aiSim		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0101f2f-78ab-4719-aebf-9b0dbde60905	AISJ	\N	AISJ		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
095c33b3-43cb-4ccc-a4f1-cceee30357a1	AISLES	\N	AISLES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21237747-38f3-4754-99f8-518930b7b7bc	AISMA	\N	AISMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55f45a4c-3316-48e2-a3f0-48a49851bec0	AI-SPRINT	\N	AI-SPRINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae92103e-65e3-41fe-91cc-3407291d6bf1	AISS4SME	\N	AISS4SME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
59e62cb3-5fa8-4d8c-ab52-7c89d0dc214a	AISTREAM	\N	AISTREAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5397d29-a8e4-4771-a4cb-f4b3d0769f15	AITEP	\N	AITEP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
93c1a9fa-f121-4a30-9505-fd990451dd47	AI-TRAIN	\N	AI-TRAIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9d17bb1-bb6f-49c5-ba05-464ca33d17f6	ALCH	\N	ALCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
86c69cf7-fdf9-484e-b90b-2bdcddf57dec	AI-TWILIGHT	\N	AI-TWILIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d9b1c38-1ea8-4a5e-ad51-1b111a2524e4	AIVA	\N	AIVA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8598320b-cd62-4345-b75b-45e0e7001ed0	aiVision	\N	aiVision		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cbb486e0-6254-416d-9b92-461f9338e0d1	AIx	\N	AIx		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3be25ad4-6b8b-4761-98f7-34515242e6a0	AJ86RH5GYM	\N	AJ86RH5GYM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b2026a1-a537-40d4-90a1-9952611b0ba3	AJAPP	\N	AJAPP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92b14366-b178-4381-bb73-6f2d07af13c4	AKMI	\N	AKMI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b9cb0b63-e734-4ce9-be22-2e89aa0dd613	Akselos Integra	\N	Akselos Integra		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3356420c-9f9d-466f-be07-d0ac10a31d53	AL4BIOCH	\N	AL4BIOCH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d070017-01f4-489d-a789-72c2ab4df967	ALABGM08	\N	ALABGM08		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
21e56919-b530-4e86-9778-26c1d65bd648	ALABO	\N	ALABO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05e07294-f98f-4979-acc9-d39d47ce9b97	ALACS	\N	ALACS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d9d888eb-e079-4267-8c1d-ef48ff416596	ALADDIN	\N	ALADDIN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
58b071ef-df33-44eb-acfa-45e799a460be	Aladin	\N	Aladin		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40e0c9cf-5443-47af-939f-07cecc511fd6	ALADS-DS	\N	ALADS-DS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc6a6b58-03d9-4879-abb3-0bfb0685a87c	ALADVS	\N	ALADVS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
997f0a6b-1b43-4304-90e3-4c55948573c4	Aladyn System Ph1	\N	Aladyn System Ph1		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
621840b5-7987-49fe-9e0e-68fc5fa4d378	ALAMEDA	\N	ALAMEDA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6e312d06-78d6-40c4-9deb-012e24a7a5aa	ALAMSA	\N	ALAMSA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
00664b73-4b2e-46c0-956a-2c7455b97491	ALARM	\N	ALARM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
585aae1b-92f4-4ee4-ad3b-3a0d9c8128bd	ALARTE	\N	ALARTE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8aeca9d4-7a08-4872-97c0-526aba36bebc	ALAS	\N	ALAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7c19f79a-9dbe-4970-9aaa-13cdb51e0bf1	ALASCA	\N	ALASCA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
85c1a64b-9813-49bb-9bc6-330fdba9d268	ALATA	\N	ALATA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a807a8af-3e47-4d34-a1cd-ea1ee98afe99	ALAV	\N	ALAV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
80c07aae-a65b-4d0c-8995-84e45a188471	Albanian diaspora	\N	Albanian diaspora		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eb1523c2-6232-4d28-a1cc-fda99ef95732	AlbaSolar	\N	AlbaSolar		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d26591d6-e784-4541-aacf-2ff38ce41f27	ALBASPECIALISATION	\N	ALBASPECIALISATION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c851d5f3-18e3-4b8d-8665-1c10de8e34c3	ALBATROSS	\N	ALBATROSS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8bbd7b55-b947-4a93-b0b4-414ffdc6e599	ALBICAN	\N	ALBICAN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3dd19936-c671-49c6-a5be-dce8ece189df	ALBIMEH	\N	ALBIMEH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
442b2350-5320-40dd-8017-3283264cc2d6	ALBINO	\N	ALBINO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98482d30-c741-4f05-998c-01424ec1e505	ALBORA	\N	ALBORA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e04346a-97f9-46bf-b4e5-e3f9df2a4aeb	ALBTUSMED II	\N	ALBTUSMED II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40a9a776-125a-4336-805a-7d44a3e25c0e	ALBUGON	\N	ALBUGON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
db943cdc-a26b-4267-acc9-31e5b8bae60c	ALC	\N	ALC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
182bc964-553c-4956-bc05-d5ba903ef714	ALCAMS	\N	ALCAMS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3a377dac-ea07-493c-8c77-d50adc58fd82	AlCat	\N	AlCat		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
154bd80f-2da3-4057-b784-d0f3513d5a2a	AlchemEast	\N	AlchemEast		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f846200a-2829-4dbc-a4b5-e15387b6ce8e	ALCHEMVIENNA	\N	ALCHEMVIENNA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e1820b43-6074-4234-9ef4-2f5d2f5e41f6	AlchemyML	\N	AlchemyML		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
09268359-6e21-4f4c-9950-a830bc8cb906	AlCHIMIE	\N	AlCHIMIE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8b4b3c06-5bf6-4019-b931-65e387ac2c52	ALCLASS	\N	ALCLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3d616090-7d93-4da0-bb51-0e6d841106e2	ALCO2-FUNC	\N	ALCO2-FUNC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d4befc5-8862-46a9-94aa-06b4f62ef8fb	ALCO2HOL	\N	ALCO2HOL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6a9916e9-0562-4518-9b85-b8df57b2cd77	ALCO-ADO	\N	ALCO-ADO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f793394-1480-449c-8e7c-07cecdbd4639	ALCO_CAMK	\N	ALCO_CAMK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d46a07f-5036-4aad-a624-c62ef8819974	ALCOHOLLIFECOURSE	\N	ALCOHOLLIFECOURSE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fc022e75-5934-443b-97b4-a9bf240bbb70	ALCUE-KBBE	\N	ALCUE-KBBE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b202061e-7acb-40d2-b79c-46ff84dfc767	ALCUE NET	\N	ALCUE NET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3a68d76-95c6-4592-b56f-a25c19e9e6f2	ALD4PV	\N	ALD4PV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5636adbf-1329-46c5-b99c-67895919a11e	ALDing	\N	ALDing		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d989ecb-1944-404b-a3a2-030253c9fce3	ALDof 2DTMDs	\N	ALDof 2DTMDs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dda6b420-003b-4167-ad7f-d1ebf8bd8109	ALDREN	\N	ALDREN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
23bad74d-9d1b-4858-a876-51bba74222de	ALDrone	\N	ALDrone		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6efb6e3b-c5a6-4ee1-b671-39d31d9be436	ALD-SPUTTERING-OXIDE	\N	ALD-SPUTTERING-OXIDE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
13133833-eec5-44e0-9e8a-5068d54afd2c	ALEA	\N	ALEA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2e88f9d0-aa9a-40f2-85fe-782ecffd9c77	A-LEAF	\N	A-LEAF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c4da16cf-31a0-4f21-a69e-7b3efb82541c	ALEAR	\N	ALEAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c23b3e40-5202-4074-aaea-d7f8e4e196d0	ALEC	\N	ALEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9fad3bcc-1eaf-4fe7-9c81-2179f05d1016	ALECS	\N	ALECS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd80202b-bead-4c39-bf2e-09414cf33537	ALEF	\N	ALEF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a1235ad2-6664-487c-b6bc-cfe70891d6e2	ALEHOOP	\N	ALEHOOP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76494922-a6f9-40de-8eb2-16b00bab8aeb	ALELION	\N	ALELION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
175abf86-681f-4863-8e4a-1da1445c75f1	ALEM	\N	ALEM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cd443c60-3fd3-40e6-9a68-7b923b8e38ba	ALEPH	\N	ALEPH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd289f12-c158-40a7-993d-94b5340dd40e	ALErT	\N	ALErT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d803622d-a1ce-4173-961c-27320a54cef5	ALERT	\N	ALERT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ddf84be2-be1e-4d0d-923c-2fc43897987b	ALERT AND FOCUSED	\N	ALERT AND FOCUSED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8c8ae4b-47e2-4462-aaad-1cbe881733cb	AL-ES.NET	\N	AL-ES.NET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
05752422-e2e9-440a-a35f-15512ac16608	ALEX	\N	ALEX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f669381e-8ac8-4b43-8ba9-c5103250cb9f	ALEXANDER	\N	ALEXANDER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
478dec36-75cb-4f39-a8d5-673750d5c3f9	Alexander Krauss	\N	Alexander Krauss		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8ea3c7e2-22a8-4b72-988d-194c1e1ecabf	ALEXANDRIA	\N	ALEXANDRIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9350a7f2-5f54-4c21-a6f2-2245e4ff96ed	ALFA-BIRD	\N	ALFA-BIRD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1e5cdf7d-3a9d-470d-845b-08b29dcf1cae	ALFALFAEVOLUTION	\N	ALFALFAEVOLUTION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6836bd9f-b66c-4c60-ae8b-3995d4e6f97b	ALFAMA	\N	ALFAMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ab7d4d70-61ee-47fe-ad07-e206e859a8be	ALFAwetlands	\N	ALFAwetlands		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
af0473b0-eee4-40f7-9620-03bba786bfe2	ALFF	\N	ALFF		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1325e96-146d-4892-8109-b1ce6fc44c59	AlFHoNSo	\N	AlFHoNSo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0b97e036-3bc0-4683-8d86-95a0618c9cfc	ALFOAM	\N	ALFOAM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2fb287c0-3b11-4d5e-b330-74d832bb6481	AlForAMA	\N	AlForAMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8c96ada4-0f73-4be3-b134-345be7070e1c	ALFRED	\N	ALFRED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f49c6899-8ad2-4289-847d-702b9d3cfd44	ALGABOOSTER	\N	ALGABOOSTER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f9641eaa-138e-406d-8c94-873094eeb2ad	ALGADISK	\N	ALGADISK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e4301e46-464f-436f-a77e-0d738f0a3c94	ALGAE4A-B	\N	ALGAE4A-B		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3be9c18d-c959-4b3d-9cca-a0ece53a485b	Algae4IBD	\N	Algae4IBD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f3cf1acb-2b6c-48eb-9ec6-8d28948e3809	AlgaeCeuticals	\N	AlgaeCeuticals		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
18b72f04-22b4-4311-a468-d0c9fc34c15a	ALGAECOM	\N	ALGAECOM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f1886a7-bd88-4333-a1d2-1d895ce1a06a	AlgaeFLOAT	\N	AlgaeFLOAT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
29f7adeb-1c8c-4117-8bb4-57c9ed261bba	ALGAEMAX	\N	ALGAEMAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
70b4a445-309b-4c15-ae0a-1f9cdf7c148c	ALGAENET	\N	ALGAENET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c0060340-705e-473b-8d60-47f013756acb	ALGAEOILSYNTH	\N	ALGAEOILSYNTH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6380f5dd-97c1-458f-bdd2-5d25afc83e37	ALGAEPRINT	\N	ALGAEPRINT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aa67f8b1-acb5-479f-9ed6-8b6938c810cf	AlgaHealth	\N	AlgaHealth		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c7e415c9-2e07-4817-b42e-78612861518f	ALGALVANISE	\N	ALGALVANISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c70e4e5-4ccb-405a-98e1-cd18d676b775	ALGAMATER	\N	ALGAMATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c8f51b12-cfb4-4b67-a231-931c2d063609	ALGAME	\N	ALGAME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7ded7ab2-1b85-48e4-bbc3-a69c1a74a32e	algaPLUS	\N	algaPLUS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2a1a72fa-7f6d-4bda-8704-02a3d22ffb10	ALGATEC	\N	ALGATEC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce405a01-2d6b-4ee7-a4e8-93f9cf7d0dfd	ALGATEC II	\N	ALGATEC II		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2e71c47c-31b3-4ca6-92d2-5401a732092a	ALGBACT	\N	ALGBACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4d726eba-5002-4701-8856-2aa94092e71a	AlgCoustics	\N	AlgCoustics		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7c72385d-6cb8-4d0e-8c13-3a9d7b09cc58	AlgDates	\N	AlgDates		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8bc9d9b0-cb7d-4d5b-911e-4e41edf35ba0	ALGeSMo	\N	ALGeSMo		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f80fa4c1-cec6-4e5a-a9f0-4b6436e820b2	ALGETOX	\N	ALGETOX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dbb4bd8c-7ed3-4847-a19e-b525068697ee	ALGFUEL	\N	ALGFUEL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
44114bc5-d0c7-445c-8492-fdac2fc12191	ALGGENOMES	\N	ALGGENOMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dadcafaf-ca72-44a2-852f-f3bb4a6bbcc9	ALGILE	\N	ALGILE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7d4de8e-d95f-4bd9-9241-72c764a7ce0a	ALGLASS	\N	ALGLASS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1e9cc765-c1bf-4716-a728-59e771db7bd8	ALGOA	\N	ALGOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8e376e73-fda4-4915-b7f9-16135ce6ae63	ALGOCERT	\N	ALGOCERT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
43c26bb7-a741-45d9-9be0-02d41faae338	ALGOCom	\N	ALGOCom		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e117c5b6-1c31-4fa7-b525-1b05b28be15a	AlgoFinance	\N	AlgoFinance		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
062a2b7d-1272-4862-be31-7d093f276d2a	Algo-Grid	\N	Algo-Grid		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3bf05bcc-0102-4413-a2e8-69ecd4c819f3	AlgoHex	\N	AlgoHex		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7ee90721-28b1-4f08-b2f9-7d1e0c9c01d6	AlgoQIP	\N	AlgoQIP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
caa635b0-f999-415f-812e-55cc3203ef23	ALGORITM	\N	ALGORITM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6136faa1-b425-4c4e-9537-6bc8355045e8	AlgoRNN	\N	AlgoRNN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3602ba02-fe21-47d8-8548-4183841be0ae	ALGOSOC	\N	ALGOSOC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f2ee67b6-8b7e-4206-9439-8df2bd2aea08	ALGOVIS	\N	ALGOVIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
40c9c4f3-2a18-49eb-badb-c8e9dd4dd921	AlgSignSen	\N	AlgSignSen		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0c9077f4-ccb6-43e7-8d80-5bf1c252be3f	ALGSTRONGCRYPTO	\N	ALGSTRONGCRYPTO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b309a8cb-1fe7-4d63-aa3c-4bcbeb23868b	AlgTateGro	\N	AlgTateGro		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9380633c-e626-462d-857c-b79f18df273e	ALGWAS-BIOR	\N	ALGWAS-BIOR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7bceec9-ffc3-4b9c-825d-046e24e20fbb	ALH	\N	ALH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
07e35220-bfd3-46ef-a9c2-188698641329	ALHIS	\N	ALHIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae1871e9-f4e6-4b63-896f-b2f96cbadcab	ALHOME	\N	ALHOME		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3ebcf778-707a-4a30-be39-a71efa53b67d	ALHSOLAR	\N	ALHSOLAR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3fde4cf2-e750-40ff-bf41-9bb48fce5527	ALHTOUR	\N	ALHTOUR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eb6d8489-1dc7-471b-88f8-87732f24cfcd	ALIADA	\N	ALIADA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
41dca494-2729-48d3-985e-aed6af038b01	ALIAS	\N	ALIAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4eb00750-cb2b-418c-bfd6-8103148483e5	A.L.I.B.I.	\N	A.L.I.B.I.		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3846c235-bc63-4260-9fbb-de3ae87de5cd	ALICANTE	\N	ALICANTE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
560ba22a-5800-481c-8a2b-ddba1d831cfe	ALICE	\N	ALICE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd17d9d0-1548-49d7-bb48-624a7b0ccaca	ALICE RAP	\N	ALICE RAP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
db3926de-92db-42af-9f4f-a8b74541fff3	ALICIA	\N	ALICIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
45e2d8c0-cdbb-4183-b38e-e8ae7d6aa814	ALiEN	\N	ALiEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
042a7889-c920-403b-8117-6c3517e83df6	ALIEN	\N	ALIEN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81015bc3-02fb-4f2c-8382-07455ac644e4	ALIENC	\N	ALIENC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b0e39fb8-05e3-4b81-9a3a-47470e04aa5c	ALIENFISH&CLIMCHANGE	\N	ALIENFISH&CLIMCHANGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55ca1229-066f-456f-a9af-2c35b63458f0	ALIENIMPACTS	\N	ALIENIMPACTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fcc61629-58b3-44fa-9c20-2274cb710783	ALIENinSoil	\N	ALIENinSoil		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d7e355e-eae6-4a40-89cf-9ab94433ca19	Alien Species	\N	Alien Species		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b2d5930b-7653-4238-a619-9681a59fb6bc	A-LIFE	\N	A-LIFE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cc2f63e5-4696-464d-a4ba-13458de6e5b6	ALifeInSOFCs	\N	ALifeInSOFCs		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8e773447-c3c5-4e49-99ed-048347663e97	ALIGHT	\N	ALIGHT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77d98b94-f297-4ccb-a7ea-670d6a492fa3	A light on vision	\N	A light on vision		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8df769a-035f-4fa1-be5d-704b9a22b892	ALIGN	\N	ALIGN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c272ef75-ab91-4c6b-8374-472ecb16d743	ALIGNED	\N	ALIGNED		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f1941e9-fe5f-4e9a-a8b2-dc76b961368f	Aligned e2e	\N	Aligned e2e		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd6511ed-fffd-4b74-9be4-1404665a309c	ALIGNER	\N	ALIGNER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b88fa806-b886-493f-89c9-20e5060895a1	ALIGNING MINDS	\N	ALIGNING MINDS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8393bdcb-3eb3-44f0-afc9-6a7295a721cd	AL-IN-WON	\N	AL-IN-WON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
411c527b-cdaf-48f6-a231-df603dde220a	ALION	\N	ALION		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
661026ba-e657-4110-846f-9914d8b8cebe	ALIPS	\N	ALIPS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
98444e28-5a66-4108-ac7c-b6a44d382fe6	ALIS	\N	ALIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4e2ee0fc-552f-4d03-a600-d0a0035764f7	ALISA	\N	ALISA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b1b69c2c-4c3f-4746-b9fa-80aeb9d9f0ed	ALISE	\N	ALISE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
48befb99-79d6-4985-8c42-cae1f199ccbb	A-LITHIA	\N	A-LITHIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d3b4d569-9466-463a-beee-f5a7ca75bf28	ALIVE	\N	ALIVE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9d85759f-042f-4bfd-9859-86355a55f4e4	ALIVEAfrica	\N	ALIVEAfrica		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67745709-e513-4afc-a9f0-ba6eb5bcc6d7	ALIVER	\N	ALIVER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9014a615-1fd8-485d-9a49-d29d45b661db	ALIZ-E	\N	ALIZ-E		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6349c864-01c8-45d8-917c-26a41cec1f19	ALK7	\N	ALK7		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
31a1c828-418e-461e-a351-0c7cab3d4a09	ALKAGE	\N	ALKAGE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f4dd1d26-1e27-4523-88c4-fa6e90e6ae83	ALKAMMONIA	\N	ALKAMMONIA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6206c71b-9323-4633-9557-32ff0f4b57e4	ALKATRAS	\N	ALKATRAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eecef464-92ec-46a8-b02e-a58bc9181f3f	ALLODD	\N	ALLODD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
25cb8b26-f7b4-4272-818a-c74aa0ad0080	AlkenesToAminoAcids	\N	AlkenesToAminoAcids		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a85a3118-b476-4804-a320-67c12bf196e2	ALKENoNE	\N	ALKENoNE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
340de540-7449-4d86-bde2-fabb83739c56	AlkFood	\N	AlkFood		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b508d2bb-3d75-44b3-8050-94bf9df91d6c	ALKVAX	\N	ALKVAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e58560fb-055c-4294-a1ab-0af7746eb774	ALL	\N	ALL		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
af7af4e5-7b69-4ad6-bde3-0127680390f0	All4Green	\N	All4Green		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b31d4c82-f27f-4da2-916d-459ea6e3fb8c	ALL4REST	\N	ALL4REST		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
75aa0cd6-3bef-4022-92ae-092cb0d33bbf	ALL4RESTgo2MARKET	\N	ALL4RESTgo2MARKET		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7fb4b71c-f48b-4b16-ac91-393266695b91	All-Atlantic2021	\N	All-Atlantic2021		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
41de2d4d-445f-43a6-b403-cf66e191b746	ALLBIO	\N	ALLBIO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
61687d64-685f-45b5-9197-ef2899f3cfa4	AlleeMod	\N	AlleeMod		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eef20569-7ccb-48b6-9814-55965db0e73d	ALLEGRA	\N	ALLEGRA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
827427ef-f181-4f45-993c-74507f0cae01	ALLEGRO	\N	ALLEGRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cfb4bf00-4b2b-4aa3-91b6-a8ade57cdded	ALLELECHOKER	\N	ALLELECHOKER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7f973595-23b0-49cf-a4e4-9a6363912aa5	Allelic Regulation	\N	Allelic Regulation		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e15a59c0-d6af-423d-a73f-3f4855062e28	AllergenDetect	\N	AllergenDetect		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c68ad14-6290-4057-929f-ef20978c36e8	ALLERGENE	\N	ALLERGENE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d22aea74-1340-40fc-9201-b715bc65f373	ALLERGUT	\N	ALLERGUT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b6f549ed-315c-4a21-8040-548b58c020c4	AllergyBLOCK	\N	AllergyBLOCK		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2e174e8e-a396-41fb-8ef7-3a18c2a7e231	AllergyExplorer	\N	AllergyExplorer		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9cb83ec3-b5da-43ad-a1e4-0b3549d29808	AllergyVAX	\N	AllergyVAX		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
67aa5e58-4453-46ba-a4d9-7e7af8af8bfe	AllerScreening	\N	AllerScreening		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
50c051c3-eb20-4937-b7a8-3f39ba8edd30	ALLFUN	\N	ALLFUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2ea5fe25-c31d-4d17-947e-b05f13f3680f	ALL-GAS	\N	ALL-GAS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22a25cce-0eaf-41d8-aa0b-ec7eee1cec29	ALLIANCE	\N	ALLIANCE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fed04154-516c-4e8f-a520-e29b8b5d348e	Alliance4Life	\N	Alliance4Life		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
47a4c06b-5280-457d-a0b3-950f6421a57c	ALLINTERACT	\N	ALLINTERACT		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d4583b8b-5490-4b9d-a30b-a049bcd7bcd0	ALL-IN Zero	\N	ALL-IN Zero		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b218f2dc-cfd2-417e-854f-4722bdb1e5b0	ALLNIGHTS	\N	ALLNIGHTS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a56dd1f9-2614-4a60-b58e-7a94843fa025	ALLOCHRONY	\N	ALLOCHRONY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
609c5513-3c80-4efa-bfbb-90cb55bc5b0b	Alloem	\N	Alloem		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b698eae0-71fd-416a-a26c-af79e3d84af6	AlloGPCR	\N	AlloGPCR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6d689a2f-c08a-4b96-85ff-2ef5db3544ec	ALLOPLASM	\N	ALLOPLASM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
363e9ae5-3535-4466-a31a-cdb6f0a836a1	AllOptHIPP	\N	AllOptHIPP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
865effb1-ed1b-4efc-b867-76946f2994a8	ALLOPTICS	\N	ALLOPTICS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
53d03272-c6fa-4680-adb1-25e1f70ec442	ALLOSERGON	\N	ALLOSERGON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8da96441-4917-4665-8e70-37099a8e403e	Allosteric-CRISPR	\N	Allosteric-CRISPR		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
679f0449-6e15-4ac2-9bd1-f0d82c624790	Allo-THYTECH	\N	Allo-THYTECH		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f12a5f92-6f11-43f5-9b4d-11170cfcc09f	Allow	\N	Allow		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d142b95-60db-4836-85cc-014627a1e5e7	ALLOWE	\N	ALLOWE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9873b456-ab8d-4956-ab26-b7fd53deceae	ALLOW Ensembles	\N	ALLOW Ensembles		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3814840-c827-425a-8d35-26023ae3ccc3	ALLOXIDEPV	\N	ALLOXIDEPV		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f7a38f3-973e-4575-8a95-16f9c21247b7	AllOxITD	\N	AllOxITD		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81450053-d631-4bcd-a7b4-1e0602abf09c	ALLQUANTUM	\N	ALLQUANTUM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77ef2565-222d-4340-b33f-907879c2fa85	ALL-Ready	\N	ALL-Ready		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f30cba75-d05b-4d70-9db7-fcfe7a71c5d7	ALLRUN	\N	ALLRUN		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
406a1213-f01b-4a6e-aebc-efd187b83761	ALLScale	\N	ALLScale		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
667c5024-7dee-4482-8a78-0bf678fda2f6	ALL-SMART-PIGS	\N	ALL-SMART-PIGS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
87468adc-2fa3-4ba2-838c-b3df710bb382	AllSteel-SRetrofit	\N	AllSteel-SRetrofit		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9f3100d4-986d-4efc-83b1-55a5a4f3e15f	Allthings.bioPRO	\N	Allthings.bioPRO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ca9cbeed-ab01-40bb-ae50-c99ef45453f1	ALL-TIMES	\N	ALL-TIMES		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
df4c3a1f-28dd-4611-b47a-32084bee3823	AllYours	\N	AllYours		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f8881572-9934-4e04-bf20-8eaff2164169	ALM	\N	ALM		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e0ce4e0d-a7bd-4eb3-b606-ce98ffd50e48	ALMA	\N	ALMA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1d9d89b-909a-417a-8b49-2d034edaadfb	AlmaCrypt	\N	AlmaCrypt		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd5832a1-edd1-491e-a80f-e5d48bc9f044	ALMAGIC	\N	ALMAGIC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c28e6147-e8f3-47bf-9db9-28818b19a612	ALMA-MATER	\N	ALMA-MATER		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0cfcdec0-db8d-4812-842c-0010702d0056	ALMANAC	\N	ALMANAC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d987e2ac-6abd-4307-a45f-af625746e610	ALMARVI	\N	ALMARVI		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76511f98-55e7-4ff2-994b-5d85ac9c04a8	Almazara 4.0	\N	Almazara 4.0		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
55869c94-34c7-40a5-9361-04a1afdd51fa	Al-medicare	\N	Al-medicare		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8adee904-66ab-47ba-81e4-fa7c091656d5	ALMOND	\N	ALMOND		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3aede679-4778-4d9e-963c-af5eb683e206	ALMP	\N	ALMP		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
029d0b4a-1f28-469b-a9c5-11c6cfdc1860	ALMP_ECON	\N	ALMP_ECON		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c8f3eb25-937d-4a29-bbeb-7f6c649c1320	AL-NANOFUNC	\N	AL-NANOFUNC		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
490329e8-e24a-43b0-8ae9-584e81768093	ALOA	\N	ALOA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d5a82931-afc8-4c4b-b08e-3b7620c14f80	ALOEco	\N	ALOEco		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
01edc171-1a73-4ba2-9891-28b06f9dcf54	ALOE-DIVERSITY	\N	ALOE-DIVERSITY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e434a273-6639-4078-a5ee-0990f634bb73	ALOGLADIS	\N	ALOGLADIS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
385c6ffc-d376-48c8-aee2-b4dbfd1fe31a	ALOHA	\N	ALOHA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1aa048a5-319d-4b50-aabd-d2f6c2a2e5d8	ALOHA TORINO-SYDNEY	\N	ALOHA TORINO-SYDNEY		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8c230655-92e9-48a5-b2f0-018ffd614471	ALONE	\N	ALONE		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6660c207-af87-4fab-b69c-3dfdd78f7d47	ALONOCO	\N	ALONOCO		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9f42f5c0-dc5e-4186-81d3-6790923f27c6	ALORS	\N	ALORS		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d531022-6330-4d6a-97df-8a0433743bd9	ALPaCA	\N	ALPaCA		acronym	projects	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
74ff33eb-7d95-4580-9bc7-9dff3bcd03e8	AMU	\N	AMU		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
406da45a-0453-42a3-9cd2-a4b5fff5085b	Barcelonabeta Brain Research Center	\N	Barcelonabeta Brain Research Center		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e29085fb-76c1-4242-9f8b-d9bd9ff01dfe	Barcelona Digital Centre Tecnològic	\N	Barcelona Digital Centre Tecnològic		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b90dc4b7-86c3-4a3c-bc78-74c1d2dcdaab	Barcelona Graduate School of Economics	\N	Barcelona Graduate School of Economics		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
90585708-73cd-4edc-b3d2-d8bb78fb9bba	Barcelona Institute of Science and Technology	\N	Barcelona Institute of Science and Technology		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
94dbc0f0-a500-4339-9d02-4491b2e6df8c	Barcelona Media	\N	Barcelona Media		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
91099751-dca6-4f73-b5d1-31690725e9da	Barcelona Supercomputing Center - CNS	\N	Barcelona Supercomputing Center - CNS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
66d0ae54-7d77-40d6-811d-be8d02adcbfd	Càmara Arrossera del Montsià	\N	Càmara Arrossera del Montsià		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
52428a61-9794-4161-854f-d2ee60234b7c	Cambra de Comerç de Barcelona	\N	Cambra de Comerç de Barcelona		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a580d9bf-a112-4dc9-96de-344e0536574f	CELLS - ALBA	\N	CELLS - ALBA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
991533c9-910f-461c-aeba-93f87e3ccf1f	Centre CIM	\N	Centre CIM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d56e1d20-09bc-4e33-b257-901f797833f7	Centre de Recerca en Agrigenòmica	\N	Centre de Recerca en Agrigenòmica		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e61d940d-84d2-46e3-bbf6-7d2891345c92	INSA Lyon	\N	INSA Lyon		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b8fa0c15-c35d-4115-9699-f370abb6b69b	UCA	\N	UCA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd7681b6-de2c-4ade-bc95-f6ca403758f6	Centre de Recerca en Economia i Desenvolupament Agroalimentari	\N	Centre de Recerca en Economia i Desenvolupament Agroalimentari		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5b2765ac-3307-49cd-938b-1b869490a4ea	Centre d'Estudis Demogràfics	\N	Centre d'Estudis Demogràfics		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e7da27dc-1775-4e93-b5ee-c3e2c688c13a	Centre d'Innovació del Transport	\N	Centre d'Innovació del Transport		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
51355aac-9bc2-4e78-b7d8-e43db926293a	Centre d'Innovació i Tecnologia de la UPC	\N	Centre d'Innovació i Tecnologia de la UPC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2c7414f0-aaef-4f98-b541-c931c105e86e	CNRS	\N	CNRS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
324cf9a8-ab62-44b6-8678-2271ce2494eb	CTM Centre Tecnològic	\N	CTM Centre Tecnològic		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5fd55d2-423b-49cc-a566-becf93ec6cf1	EC Lyon	\N	EC Lyon		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f78162ba-794d-4747-b5d8-b17b24f996e8	ECP	\N	ECP		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77335eb0-4995-4dfc-873b-9f7d7f921524	EFEO	\N	EFEO		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
772cd635-1881-4d3e-aed2-0304590690c1	EHESS	\N	EHESS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a8adcac6-61b9-4100-9a32-d4d2740b7bc3	ENC	\N	ENC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
76f03686-dfb9-4402-8541-c5ebf1038061	ENPC	\N	ENPC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ce00f8d8-278a-4066-8c5b-5aa5bd1ec41d	Ensad	\N	Ensad		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0322bca6-1f02-445b-bde1-a365b1efd544	ENS Chimie de Paris	\N	ENS Chimie de Paris		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6c330541-8f2d-4966-bd42-c86ad4fec93f	ENS de Cachan	\N	ENS de Cachan		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26896572-00e3-42c4-8ac8-d3916f13e29f	ENS Paris	\N	ENS Paris		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3309b9c2-9d27-4c0f-82c9-b1cfb546afc6	EPHE	\N	EPHE		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f655eade-9476-45b8-a8e0-e7adc0417968	ESPCI	\N	ESPCI		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12b1d4e6-299f-4244-8fa9-259beacad02b	Fundació Barcelona Mobile World Capital 	\N	Fundació Barcelona Mobile World Capital 		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e052b8a3-5944-4c3c-84f2-0976a0941a53	Fundació Clínic per a la Recerca Biomèdica	\N	Fundació Clínic per a la Recerca Biomèdica		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
be0bbcb3-0dfb-4b5c-bdf1-bfab7dda9978	Fundació guifi.net	\N	Fundació guifi.net		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b3a49210-c40a-4c89-9e9c-f1e4fbfa3b01	Fundació I2CAT	\N	Fundació I2CAT		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ae6f8bad-d232-4911-8c90-e76899b2c64d	CNI	\N	CNI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0ab9d87e-5159-4cd9-861f-169012d18cfd	Fundació La Caixa	\N	Fundació La Caixa		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f83dfaab-ac88-44ca-93d0-a23d1c669558	Fundació Pau Costa	\N	Fundació Pau Costa		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b4997ee3-78c8-4413-89fc-265c90a2b5ea	Fundació Salut i Envelliment	\N	Fundació Salut i Envelliment		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7d41f285-83d1-49c0-88b1-c3f5a11c0d08	Hospital Clínic	\N	Hospital Clínic		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6844640d-0aac-43e4-ac18-fb387a9c35c1	Hospital de la Santa Creu i Sant Pau	\N	Hospital de la Santa Creu i Sant Pau		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e6fb0731-5dfb-4e01-bb5e-cb3e47080952	IDIAP Jordi Gol	\N	IDIAP Jordi Gol		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6b8c4866-284f-4690-91c1-a0aedf708037	IEP de Paris	\N	IEP de Paris		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0fb7420a-8b87-4575-acb2-08b219a93668	INPT	\N	INPT		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
298493ab-4f0a-4e44-9620-a2c0f81caae2	Institut Barcelona d'Estudis Internacionals	\N	Institut Barcelona d'Estudis Internacionals		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5ec87594-3217-4315-a0fa-55507a6ea92c	Institut Català de Paleoecologia Humana i Evolució Social	\N	Institut Català de Paleoecologia Humana i Evolució Social		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1278bb05-cf36-4607-b7d7-08e601cedfff	Institut Català de Recerca de l'Aigua	\N	Institut Català de Recerca de l'Aigua		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
22689b0b-c28d-4743-aed0-bf745cd39f02	Institut Català d'Investigació Química	\N	Institut Català d'Investigació Química		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d2cb18d-4fae-4f26-aeea-4abf6b6e33c9	Institut de Recerca Biomèdica de Lleida	\N	Institut de Recerca Biomèdica de Lleida		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
162002fe-4c94-450f-be78-e3dd56b881a0	ULCO	\N	ULCO		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f85440e9-eb07-452f-aa74-1451b80b5cbc	Institut de Recerca de l'Energia de Catalunya	\N	Institut de Recerca de l'Energia de Catalunya		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a23c27ea-b30c-4ce2-a3d0-92d5d4119efc	Institut de Recerca de l'Hospital de la Santa Creu i Sant Pau	\N	Institut de Recerca de l'Hospital de la Santa Creu i Sant Pau		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
39985f56-a034-4c5f-bba7-56141af624ca	Institut de Salut Global de Barcelona	\N	Institut de Salut Global de Barcelona		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b83bf121-efab-42b5-aab3-dab071861f3a	Coordinator	\N	Coordinator		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fe65540c-0884-4cbd-866b-0127038b6cae	Institut d'Estudis Espacials de Catalunya	\N	Institut d'Estudis Espacials de Catalunya		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c2613f18-64f7-4fd4-b926-4317a4c59bdf	Institut d'Investigació Oncològica Vall d'Hebron	\N	Institut d'Investigació Oncològica Vall d'Hebron		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
587a6ce5-9020-42f7-969a-96ddef37d880	Institut Guttmann	\N	Institut Guttmann		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e381cfcf-f231-4fad-aa29-8948a00d48a0	Interarts	\N	Interarts		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c1e88ebb-362e-4658-81b9-3b3d0dd1593c	KimGlobal	\N	KimGlobal		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1977d94c-4113-45e9-b97b-7f3176b4096e	Participant	\N	Participant		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bfa87754-4677-40c5-8e7f-44972b96bfbc	Leitat - Technological Center	\N	Leitat - Technological Center		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c4ca19aa-7be9-45b4-97da-2f7a77fefc49	Mines ParisTech	\N	Mines ParisTech		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b1a4fd16-994c-4bdb-a8d8-cc48a3e316d5	Parc Agrari del Baix Llobregat	\N	Parc Agrari del Baix Llobregat		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d37946a7-bc2a-467a-89a6-f3a38327bf18	Parc de Recerca UAB	\N	Parc de Recerca UAB		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
71d39895-6390-4f9f-9042-217c06719744	Parc de Salut Mar	\N	Parc de Salut Mar		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4b767194-4712-49f3-aae2-79867cca0d56	Paris-Dauphine	\N	Paris-Dauphine		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d1f7f86-bc53-4a1a-befd-04cbb7cac134	PRES ParisTech	\N	PRES ParisTech		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3c36725c-fe95-4f6c-a5ca-9c78b1361e25	PSL	\N	PSL		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d6e26d90-f91d-4c81-8c64-bb131d861a8c	UBM	\N	UBM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
4e4843e4-6b2d-4a4e-a2ed-b3773a96e567	UBO	\N	UBO		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
93029008-88b9-4917-8efa-e151ce9cf7a3	UBP	\N	UBP		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
69f02988-f1aa-4d96-9f9a-66c1e2b0625f	UBS	\N	UBS		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
83cdab2e-9baf-48ed-8d48-733fd250e866	UdA	\N	UdA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9216be74-36fd-4c2a-9305-8949d81f5251	UDL	\N	UDL		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dc609d30-a5ae-4fc7-a3fe-e86ffacec8a4	UFC	\N	UFC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3ba82031-444e-4980-a268-3a3c8c70f9ac	UGA	\N	UGA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
26edbc17-edd6-4e3c-9ecb-e057c4b126fb	UHA	\N	UHA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6ff7f780-8c52-4aa6-8fee-710210aa516d	UNÎMES	\N	UNÎMES		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
952419a3-9f1f-418e-95a0-816eed181a76	Universitat Politècnica de Catalunya	\N	Universitat Politècnica de Catalunya		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ad6c98f6-d965-4239-a34e-421ecfaf89a6	UPE	\N	UPE		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
42ac0881-d927-4e4f-a1a9-8938d7d9082e	UPEC	\N	UPEC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1bbb2435-ac77-4a86-9cdc-074241af9063	UPEM	\N	UPEM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
78deb2f8-db42-4411-b376-c869fb13079a	UPJV	\N	UPJV		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
094e0269-e4b5-4c05-8c38-8d7f12b0a30f	UPMC	\N	UPMC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d9bdda6-9907-4765-a9dc-c5bf1b079430	UPPA	\N	UPPA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cfe0245f-d302-49c2-bc67-3d4d02e129b9	UPV	\N	UPV		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
32c2eff3-a691-48b2-86b3-95053b21e5e3	URCA	\N	URCA		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b6da97b9-ed0d-453b-8169-739d6582e6d4	USTV	\N	USTV		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
daff94b3-7748-4b16-bbfd-515ba35e81b2	UTBM	\N	UTBM		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
958a7835-60ec-4fd7-94c9-84ed89d4e986	UTC	\N	UTC		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8d266db4-d718-4ae2-a366-1e0167875fa7	UTT	\N	UTT		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0e9eba6c-9721-4c2a-a2b0-94b873e9b223	X	\N	X		short_name	institutions	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0f146e36-9ecb-42c2-a62b-50b9f984d90c	Beneficiary	\N	Beneficiary		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9f340749-e61b-4ff1-9349-343a93bf5720	Host institution	\N	Host institution		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
afd9de21-e8a4-4778-9a62-211d98879b9e	CNC	\N	CNC		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
12f14bc0-d046-4895-9d16-ce829ed1ecb6	International partner	\N	International partner		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
17ac9c0e-d15b-4334-ac83-245d9819def5	Third party	\N	Third party		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fece5852-2573-43af-9c01-089220eb4b05	Partner	\N	Partner		description	project_member_roles	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0cd2fd5e-a6af-46ed-84c4-9cc337e71da7	169	\N	169		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a4377da7-c8a9-4af6-9987-42aa04f2e43c	ACM	\N	ACM		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a9aa265d-4653-4498-aa35-99dd76beb0d6	ACT	\N	ACT		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c70c96b4-6347-4200-8011-6f9c5ee8e634	AM-SSA	\N	AM-SSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b342ad95-0b78-4cf0-9a1a-07a6dce25374	ART169	\N	ART169		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
114c829e-e695-4d3e-ae85-2071fbea471e	BBI-CSA	\N	BBI-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
01da1cbc-4b63-4503-afd2-c97d4bdd5c54	BBI-IA-DEMO	\N	BBI-IA-DEMO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f05494e3-77bf-476d-8339-60babafc287d	BBI-IA-FLAG	\N	BBI-IA-FLAG		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5a5212bc-aff1-4b46-95a0-7cd1889573e5	BBI-RIA	\N	BBI-RIA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a98f9ec2-961c-4a8d-a1c7-7f4d0bbfc88b	BPN	\N	BPN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2aeb10f3-fbcc-4678-a9bd-aca6755871af	BSG-CSO	\N	BSG-CSO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
bd53fa09-189a-4166-8572-a62a9ec8c61a	BSG-SME	\N	BSG-SME		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b6d5f474-13b2-4dff-86de-937824eb2c67	BSG-SME-AG	\N	BSG-SME-AG		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e95a30f3-e165-48be-8892-6a7b7c365a52	BUR	\N	BUR		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e7bba28c-9d1f-4c20-85df-f76008cf7999	CAREER	\N	CAREER		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9378ab9c-04b4-4559-8e43-489e22754b6a	CIP-EIP-EI-PMRP	\N	CIP-EIP-EI-PMRP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1af1b779-1424-4dc0-b78f-0a2c03fae890	CIP-EIP-EI-TN	\N	CIP-EIP-EI-TN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5a20cd0e-a384-48b3-b31d-7252055dd598	CIP-EIP-EI-TNS	\N	CIP-EIP-EI-TNS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f78f9ff-85a7-4e70-a15a-84bc4a374dd3	CIP-EIP-SPA	\N	CIP-EIP-SPA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
370f6eee-652a-4401-9435-5d5d52e4fa5c	CIP-EIP-TN-EI	\N	CIP-EIP-TN-EI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0d030557-365d-47e7-b2f3-7e88fd46f631	CIP-EIP-TN-PIE	\N	CIP-EIP-TN-PIE		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
81c3bec9-daa4-45f2-8281-9999a8c0bec9	CIP-ICT-PSP-BPN	\N	CIP-ICT-PSP-BPN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3e21cc26-8f74-471c-8825-3a60278b510f	CIP-ICT-PSP-PA	\N	CIP-ICT-PSP-PA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a77a7525-62fe-4657-a703-034f26ed8598	CIP-ICT-PSP-PB	\N	CIP-ICT-PSP-PB		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a5282ecd-d42d-4a9d-9fcd-da4aeb7fd94b	CIP-ICT-PSP-TN	\N	CIP-ICT-PSP-TN		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
92fcb147-3e9e-439d-9629-b368109867f1	CIP-ICT-PSP-TN(EC)	\N	CIP-ICT-PSP-TN(EC)		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
018eb6b4-a74d-4037-ac57-3d5eedffccfd	CIP-IEE-MRP	\N	CIP-IEE-MRP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
aebb0fc4-56f3-4b98-a02d-5ae08e9f9e98	CIP-IEE-Promo-A	\N	CIP-IEE-Promo-A		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a0297655-ba3a-49bb-acd8-361ec72a1054	CIP-IEE-PROMO-BWI	\N	CIP-IEE-PROMO-BWI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ed2e15dd-3d13-4257-8ccb-e8d210412c4d	CIP-IEE-Promo-P	\N	CIP-IEE-Promo-P		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9f391fe3-5641-458b-974f-b120cad2f16c	CLR	\N	CLR		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2080e795-83c8-455c-b8c1-4e9fbe836c3b	CNI-SSA	\N	CNI-SSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3377fe63-ad1b-482f-9632-c28061e13d35	COFUND-EJP	\N	COFUND-EJP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5f11c75b-e394-4c34-b56f-5240278b54b0	COFUND-PCP	\N	COFUND-PCP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
dd91aafc-8476-4fca-a5de-12caea1ef0e0	COFUND-PPI	\N	COFUND-PPI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
ed7633b4-b274-42a7-8168-d88a05cd588f	Collective	\N	Collective		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9c856327-9da1-4a4c-b275-938e0b1388d8	CON	\N	CON		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
eca08580-1b0d-4788-88ba-965a0e99a901	Cooperative	\N	Cooperative		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
3448aad1-62e2-4610-84e0-86131e72a8f4	CP	\N	CP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e5c1530-39c1-4511-929d-df2e1939be2a	CP-CS	\N	CP-CS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7dc73323-dc5a-47f2-b80b-9d9e3f404807	CP-CSA	\N	CP-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
88f9207c-8471-45c6-815b-0e6e6b509aba	CPCSA	\N	CPCSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f45c2f99-8b9c-40b2-b4a8-6bfab22ebbd2	CP-CSA-Infra	\N	CP-CSA-Infra		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f39a5e75-9305-4742-9071-7067e0f6dfc2	CP-CSA-INFRA	\N	CP-CSA-INFRA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7a5dbb11-8a1b-429b-a40e-c17529cb7a9a	CP-CSA-Infra-IP	\N	CP-CSA-Infra-IP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
84d73100-4ff2-4c1a-89fc-0bbfb8adf207	CP-CSA-Infra-PP	\N	CP-CSA-Infra-PP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
06926f5f-24eb-4fd6-bb09-0c15cc721f50	CP-CSA-PCP	\N	CP-CSA-PCP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8f537880-83f6-4081-989a-b091f22ea679	CP-FP	\N	CP-FP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
10ef42b0-a210-4aab-b98f-c460edb4900b	EAT	\N	EAT		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
de31d495-f64e-4c54-a430-e908c3699ff1	CP-FP-INFSO	\N	CP-FP-INFSO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b1290c0e-328f-49fd-bba9-40f321b73850	CP-FP-INFSO-FET	\N	CP-FP-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
89e0822b-4cde-4e6b-95b2-b18880327eac	CP-FP-SICA	\N	CP-FP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f1506269-5d37-44ef-be37-cd80df9322ce	CP-FP-TP	\N	CP-FP-TP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e87bc0ee-fc24-421a-ac85-ffb162ce74ed	CP-FP-TP-SICA	\N	CP-FP-TP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9ff58b79-42fd-454d-a778-194c6aad504e	CP-IP	\N	CP-IP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9365e28a-f6b8-4364-8603-79673e19883c	CP-IP-INFSO-FET	\N	CP-IP-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
cbcd2bb9-356c-4012-9371-c331d82b4fd7	CP-IP-SICA	\N	CP-IP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
514cb48e-1cb3-42db-b252-9031a36a79c0	CP-IP-TP	\N	CP-IP-TP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f2294bb8-0625-49dc-b20f-8297562941bf	CP-SI	\N	CP-SI		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
402e85fc-351f-4e90-81b0-f4a0179361f7	CP-SICA	\N	CP-SICA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
84c9ec65-9bf8-4b9e-a1b3-54bfef8d6574	CP-SICA-INFSO	\N	CP-SICA-INFSO		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
034886f6-56e8-424b-b4d8-ddbf83b7e4df	CP-SoU	\N	CP-SoU		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2444571f-1240-48cc-81bf-68745efac265	CP-TP	\N	CP-TP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d21d1280-5b02-4511-bba0-6294e3fc6c63	CRAFT	\N	CRAFT		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a59e5ddd-24e3-4314-81a7-a32bafcb1fd1	CRS	\N	CRS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
374c5fc4-c0f6-45c4-93d5-2eed4938704f	CS2-CSA	\N	CS2-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2b2de432-f0dd-4b9f-bc5d-78a60d2823ec	CS2-IA	\N	CS2-IA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
59775f7a-d79e-42b1-9d45-99a26e0ca161	CS2-RIA	\N	CS2-RIA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
0cf45e4a-d7f8-4eb4-9cfc-c98e6946ff0f	CSA	\N	CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a3ca4cb3-9d4d-42dd-aec0-475f164f95e4	CSA-C	\N	CSA-C		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
6f48fa7a-4464-4930-8252-86ab56e87450	CSA-CA	\N	CSA-CA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
17760d24-d67d-4ac1-9d55-3810a8dd6d74	CSA-CA-INFSO-FET	\N	CSA-CA-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7155e388-9bfd-49b9-9480-5d0d9dc61669	CSA-E	\N	CSA-E		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fe74575a-278c-46f8-a003-e3f5f6a2e09a	CSA-ERANET	\N	CSA-ERANET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a7ce014d-92de-4083-ab09-206fb92f711b	CSA-ERA-Plus	\N	CSA-ERA-Plus		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c8d0c483-d882-426f-8bad-47662d1da448	CSA-ERA-PLUS	\N	CSA-ERA-PLUS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
77811378-be9c-4230-87c5-fa8290fe93c6	CSA-LS	\N	CSA-LS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
c37fc900-79ed-4f33-84d7-0cb89cbef836	CSA-LSP	\N	CSA-LSP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
f375a49f-5197-4e56-b27b-2ae3fb96ea54	CSA-S	\N	CSA-S		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
8cccb107-fca2-47f1-872d-4637751309b1	CSA-SA	\N	CSA-SA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
9c434d5b-2527-4d20-a3ee-480d275c3f42	CSA-SA-INFSO-FET	\N	CSA-SA-INFSO-FET		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5d408a47-98ef-464b-a351-b8b7c457a751	CSA-SA(POC)	\N	CSA-SA(POC)		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
38fff536-b6c5-44bc-87cf-925901bbdba2	CSC	\N	CSC		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d55d476e-cf09-49e8-9af8-734a4dd3058c	DEF	\N	DEF		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
1d9eddc2-8923-4770-bb2b-2a95f2412512	DEM	\N	DEM		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
fd4d7946-4e77-42ed-bf55-97df66d37dc4	DEP	\N	DEP		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
7fa6ace2-8716-428a-8c47-ebc72da92456	DS	\N	DS		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
2435f50b-c8e5-41d5-a40e-cfa80dd16541	DS-SSA	\N	DS-SSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5b32c8f0-f986-48d0-8d55-2037bf8cc455	EAD	\N	EAD		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a32665af-00c3-4f5b-a3ef-2af0deb90c4c	EAW	\N	EAW		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
e2ce15bf-0d15-426a-be6a-c7724ce144ab	ECSEL-CSA	\N	ECSEL-CSA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
de59f44b-830a-479f-af2b-85b6768ce93b	ECSEL-IA	\N	ECSEL-IA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
a2014821-d3a8-4620-838c-ab8d271a697f	ECSEL-RIA	\N	ECSEL-RIA		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
5e3d3e57-b1de-42ae-88fb-5452145c4821	EIF	\N	EIF		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
b5bcb9ce-5ace-4915-8115-209b9b07d0e7	ERA-NET-Cofund	\N	ERA-NET-Cofund		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
d3215458-267a-40eb-8a21-7ba6de64941e	ERC-ADG	\N	ERC-ADG		code	funding_schemes	cordis_temporary	VARCHAR	Active	2026-10-31 03:41:59.741954+00	2026-10-31 03:41:59.741954+00
\.
COPY public.t_semantic_edge_table_has_column (edge_id, source_dimension_id, target_entity_id, is_primary_source, status, created_at, updated_at) FROM stdin;
507acb09-6c67-4315-9606-b0a89772728b	dbecf104-c73d-5016-99d3-dd9d6fa47120	452d93e6-35dd-426f-863c-a998d42b2c78	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
33ce5dac-7292-438f-85a7-f6a9efb0dcba	e454c561-623c-5447-8dce-b3f559f05b65	ae2e4492-031d-48ae-9c68-8f1dcbe95437	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
fb82df8d-ab38-417f-96ec-762edb722009	6981aeec-9867-5559-9659-95cb008082fe	ae2e4492-031d-48ae-9c68-8f1dcbe95437	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
2d569b92-7410-458b-98d5-09692f81d107	731f865d-608a-5661-b581-8c224c75976b	ae2e4492-031d-48ae-9c68-8f1dcbe95437	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
88309f87-040d-4e59-83e8-e58a32b993a5	181f9815-26c0-5c99-964b-5e4388beaf26	452d93e6-35dd-426f-863c-a998d42b2c78	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
2be3e379-aeba-47cf-99b5-630300647000	0f2c294b-e5bb-5658-a34f-e199c381f6ed	ae2e4492-031d-48ae-9c68-8f1dcbe95437	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
f74e394b-7a3a-4df4-a7d2-7caa70868ec8	9bdc6f76-c04e-5b0f-a016-4e73d8b6a0f2	452d93e6-35dd-426f-863c-a998d42b2c78	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
0152ac63-0a12-4c81-ac26-8876f57a61de	a5149156-fafa-5143-b48c-54798d4b6d61	ae2e4492-031d-48ae-9c68-8f1dcbe95437	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
1a4a43aa-d975-422c-b2b9-d7daba417f95	89aa1f5e-9879-532a-b723-c42b81200701	452d93e6-35dd-426f-863c-a998d42b2c78	t	Active	2026-10-26 06:17:41.651637+00	2026-10-26 06:17:41.651637+00
ea0fc333-63fb-483a-8715-af4e061c4db3	74927d59-86e2-56d0-9c44-a8b838ea8a55	af01bc68-175f-4680-a45b-7ce1df299761	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
9916350c-050d-42ce-a43a-3e781511678f	c4c437ec-e7de-5590-9265-a2c21674ae4d	919004a6-67ec-4d2d-bf0f-18ae953dad15	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
5b155074-3b0a-4a62-ba95-6d0208101907	ea550e34-bc87-57e4-b93a-9319e2397423	8d7100b2-8b83-4be9-922f-29f482ef3b8a	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
0a0e99b6-da64-496f-9959-f2aa1f4f794d	7e738b51-9263-5bcb-aed0-e5739092724b	d172eb52-7fff-4cc8-b2ad-e61821067136	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
ce736d93-8451-4366-899d-541efa84fc85	607298ac-0e01-5419-abd8-ce63c13d243c	5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
eb5f28cc-8344-453d-8868-4da22a41f3c4	d37ffdbc-49bb-5b67-b809-6314d7443b98	919004a6-67ec-4d2d-bf0f-18ae953dad15	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
269a2df4-3ce5-4346-a94b-d9333da90007	507ba30e-555e-5d20-88d1-2f3b21163ba3	cd961474-8eff-4886-97d1-6345c73e864b	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
c514c2b6-6575-458f-b8e7-00740aa3f85d	c9b3abb6-139e-5c4a-bfcf-82c959c0afbf	d172eb52-7fff-4cc8-b2ad-e61821067136	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
b02a3a7d-5268-4cd0-92f9-63cfa0382403	e2815a8a-3288-51b3-9b1e-14e37c8a5452	5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
cc490a20-5bc4-4d9a-b51b-17e91ca5bd05	639a5c93-084c-5a9b-8911-52a923e0ab0e	64db1cbc-0840-47d4-96de-edeebe954ae9	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
3259f6c9-f792-466e-9d24-67500a8d2f26	5c6509a9-b8f8-5a92-a007-e3a6453613a7	d172eb52-7fff-4cc8-b2ad-e61821067136	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
9379e05a-4df3-4f5f-8a6b-38e72d1fad62	fac5e9b4-f75b-505e-9326-6b3d6f8935b0	af01bc68-175f-4680-a45b-7ce1df299761	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
25cd04b4-1c00-4c74-bff0-beb9c9dc64fb	650253ec-5c99-5ae8-8666-7c61dcd9f4b1	8d7100b2-8b83-4be9-922f-29f482ef3b8a	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
73883ae4-5b85-4344-81f8-edfa46677cc7	1fa2911e-abe8-5d67-a119-1f1a6f03e237	5fbd92cb-06a2-40d0-b3e6-b160bbbdc6bd	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
3c5924b5-e916-49ac-99a8-d42ec7bf1362	e542e785-7a32-50a8-ae51-68ae440db03d	64db1cbc-0840-47d4-96de-edeebe954ae9	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
f90809e2-c06c-4b57-a7f0-0a5346e62ba8	234503d9-6d52-55a1-8580-a60c02b2cbf7	cd961474-8eff-4886-97d1-6345c73e864b	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
f6d692ef-309b-4745-bed2-dd1be912fd8f	19c64428-f519-5d25-975e-0fd662917cfd	919004a6-67ec-4d2d-bf0f-18ae953dad15	t	Active	2026-10-26 06:21:27.376217+00	2026-10-26 06:21:27.376217+00
a7bcba86-9fc1-44d8-b04d-e8fbed17dcc5	931ef3bd-ed69-51b6-811c-fce4b850c0ba	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
839ae247-2db6-4b62-b6ca-0569d517ee92	1003752e-5e92-59a4-ad11-a581286595ec	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
a3d68118-b273-4737-bae3-d4208b4b23e5	7d0c4475-d518-5a49-b9ed-7ce9dc623b08	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
0fd57d8b-3403-4da0-beb1-eac2f922c5cb	45c1c894-f774-588d-bf53-82e3b1cf1c44	5ea00da3-6274-4df2-afa9-933930a5f4ec	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
d43f188e-c65c-4089-80c6-2787e3861792	6776b1f8-7cb3-532c-9712-a2ecad55ff85	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
299b29b7-dbbd-4a43-9abd-1fdb9e744d1c	e6270c4f-d40e-5130-a0ff-4ca3f3978c0e	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
5f1c8ba2-eb62-4a95-9972-7ae6b0668aaa	20a9ee1b-db41-583f-b296-14afdab0c055	e85848dd-cca7-4995-b740-36a916a789eb	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
98b7a19f-b127-4816-97c1-9097f272679a	2f519aea-7ac3-5aff-b489-b0adb7d8ff11	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
a80a0b9a-7b56-4052-96a9-bbd36955c2d0	10a834e0-b46e-5ebe-bb26-da4618fab0b3	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
b7485103-9b6f-4dad-9e50-fa1bc3f943ea	da24e1e3-bb9d-449c-b0c7-f0a3bc305d03	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
418cc028-ea22-45dd-8a6d-9b85b713548f	5f1c507d-b2fe-512b-bf99-1b0955cfd069	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
026a4d1a-fd14-44ba-80ca-1c67146684fd	f2ddaaad-dedf-5611-8dad-10c567f2287c	e85848dd-cca7-4995-b740-36a916a789eb	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
867d885d-caca-444e-863a-1919f5469cd2	b8f8ea6b-aa52-41c6-9a32-f45f500ac94b	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
bb05fb7c-a263-4566-924a-e1d8a5b3e70d	7e52348a-c459-5e5f-a254-4452a4f3bb36	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
97a5780c-8533-4f1e-bfd7-3dce2ccf4418	4cfad750-de9a-559d-a655-165cd088ef9c	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
ad96bc05-d4c7-431f-b2d4-5e34a0518303	98395eca-3905-53c8-b341-e2d0ff50d3d0	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
0543e008-52db-4c60-acac-819b362fefe3	d6459c77-2aec-536e-9b0b-3278ef480b58	db5af359-7d66-498f-b1d9-5aada88f34b5	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
70f989ac-78ad-4bc5-b9cf-ef59dab53e63	c6357c03-2c46-5e33-87c5-88d767910eb0	db5af359-7d66-498f-b1d9-5aada88f34b5	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
42258cb8-8a89-4228-a15e-213a4be0228e	f0917586-bfbc-5f3a-8365-732ae34e2406	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
6fa00220-95b5-4ba3-bab7-51360d0290bd	46d8c81d-51d8-5ef2-a0b9-c4a7110c3c9f	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
e006260d-fe1e-49ad-bf75-09aac4bf37f4	18b08caf-e6e1-5e44-a637-9637daa5f46b	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
40e1dd50-3f59-40a2-af17-396b76c2a8d1	e4175882-86a4-5b25-aec1-63fa6157d511	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
074f0b42-568b-42ac-b27b-b405b1ba39d5	7dfb9d05-5718-5291-8161-569b6f807699	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
2ef774e7-937d-4779-9d72-1d4720aeb6c4	d89a02ac-58e5-5cf9-899c-577d956384d7	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
1dedb8af-50ab-4c03-9bfc-789de0cf00f9	7d1f01f2-f430-5cbb-bf63-39f167f6a481	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
dd0fc5dc-eecd-4b67-a381-2f17cb53ed9c	e5859fc3-4f1b-5167-8660-07ce87deb38f	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
b9f80615-0a9f-4c67-ab2d-611cb5d0535f	e06bf26a-6fc9-50a4-9371-8c9cad9bd309	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
ba0432c9-4cbc-4a60-8fdc-19cdbc9e38ba	2480dca3-9cd4-415f-8a87-6040b6d581f5	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
8abcc2a1-ad33-4947-9a97-2309fe001f27	f543bff8-a8d7-5f67-9e3d-f432b3cc6ef4	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
c0115dd7-1e31-47c2-9064-5d074a7c682d	b9fb4092-cf11-5360-8e06-93bf316a3164	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
fab8c0bb-a4fa-4e8c-9a4f-d672d62ea993	a1bb8784-4bac-573a-9de5-8810c09e5e3b	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
494a3587-ac29-4d23-8ffd-4b96256a512e	b4356ca7-95c5-51e3-9e92-48237ae3c85e	5ea00da3-6274-4df2-afa9-933930a5f4ec	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
1b8f09bf-fd7e-46a5-8b47-48848b7c9cf3	6b8a8e50-5bf9-5307-afdd-ca7e3ae26041	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
9f2fd97c-864c-4965-b576-2c4c4529e606	ead61652-231c-5fce-a9cd-f41b6845a9f2	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
30b7f9c4-97bb-4934-aad9-f7dfcd4d0874	27de199a-8fdb-57d5-8259-23cd1328696e	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
259cdace-e20e-4a4d-bb75-b125851d2beb	b625cd5f-5ba4-5d28-a887-b9ce09a062bc	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
c6a36da3-0727-4616-8fe4-03047715075a	5ef477d6-ac45-5285-9baa-89e4a77ed6cf	02237d15-fa57-4db5-824a-df2a18bb6c35	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
0ab530f9-a2c0-4d7b-8796-4940dfda0e85	53cf00a7-7aec-5ca9-a452-00b9024ab25d	71b3f83b-a7c2-48e8-80f2-7e023cdf06c1	t	Active	2026-10-26 06:21:27.652293+00	2026-10-26 06:21:27.652293+00
60bea330-70ea-45f9-98cf-09a7a8156f86	0d27a56d-e442-5afc-a8b9-0e21aa5e6d68	8c160313-6794-48e9-9d43-06ef6d146023	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
3b455e88-ade2-4ca5-87f6-0e7b3b520d69	e4b5df58-1b68-5b1c-b7a2-3ea0ff6428a5	ced13c31-3076-4620-a122-b53f6bfbc8d1	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
ded2fb68-05b6-4175-99e6-b7a266c3a033	92fd1362-a2d5-552c-9d25-b0b6985c9abd	8c160313-6794-48e9-9d43-06ef6d146023	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
17d3a76c-7edc-4e46-9c23-0166bd07eeae	0625dd8c-6d9b-5812-8d61-1d79b894a9b6	ced13c31-3076-4620-a122-b53f6bfbc8d1	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
1a7fdc47-f467-4120-ac9b-b579230bcc25	17f167f3-ace6-52b5-80bc-a18ca7cc9046	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
8f8e166c-bd64-48de-9bb5-3768e3428677	daa00751-7e2e-5208-9f34-6dabc4446e6c	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
3ab35487-0b63-434a-b569-ebee34657946	2e727c02-10bd-561a-881e-d586e86c93e9	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
91a3171d-e589-42ba-af77-04dc4d5ac4ca	16682df4-941a-52f4-bada-bb727361436d	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
403664e5-883b-4c79-a002-412427eeb26f	e5b9a4ba-58c6-5f7b-9dbc-6cb52670617b	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
b3c74027-93b4-4bb0-9e6a-09c0e3f0ede5	00870e84-bc48-5394-809c-0cf025d684d0	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
18a269c5-aab6-4005-9112-53b08bc9f9e4	1d124e44-ce61-52ab-b4f5-4532c14491f1	ced13c31-3076-4620-a122-b53f6bfbc8d1	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
e51f04f7-c4a5-45d4-945f-c9cf86c2e70c	85a724bc-e06a-57e6-8690-31bccfde0e6a	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
c216d55a-dbdc-47ed-8009-c5286b3d9ba6	a354d23b-a7e1-5001-82f1-0fd6f97d65bf	ced13c31-3076-4620-a122-b53f6bfbc8d1	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
9e55526a-15d3-44c1-9586-c2b9e8396137	27f223f5-297f-53cd-91fc-8335c34f6eab	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
cad8ca32-930a-4e1f-8d4b-9fa042c1794a	0b58d135-b4f3-5448-919e-af54804de85b	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
06e31fa2-7ab3-4ff8-9776-08d4a8ca014d	11222c24-47af-594a-9f5b-cf2f011bb7b5	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
94696bf7-0cd4-4618-8065-e509541ee703	8281e9a2-fe9c-5e5d-b60b-fdd8da1156a7	ced13c31-3076-4620-a122-b53f6bfbc8d1	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
da49503d-5bda-4049-a9ce-561f5af61df5	a5216dd0-53fa-5b35-9605-517f7f7b1635	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
7452f955-896d-4cde-aac1-129c6dbac439	8b2aec85-d96e-5a77-9e09-6d02bc15925f	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
9fb83af9-ed8d-42ff-8fa3-68116f41b52f	1c0048b0-fbf6-5c65-a8c6-8db36ff3bfd5	6b6bda9e-cd24-48cb-848d-a9945edcc139	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
dc8f7c9d-006b-456e-a1da-3368867d6caf	fe127671-8b8f-5e5c-bebd-cf8fe68669d7	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
080225d8-29da-4b13-ac36-041b028a5099	1dd2d62b-c967-5b5a-8166-0cbc93a54f14	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
ff8eeb66-406e-4167-9517-2c3e1d264b12	d5a9ced2-8f7f-509e-92b0-fc7f17f5e08f	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
c119b970-22d7-4474-ba20-3bcec6e870a9	088f245d-84b3-57f6-964e-ef2a643d5122	93e9b14a-3710-413d-b611-255bf90040d3	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
eb1c66e8-0557-4a9e-aed9-960469eca59d	6aa8e21c-3faa-53dd-aa0b-5aae05d15b47	93e9b14a-3710-413d-b611-255bf90040d3	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
39e4fb6e-6acd-4878-9ede-81a1bf017d17	afbe1d23-b5ab-5a41-8cfb-1042c22bb13d	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
05f6028e-7907-4bdc-a05a-bbd177416546	938da35f-973c-519b-9b6b-8fb2278b9324	804b8988-7d87-4a2c-9086-6be7b216f565	t	Active	2026-10-26 06:21:27.960558+00	2026-10-26 06:21:27.960558+00
\.
COPY public.t_semantic_edge_column_join_relationship (edge_id, source_dimension_id, target_dimension_id, join_type, expression, intent, status, created_at, updated_at) FROM stdin;
6d7ca711-a08b-5740-adca-2661a61dfb46	c9b3abb6-139e-5c4a-bfcf-82c959c0afbf	650253ec-5c99-5ae8-8666-7c61dcd9f4b1	EQUALS	{source} = {target}	erc_panels.part_of = erc_research_domains.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
a42c1a06-c3c6-5e1d-9c9e-fde09b464299	7d1f01f2-f430-5cbb-bf63-39f167f6a481	dbecf104-c73d-5016-99d3-dd9d6fa47120	EQUALS	{source} = {target}	institutions.geocode_regions_3 = eu_territorial_units.geocode_regions	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
46f61776-230b-55aa-9a4a-9115b15e5955	1003752e-5e92-59a4-ad11-a581286595ec	6981aeec-9867-5559-9659-95cb008082fe	EQUALS	{source} = {target}	institutions.country_id = countries.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
67dd725f-eb6c-5cb7-aa49-956be9529b28	0625dd8c-6d9b-5812-8d61-1d79b894a9b6	a354d23b-a7e1-5001-82f1-0fd6f97d65bf	EQUALS	{source} = {target}	programmes.parent = programmes.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
6e80a4d9-5114-540a-8285-859b5d60d6b7	74927d59-86e2-56d0-9c44-a8b838ea8a55	0b58d135-b4f3-5448-919e-af54804de85b	EQUALS	{source} = {target}	project_erc_panels.project = projects.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
16be5101-acb0-5f44-9a32-a0eb27574714	fac5e9b4-f75b-505e-9326-6b3d6f8935b0	7e738b51-9263-5bcb-aed0-e5739092724b	EQUALS	{source} = {target}	project_erc_panels.panel = erc_panels.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
aa70b9c4-db48-52e0-bcc7-d68f6d6f94b0	7dfb9d05-5718-5291-8161-569b6f807699	0b58d135-b4f3-5448-919e-af54804de85b	EQUALS	{source} = {target}	project_members.project = projects.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
aab2d3e4-4a4e-56d2-a9af-aac9a3a57bc4	e6270c4f-d40e-5130-a0ff-4ca3f3978c0e	20a9ee1b-db41-583f-b296-14afdab0c055	EQUALS	{source} = {target}	project_members.member_role = project_member_roles.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
8c270977-7b8c-5e09-a3a5-6ab819eb11b8	b9fb4092-cf11-5360-8e06-93bf316a3164	5ef477d6-ac45-5285-9baa-89e4a77ed6cf	EQUALS	{source} = {target}	project_members.institution_id = institutions.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
e989241d-1e4a-50f4-9bf7-c8597e3e822e	d89a02ac-58e5-5cf9-899c-577d956384d7	dbecf104-c73d-5016-99d3-dd9d6fa47120	EQUALS	{source} = {target}	project_members.geocode_regions_3 = eu_territorial_units.geocode_regions	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
277007de-afb9-590d-848a-8c1aced068bd	6b8a8e50-5bf9-5307-afdd-ca7e3ae26041	c6357c03-2c46-5e33-87c5-88d767910eb0	EQUALS	{source} = {target}	project_members.activity_type = activity_types.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
13160541-1d56-55e9-ae75-fbcc02f5b4e7	6aa8e21c-3faa-53dd-aa0b-5aae05d15b47	0b58d135-b4f3-5448-919e-af54804de85b	EQUALS	{source} = {target}	project_programmes.project = projects.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
938d23ce-b52e-5a75-8be7-35a9383b7f42	088f245d-84b3-57f6-964e-ef2a643d5122	a354d23b-a7e1-5001-82f1-0fd6f97d65bf	EQUALS	{source} = {target}	project_programmes.programme = programmes.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
cebb5632-3a0d-52d8-b6d9-ba8740c01141	639a5c93-084c-5a9b-8911-52a923e0ab0e	19c64428-f519-5d25-975e-0fd662917cfd	EQUALS	{source} = {target}	project_subject_areas.subject_area = subject_areas.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
57be87a8-a909-5b3c-ba91-fe99380799b7	e542e785-7a32-50a8-ae51-68ae440db03d	0b58d135-b4f3-5448-919e-af54804de85b	EQUALS	{source} = {target}	project_subject_areas.project = projects.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
f57e36b6-29c8-52ca-9c0b-1b45b221fea5	507ba30e-555e-5d20-88d1-2f3b21163ba3	1fa2911e-abe8-5d67-a119-1f1a6f03e237	EQUALS	{source} = {target}	project_topics.topic = topics.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
5b30640d-ac85-53b0-98bc-48dc433b355a	234503d9-6d52-55a1-8580-a60c02b2cbf7	0b58d135-b4f3-5448-919e-af54804de85b	EQUALS	{source} = {target}	project_topics.project = projects.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
fa154a32-5d38-5661-9b66-2d1852d12c27	17f167f3-ace6-52b5-80bc-a18ca7cc9046	45c1c894-f774-588d-bf53-82e3b1cf1c44	EQUALS	{source} = {target}	projects.principal_investigator = people.unics_id	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
538d48b6-62a5-5407-9e08-e9c4dc16e7f0	11222c24-47af-594a-9f5b-cf2f011bb7b5	1c0048b0-fbf6-5c65-a8c6-8db36ff3bfd5	EQUALS	{source} = {target}	projects.framework_program = ec_framework_programs.ec_framework_program_name	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
e3387757-61d7-55d3-a563-15fbd8579653	938da35f-973c-519b-9b6b-8fb2278b9324	92fd1362-a2d5-552c-9d25-b0b6985c9abd	EQUALS	{source} = {target}	projects.ec_fund_scheme = funding_schemes.code	Active	2026-09-23 14:01:56.408209+00	2026-09-23 14:01:56.408209+00
\.
COMMIT;
